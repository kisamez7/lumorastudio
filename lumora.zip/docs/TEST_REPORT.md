# Relatório de testes

Ambiente: sandbox Linux x64, **CPU apenas**, FFmpeg 7.0.2 estático, Node 22, PostgreSQL local, **sem navegador automatizado, sem GPU, sem Docker, sem Ollama, sem Redis**.
Legenda: ✅ executado e passou · ⚠️ executado parcialmente · ❌ **não executado** (e por quê).

| # | Teste | Resultado | Detalhes reais |
|---|---|---|---|
| 1 | Upload MP4 | ✅ | MP4 1920×1080 de 283 MB enviado em streaming; FFprobe: 200 s, 30 fps, h264/aac |
| 1 | Upload MOV / MKV / WEBM | ❌ | Aceitos pela validação de extensão e FFprobe, mas não enviados nos testes |
| 1 | Arrastar e soltar (UI) | ❌ | Sem navegador automatizado; código implementado, não exercitado |
| 1 | Importação de URL direta | ✅ | `mov_bbb.mp4` público (788 KB, 320×176, 10 s): probe + download + FFprobe |
| 1 | Importação de plataforma (YouTube) | ✅ (limitação) | Retorna “importação direta indisponível” + método oficial; oEmbed não respondeu no sandbox (sem título) |
| 1 | Rejeição de URL inválida / SSRF | ✅ | `127.0.0.1`, `localhost`, `169.254.169.254`, `ftp://`, credenciais embutidas, texto aleatório: todos bloqueados |
| 2 | Análise de vídeo de **30 min** | ❌ | Testado só com vídeo **sintético de 200 s** (áudio+imagem analisados em ~8 s). Vídeo real de 30 min e fala real em PT-BR **não** foram testados |
| 2 | Análise visual/áudio 100% | ✅ | `coverage`: 200 s de áudio (100%), 400 amostras visuais a 2 fps |
| 2 | Transcrição Whisper | ⚠️ | `scripts/transcribe.mjs` testado com `jfk.wav` (inglês, modelo `whisper-tiny`): texto correto com tempos por palavra. **Português e modelo `base` não testados**; último timestamp veio esticado (corrigido por `sanitizeSegments`) |
| 2 | Seleção global, pontuação, dedupe | ⚠️ | Funcionou em vídeo sintético com SRT sintético (repetitivo): retornou 1 de 3 cortes pedidos por sobreposição/repetição, nota 99 com 12 critérios. **Qualidade editorial em conteúdo real não foi avaliada** |
| 3 | Gameplay 1920×1080 + webcam fora do centro | ⚠️ | Vídeo sintético (barras SMPTE no canto superior direito). Layout A com região da webcam marcada manualmente: quadro inspecionado — jogo em cima, webcam embaixo, sem deformação. **Detecção facial automática NÃO testada** (serviço `/backend` não executado) |
| 4 | Duração dos cortes | ✅ | PATCH para 119,7 s → HTTP 400 (backend). Render: FFprobe = **63,77 s** (dentro de 60–90). Verificação pós-render descarta arquivos fora do intervalo |
| 5 | Hooks | ⚠️ | 5 opções geradas (Surpresa, Pergunta, Revelação, Curiosidade, Humor) a partir do texto do trecho; hook visível no quadro renderizado (2–4 s configurável), com palavra de destaque. Edição manual via API/UI: não exercitada no navegador. Modo LLM (Ollama) não testado |
| 6 | Legendas | ⚠️ | 64 linhas geradas; legenda renderizada com destaque de palavra; SRT por endpoint. Sincronia medida visualmente em 2 quadros apenas; edição na UI não exercitada |
| 7 | Editor (timeline, canvas) | ❌ | Compilado e tipado; **não testado em navegador**. Render pela API testado |
| 7 | Áudio (loudnorm etc.) | ⚠️ | Renderizado com `loudnorm`+fade (padrão); denoise/voz/música não testados |
| 8 | Downloader: URL válida, MP4, MP3 | ✅ | Download de mídia direta, extração MP3 concluída, `2160p` recusado (original 176p), Range 206 OK |
| 8 | Imagens/slideshow ZIP | ❌ | Não implementado (informado na UI) |
| 9 | Publicação (títulos/descrições/hashtags) | ❌ | Rotas e UI implementadas; **não executadas nos testes**. Capas (canvas): não testadas |
| 10 | Build / rotas | ✅ | `next typegen`, `tsc --noEmit`, `npm run build` e `build_and_start` passaram; páginas respondem 200 |
| 10 | CORS / Redis / Worker separado / Docker / S3 | ❌ | Não executados. Fila é em processo (sem Redis). Docker/compose escritos mas **não construídos**. S3 não implementado |
| 10 | Netlify / Vercel | ❌ | Arquivos de configuração escritos; **nenhum deploy realizado** |
| 10 | Persistência / progresso | ✅ | Dados no PostgreSQL + disco; progresso real via jobs (render 0→100%) |

## Bugs encontrados e corrigidos durante os testes
1. Proxy do Next limitava uploads a 10 MB → rotas de upload excluídas do proxy, com autenticação no handler.
2. Download por URL corrompido (listener `data` consumia chunks antes do pipe) → contagem de bytes movida para dentro do `saveStream`.
3. Hook/legendas cobriam gameplay/webcam → padrões de posição ajustados por layout.

## Para validar no seu ambiente
`tests/api-smoke.sh` (gera-se o vídeo com `scripts/make-test-assets.sh`). Teste ainda: vídeo real de 30 min em PT-BR, MOV, webcam real com o serviço CV, Ollama, deploy em VPS/Netlify/Vercel.
