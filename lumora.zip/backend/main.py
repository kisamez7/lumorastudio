"""Serviço de Computer Vision do Lumora Studio (OpenCV).

Endpoints:
  GET  /health
  POST /detect-webcam   (multipart: frames[]=jpeg) -> região provável da webcam (frações 0..1)

Método: detecção facial (Haar cascade) em vários quadros; uma webcam é considerada detectada somente se
o rosto aparece numa posição ESTÁVEL em >= 2 quadros (IoU > 0.3). Não presume cantos; devolve null se incerto.
Limitação: não detecta webcam sem rosto visível (ex.: câmera apagada) — use a seleção manual.
"""
import cv2
import numpy as np
from fastapi import FastAPI, File, UploadFile

app = FastAPI(title="Lumora CV service")
_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")


def _iou(a, b):
    ax2, ay2, bx2, by2 = a[0] + a[2], a[1] + a[3], b[0] + b[2], b[1] + b[3]
    iw = max(0, min(ax2, bx2) - max(a[0], b[0]))
    ih = max(0, min(ay2, by2) - max(a[1], b[1]))
    inter = iw * ih
    return inter / float(a[2] * a[3] + b[2] * b[3] - inter + 1e-9)


@app.get("/health")
def health():
    return {"ok": True, "cascade_loaded": not _cascade.empty(), "opencv": cv2.__version__}


@app.post("/detect-webcam")
async def detect_webcam(frames: list[UploadFile] = File(...)):
    boxes = []
    size = None
    for f in frames:
        img = cv2.imdecode(np.frombuffer(await f.read(), np.uint8), cv2.IMREAD_GRAYSCALE)
        if img is None:
            continue
        size = img.shape[::-1]
        faces = _cascade.detectMultiScale(img, scaleFactor=1.1, minNeighbors=6, minSize=(max(24, img.shape[1] // 40),) * 2)
        if len(faces):
            boxes.append(tuple(int(v) for v in max(faces, key=lambda b: b[2] * b[3])))
    if not boxes or size is None:
        return {"cam": None, "confidence": 0.0, "frames": len(frames), "reason": "nenhum rosto detectado"}
    best, support = None, 0
    for b in boxes:
        s = sum(1 for o in boxes if _iou(b, o) > 0.3)
        if s > support:
            best, support = b, s
    if support < 2:
        return {"cam": None, "confidence": 0.2, "frames": len(frames), "reason": "rosto não estável entre quadros"}
    group = [b for b in boxes if _iou(best, b) > 0.3]
    x1 = min(b[0] for b in group); y1 = min(b[1] for b in group)
    x2 = max(b[0] + b[2] for b in group); y2 = max(b[1] + b[3] for b in group)
    w, h = x2 - x1, y2 - y1
    px, py = w * 0.9, h * 0.8  # expande do rosto para a moldura provável da webcam
    W, H = size
    rx1, ry1 = max(0, x1 - px), max(0, y1 - py)
    rx2, ry2 = min(W, x2 + px), min(H, y2 + py)
    return {
        "cam": {"x": rx1 / W, "y": ry1 / H, "w": (rx2 - rx1) / W, "h": (ry2 - ry1) / H},
        "confidence": round(support / len(frames), 2),
        "frames": len(frames),
        "reason": "rosto estável detectado; região expandida a partir do rosto",
    }
