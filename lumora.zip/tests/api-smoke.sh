#!/usr/bin/env bash
# Teste de integração (requer app rodando e tmp_test/game.mp4 + tmp_test/game.srt). Uso: BASE=http://localhost:3000 bash tests/api-smoke.sh
set -e
B=${BASE:-http://localhost:3000}
echo "== SSRF / URL inválida =="
curl -s -X POST $B/api/url/probe -H 'content-type: application/json' -d '{"url":"http://127.0.0.1:5432/x.mp4"}'; echo
curl -s -X POST $B/api/url/probe -H 'content-type: application/json' -d '{"url":"ftp://x/y.mp4"}'; echo
curl -s -X POST $B/api/url/probe -H 'content-type: application/json' -d '{"url":"http://169.254.169.254/latest/meta-data"}'; echo
curl -s -X POST $B/api/url/probe -H 'content-type: application/json' -d '{"url":"https://www.youtube.com/watch?v=dQw4w9WgXcQ"}' | head -c 400; echo
echo "== Upload + SRT + análise =="
PID=$(curl -s -X POST $B/api/projects -H 'content-type: application/json' -d '{"name":"Smoke","kind":"game"}' | python3 -c "import sys,json;print(json.load(sys.stdin)['id'])")
curl -s -X PUT "$B/api/projects/$PID/source?filename=game.mp4" --data-binary @tmp_test/game.mp4 | head -c 200; echo
python3 - <<PY
import json,urllib.request
r=urllib.request.Request("$B/api/projects/$PID/transcript",data=json.dumps({"srt":open('tmp_test/game.srt').read()}).encode(),method="PUT",headers={"content-type":"application/json"})
print(urllib.request.urlopen(r).read())
PY
curl -s -X POST $B/api/projects/$PID/analyze -H 'content-type: application/json' -d '{"transcribe":false,"count":3,"kind":"game"}'; echo
echo "Acompanhe: curl $B/api/jobs?projectId=$PID ; cortes: curl $B/api/projects/$PID/clips"
