import { NextResponse, type NextRequest } from "next/server";

/**
 * Proteção de acesso opcional: se APP_ACCESS_TOKEN estiver definido (versão hospedada),
 * todas as páginas e APIs exigem o cookie de sessão. Sem a variável, o app roda em modo local anônimo.
 */
export function proxy(req: NextRequest) {
  const token = process.env.APP_ACCESS_TOKEN;
  if (!token) return NextResponse.next();
  const p = req.nextUrl.pathname;
  if (p === "/login" || p === "/api/auth/login" || p === "/api/health") return NextResponse.next();
  const cookie = req.cookies.get("lumora_session")?.value;
  const bearer = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  if (cookie === token || bearer === token) return NextResponse.next();
  if (p.startsWith("/api/")) return NextResponse.json({ error: "Não autorizado" }, { status: 401 });
  return NextResponse.redirect(new URL("/login", req.url));
}

export const config = { matcher: ["/((?!_next/static|_next/image|favicon.ico|api/assets$|api/projects/[^/]+/source$).*)"] };
