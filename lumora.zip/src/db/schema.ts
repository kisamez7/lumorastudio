import { pgTable, uuid, text, integer, real, jsonb, timestamp, boolean, bigint } from "drizzle-orm/pg-core";
import type {
  Segment,
  LayoutConfig,
  HookConfig,
  HookOption,
  CaptionStyle,
  Caption,
  AudioFx,
  EditorElement,
  ScoreBreakdown,
} from "@/lib/types";

export const projects = pgTable("projects", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  kind: text("kind").notNull().default("general"), // general | game | podcast | educational
  status: text("status").notNull().default("draft"),
  sourceType: text("source_type"), // upload | url
  sourceUrl: text("source_url"),
  sourceAssetId: uuid("source_asset_id"),
  settings: jsonb("settings").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const assets = pgTable("assets", {
  id: uuid("id").defaultRandom().primaryKey(),
  projectId: uuid("project_id"),
  kind: text("kind").notNull(), // source | clip | compilation | download | audio | image | thumb | music | export
  filename: text("filename").notNull(),
  relPath: text("rel_path").notNull(),
  mime: text("mime"),
  sizeBytes: bigint("size_bytes", { mode: "number" }).notNull().default(0),
  durationSec: real("duration_sec"),
  width: integer("width"),
  height: integer("height"),
  fps: real("fps"),
  format: text("format"),
  hasAudio: boolean("has_audio").default(true),
  meta: jsonb("meta").$type<Record<string, unknown>>().notNull().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const transcripts = pgTable("transcripts", {
  projectId: uuid("project_id").primaryKey(),
  language: text("language").notNull().default("pt"),
  engine: text("engine").notNull(), // whisper-local | srt-import | manual
  segments: jsonb("segments").$type<Segment[]>().notNull().default([]),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export type AnalysisAudio = { energy: number[]; silenceRatio: number; peaks: number[] };
export type AnalysisVisual = { motion: number[]; cuts: number[]; sampleFps: number };
export type SummaryData = {
  short: string;
  detailed: string;
  topics: { name: string; count: number }[];
  bullets: { t: number; text: string }[];
  chronological: { t: number; text: string }[];
  events: { t: number; text: string }[];
  conclusions: string[];
  engine: string;
};
export type MindNode = { id: string; label: string; children: MindNode[]; t?: number };

export const analyses = pgTable("analyses", {
  projectId: uuid("project_id").primaryKey(),
  status: text("status").notNull().default("none"),
  audio: jsonb("audio").$type<AnalysisAudio | null>(),
  visual: jsonb("visual").$type<AnalysisVisual | null>(),
  coverage: jsonb("coverage").$type<Record<string, unknown> | null>(),
  summary: jsonb("summary").$type<SummaryData | null>(),
  mindmap: jsonb("mindmap").$type<MindNode | null>(),
  notes: text("notes"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const clips = pgTable("clips", {
  id: uuid("id").defaultRandom().primaryKey(),
  projectId: uuid("project_id").notNull(),
  type: text("type").notNull().default("clip"), // clip | compilation
  title: text("title").notNull().default(""),
  startSec: real("start_sec").notNull().default(0),
  endSec: real("end_sec").notNull().default(0),
  score: integer("score").notNull().default(0),
  scoreBreakdown: jsonb("score_breakdown").$type<ScoreBreakdown>().notNull().default({}),
  justification: text("justification").notNull().default(""),
  description: text("description").notNull().default(""),
  topic: text("topic").notNull().default(""),
  context: text("context").notNull().default(""),
  visualEvent: text("visual_event").notNull().default(""),
  spokenText: text("spoken_text").notNull().default(""),
  editorialPotential: text("editorial_potential").notNull().default(""),
  hookOptions: jsonb("hook_options").$type<HookOption[]>().notNull().default([]),
  hook: jsonb("hook").$type<HookConfig>().notNull(),
  captionStyle: jsonb("caption_style").$type<CaptionStyle>().notNull(),
  captions: jsonb("captions").$type<Caption[]>().notNull().default([]),
  layout: jsonb("layout").$type<LayoutConfig>().notNull(),
  audioFx: jsonb("audio_fx").$type<AudioFx>().notNull(),
  elements: jsonb("elements").$type<EditorElement[]>().notNull().default([]),
  extra: jsonb("extra").$type<Record<string, unknown>>().notNull().default({}),
  status: text("status").notNull().default("candidate"), // candidate | rendering | rendered | failed
  outputAssetId: uuid("output_asset_id"),
  renderedDuration: real("rendered_duration"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const jobs = pgTable("jobs", {
  id: uuid("id").defaultRandom().primaryKey(),
  projectId: uuid("project_id"),
  type: text("type").notNull(),
  status: text("status").notNull().default("queued"),
  progress: integer("progress").notNull().default(0),
  message: text("message"),
  error: text("error"),
  input: jsonb("input").$type<Record<string, unknown>>().notNull().default({}),
  result: jsonb("result").$type<unknown>(),
  cancelRequested: boolean("cancel_requested").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const publishItems = pgTable("publish_items", {
  id: uuid("id").defaultRandom().primaryKey(),
  projectId: uuid("project_id"),
  clipId: uuid("clip_id"),
  platform: text("platform").notNull(), // tiktok | reels | shorts | facebook
  title: text("title").notNull().default(""),
  description: text("description").notNull().default(""),
  hashtags: jsonb("hashtags").$type<string[]>().notNull().default([]),
  thumbAssetId: uuid("thumb_asset_id"),
  scheduledAt: timestamp("scheduled_at"),
  status: text("status").notNull().default("draft"), // draft | scheduled | published
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const chatMessages = pgTable("chat_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  projectId: uuid("project_id").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  refs: jsonb("refs").$type<{ t: number; text: string }[]>().notNull().default([]),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
