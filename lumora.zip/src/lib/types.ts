// Tipos compartilhados entre cliente e servidor.

export type Word = { start: number; end: number; text: string };
export type Segment = { start: number; end: number; text: string; speaker?: string; words?: Word[] };

/** Retângulo em frações (0..1) do quadro original. */
export type Rect = { x: number; y: number; w: number; h: number };

export type LayoutMode = "fit" | "A" | "B" | "C" | "D";
export type LayoutConfig = {
  mode: LayoutMode;
  cam: Rect | null;
  game: Rect | null;
  /** Foco horizontal (0..1) usado nos layouts C e D. */
  focusX: number;
  /** Keyframes do layout D (t relativo ao início do corte, x 0..1). */
  focus: { t: number; x: number }[];
};

export type HookOption = {
  text: string;
  approach: string;
  source: "template" | "llm";
  recommended?: boolean;
};

export type HookConfig = {
  enabled: boolean;
  text: string;
  start: number;
  duration: number;
  color: string;
  accent: string;
  font: "Anton" | "Poppins";
  size: number;
  animation: "pop" | "fade" | "slide" | "none";
  yPct: number;
  outline: boolean;
};

export type CaptionWord = { text: string; start: number; end: number; hl?: boolean };
export type Caption = { start: number; end: number; words: CaptionWord[] };

export type CaptionPreset = "viral" | "podcast" | "dinamico" | "minimalista" | "personalizado";
export type CaptionStyle = {
  preset: CaptionPreset;
  enabled: boolean;
  font: "Anton" | "Poppins";
  size: number;
  color: string;
  highlight: string;
  outline: number;
  shadow: number;
  bg: boolean;
  yPct: number;
  animation: boolean;
  uppercase: boolean;
  wordsPerLine: number;
};

export type AudioFx = {
  denoise: boolean;
  normalize: boolean;
  voice: boolean;
  fade: boolean;
  musicAssetId: string | null;
  musicVolume: number;
};

export type EditorElement = {
  id: string;
  type: "text" | "rect" | "image";
  text?: string;
  assetId?: string;
  start: number;
  end: number;
  /** posição central em % da tela 1080x1920 */
  x: number;
  y: number;
  w?: number;
  h?: number;
  size?: number;
  color?: string;
};

export type ScoreBreakdown = Record<string, { score: number; why: string }>;

export type JobInfo = {
  id: string;
  type: string;
  status: "queued" | "running" | "done" | "failed" | "canceled";
  progress: number;
  message: string | null;
  error: string | null;
  result: unknown;
  projectId: string | null;
  createdAt: string;
  updatedAt: string;
};

export const CLIP_MIN = 60;
export const CLIP_MAX = 90;
/** Margem de planejamento: janelas planejadas ficam dentro de [60.5, 89.5] para absorver arredondamentos do encoder. */
export const PLAN_MIN = 60.5;
export const PLAN_MAX = 89.5;

export const defaultLayout = (): LayoutConfig => ({ mode: "fit", cam: null, game: null, focusX: 0.5, focus: [] });

export const defaultHook = (): HookConfig => ({
  enabled: true,
  text: "",
  start: 0.3,
  duration: 3,
  color: "#FFFFFF",
  accent: "#FFE14D",
  font: "Anton",
  size: 80,
  animation: "pop",
  yPct: 4,
  outline: true,
});

export const captionPresets: Record<CaptionPreset, CaptionStyle> = {
  viral: { preset: "viral", enabled: true, font: "Anton", size: 88, color: "#FFFFFF", highlight: "#39FF88", outline: 7, shadow: 3, bg: false, yPct: 70, animation: true, uppercase: true, wordsPerLine: 3 },
  podcast: { preset: "podcast", enabled: true, font: "Poppins", size: 58, color: "#FFFFFF", highlight: "#FFE14D", outline: 4, shadow: 2, bg: false, yPct: 76, animation: false, uppercase: false, wordsPerLine: 6 },
  dinamico: { preset: "dinamico", enabled: true, font: "Anton", size: 120, color: "#FFFFFF", highlight: "#7C5CFF", outline: 8, shadow: 3, bg: false, yPct: 66, animation: true, uppercase: true, wordsPerLine: 1 },
  minimalista: { preset: "minimalista", enabled: true, font: "Poppins", size: 52, color: "#FFFFFF", highlight: "#FFFFFF", outline: 3, shadow: 3, bg: false, yPct: 82, animation: false, uppercase: false, wordsPerLine: 7 },
  personalizado: { preset: "personalizado", enabled: true, font: "Poppins", size: 64, color: "#FFFFFF", highlight: "#4DD2FF", outline: 5, shadow: 2, bg: true, yPct: 72, animation: true, uppercase: false, wordsPerLine: 4 },
};

export const defaultAudioFx = (): AudioFx => ({ denoise: false, normalize: true, voice: false, fade: true, musicAssetId: null, musicVolume: 0.15 });

export function fmtTime(s: number): string {
  const t = Math.max(0, Math.round(s));
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const sec = t % 60;
  return (h ? `${h}:${String(m).padStart(2, "0")}` : String(m)) + `:${String(sec).padStart(2, "0")}`;
}

/** Posição vertical (%) segura das legendas por layout, para não cobrir a webcam/gameplay. */
export const safeCaptionY = (mode: LayoutMode): number | null => (mode === "A" ? 88 : mode === "B" ? 92 : mode === "C" ? 88 : null);
