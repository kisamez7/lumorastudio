"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import type { JobInfo } from "./types";

export async function api<T = unknown>(url: string, init?: RequestInit): Promise<T> {
  const r = await fetch(url, { ...init, headers: { "content-type": "application/json", ...(init?.headers || {}) } });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((j as { error?: string }).error || `Erro ${r.status}`);
  return j as T;
}
export const post = <T = unknown>(url: string, body?: unknown) => api<T>(url, { method: "POST", body: JSON.stringify(body ?? {}) });
export const patch = <T = unknown>(url: string, body?: unknown) => api<T>(url, { method: "PATCH", body: JSON.stringify(body ?? {}) });
export const put = <T = unknown>(url: string, body?: unknown) => api<T>(url, { method: "PUT", body: JSON.stringify(body ?? {}) });
export const del = <T = unknown>(url: string) => api<T>(url, { method: "DELETE" });

export function uploadFile<T = unknown>(url: string, file: File, onProgress?: (p: number) => void): { promise: Promise<T>; abort: () => void } {
  const xhr = new XMLHttpRequest();
  const promise = new Promise<T>((resolve, reject) => {
    xhr.open("PUT", url);
    xhr.setRequestHeader("content-type", file.type || "application/octet-stream");
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress?.(e.loaded / e.total);
    xhr.onload = () => {
      let j: { error?: string } = {};
      try { j = JSON.parse(xhr.responseText); } catch {}
      if (xhr.status >= 200 && xhr.status < 300) resolve(j as T);
      else reject(new Error(j.error || `Falha no upload (${xhr.status})`));
    };
    xhr.onerror = () => reject(new Error("Falha de rede durante o upload."));
    xhr.onabort = () => reject(new Error("Upload cancelado."));
    xhr.send(file);
  });
  return { promise, abort: () => xhr.abort() };
}

export const fmtBytes = (n: number) => (n > 1073741824 ? (n / 1073741824).toFixed(2) + " GB" : n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.round(n / 1024) + " KB");

/** Acompanha uma tarefa por SSE (progresso real vindo do servidor). */
export function useJob(onDone?: (j: JobInfo) => void) {
  const [job, setJob] = useState<JobInfo | null>(null);
  const esRef = useRef<EventSource | null>(null);
  const cb = useRef(onDone);
  cb.current = onDone;
  const track = useCallback((jobId: string) => {
    esRef.current?.close();
    setJob({ id: jobId, type: "", status: "queued", progress: 0, message: "Na fila", error: null, result: null, projectId: null, createdAt: "", updatedAt: "" });
    const es = new EventSource(`/api/jobs/${jobId}/stream`);
    esRef.current = es;
    es.onmessage = (m) => {
      const j = JSON.parse(m.data) as JobInfo;
      if ((j as unknown as { error?: string }).error === "not-found") { es.close(); return; }
      setJob(j);
      if (["done", "failed", "canceled"].includes(j.status)) { es.close(); cb.current?.(j); }
    };
    es.onerror = () => { /* reconexão automática do EventSource */ };
  }, []);
  const cancel = useCallback(async () => { if (job) await post(`/api/jobs/${job.id}/cancel`); }, [job]);
  useEffect(() => () => esRef.current?.close(), []);
  const running = !!job && (job.status === "queued" || job.status === "running");
  return { job, track, cancel, running, reset: () => setJob(null) };
}

/** Salvamento automático com debounce. */
export function useAutosave<T>(value: T, save: (v: T) => Promise<unknown>, enabled: boolean, delay = 900) {
  const [state, setState] = useState<"idle" | "saving" | "saved" | "error">("idle");
  const saveRef = useRef(save);
  saveRef.current = save;
  useEffect(() => {
    if (!enabled) return;
    setState("saving");
    const t = setTimeout(() => saveRef.current(value).then(() => setState("saved")).catch(() => setState("error")), delay);
    return () => clearTimeout(t);
  }, [value, enabled, delay]);
  return state;
}

/** Aguarda uma tarefa por polling, reportando progresso real. */
export async function waitJob(jobId: string, onUpdate?: (j: JobInfo) => void): Promise<JobInfo> {
  for (;;) {
    const j = await api<JobInfo>(`/api/jobs/${jobId}`);
    onUpdate?.(j);
    if (["done", "failed", "canceled"].includes(j.status)) return j;
    await new Promise((r) => setTimeout(r, 1200));
  }
}
