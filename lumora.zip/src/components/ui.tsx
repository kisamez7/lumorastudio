"use client";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { Loader2, X } from "lucide-react";
import type { JobInfo } from "@/lib/types";

export function Card({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`glass rounded-2xl p-5 ${className}`}>{children}</div>;
}

export function PageHeader({ title, subtitle, icon, actions }: { title: string; subtitle?: string; icon?: ReactNode; actions?: ReactNode }) {
  return (
    <div className="rise mb-6 flex flex-wrap items-start justify-between gap-4">
      <div className="flex items-start gap-3">
        {icon && <div className="grad-bg grid size-11 shrink-0 place-items-center rounded-xl text-white shadow-lg shadow-violet-500/20">{icon}</div>}
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">{title}</h1>
          {subtitle && <p className="mt-1 max-w-2xl text-sm text-zinc-400">{subtitle}</p>}
        </div>
      </div>
      {actions}
    </div>
  );
}

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" | "danger" | "soft"; size?: "sm" | "md"; loading?: boolean };
export function Btn({ variant = "soft", size = "md", loading, className = "", children, disabled, ...p }: BtnProps) {
  const v = {
    primary: "grad-bg text-white shadow-lg shadow-violet-500/20 hover:brightness-110",
    soft: "bg-white/[0.06] text-zinc-100 hover:bg-white/[0.11] border border-white/10",
    ghost: "text-zinc-300 hover:bg-white/[0.07]",
    danger: "bg-rose-500/15 text-rose-300 hover:bg-rose-500/25 border border-rose-500/20",
  }[variant];
  return (
    <button {...p} disabled={disabled || loading} className={`inline-flex items-center justify-center gap-2 rounded-xl font-medium transition active:scale-[0.97] disabled:cursor-not-allowed disabled:opacity-50 ${size === "sm" ? "px-3 py-1.5 text-xs" : "px-4 py-2.5 text-sm"} ${v} ${className}`}>
      {loading && <Loader2 className="size-4 animate-spin" />}
      {children}
    </button>
  );
}

export function Badge({ children, tone = "zinc" }: { children: ReactNode; tone?: "zinc" | "violet" | "green" | "amber" | "rose" | "blue" }) {
  const t = { zinc: "bg-white/[0.07] text-zinc-300", violet: "bg-violet-500/15 text-violet-300", green: "bg-emerald-500/15 text-emerald-300", amber: "bg-amber-500/15 text-amber-300", rose: "bg-rose-500/15 text-rose-300", blue: "bg-blue-500/15 text-blue-300" }[tone];
  return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[11px] font-medium ${t}`}>{children}</span>;
}

export function Progress({ value }: { value: number }) {
  return (
    <div className="h-2 w-full overflow-hidden rounded-full bg-white/[0.07]">
      <div className="grad-bg h-full rounded-full transition-all duration-500" style={{ width: `${Math.max(2, Math.min(100, value))}%` }} />
    </div>
  );
}

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block text-xs text-zinc-400">
      <span className="mb-1.5 block font-medium">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11px] text-zinc-500">{hint}</span>}
    </label>
  );
}

export const inputCls = "w-full rounded-xl border border-white/10 bg-black/30 px-3 py-2.5 text-sm text-zinc-100 outline-none transition placeholder:text-zinc-600 focus:border-violet-400/60 focus:ring-2 focus:ring-violet-500/20";

export function JobBar({ job, onCancel }: { job: JobInfo | null; onCancel?: () => void }) {
  if (!job) return null;
  const active = job.status === "queued" || job.status === "running";
  return (
    <div className={`rise rounded-xl border p-3 text-sm ${job.status === "failed" ? "border-rose-500/30 bg-rose-500/10" : job.status === "done" ? "border-emerald-500/30 bg-emerald-500/10" : "border-white/10 bg-white/[0.04]"}`}>
      <div className="mb-2 flex items-center justify-between gap-3">
        <span className="flex items-center gap-2 text-zinc-200">
          {active && <Loader2 className="size-4 animate-spin text-violet-300" />}
          {job.status === "failed" ? "Falhou" : job.status === "canceled" ? "Cancelado" : job.message || "Processando"}
        </span>
        <span className="flex items-center gap-2 text-xs text-zinc-400">
          {job.progress}%
          {active && onCancel && <button onClick={onCancel} className="inline-flex items-center gap-1 rounded-lg bg-white/10 px-2 py-1 text-zinc-200 hover:bg-white/20"><X className="size-3" />Cancelar</button>}
        </span>
      </div>
      {active && <Progress value={job.progress} />}
      {job.error && <p className="mt-2 text-xs text-rose-300">{job.error}</p>}
    </div>
  );
}

export function Empty({ title, children, icon }: { title: string; children?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="grid place-items-center rounded-2xl border border-dashed border-white/10 px-6 py-14 text-center">
      {icon && <div className="mb-3 text-zinc-500">{icon}</div>}
      <p className="font-medium text-zinc-200">{title}</p>
      {children && <div className="mt-2 max-w-md text-sm text-zinc-500">{children}</div>}
    </div>
  );
}

export function Notice({ tone = "amber", children }: { tone?: "amber" | "blue" | "rose"; children: ReactNode }) {
  const t = { amber: "border-amber-500/25 bg-amber-500/10 text-amber-200", blue: "border-blue-500/25 bg-blue-500/10 text-blue-200", rose: "border-rose-500/25 bg-rose-500/10 text-rose-200" }[tone];
  return <div className={`rounded-xl border px-3.5 py-2.5 text-xs leading-relaxed ${t}`}>{children}</div>;
}
