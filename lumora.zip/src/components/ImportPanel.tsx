"use client";
import Link from "next/link";
import { useRef, useState, type ReactNode } from "react";
import { FileVideo, Link2, Replace, Trash2, UploadCloud, ShieldAlert, CheckCircle2 } from "lucide-react";
import { del, fmtBytes, post, uploadFile, useJob } from "@/lib/client";
import { fmtTime } from "@/lib/types";
import { Badge, Btn, Card, Empty, inputCls, JobBar, Notice, Progress } from "./ui";
import { useProject, type ProjectFull } from "./ProjectContext";

type Probe = { platform: { name: string }; supported: boolean; status: string; reason: string; title?: string; thumbnail?: string; author?: string; official?: string; size?: number | null; filename?: string };

export function SourceCard({ project, onChange }: { project: ProjectFull; onChange: () => void }) {
  const s = project.source!;
  const [busy, setBusy] = useState(false);
  return (
    <Card className="rise">
      <div className="grid gap-5 md:grid-cols-[minmax(0,360px)_1fr]">
        <video src={s.url} controls preload="metadata" className="aspect-video w-full rounded-xl bg-black object-contain" />
        <div className="min-w-0">
          <div className="mb-3 flex items-center gap-2"><CheckCircle2 className="size-5 text-emerald-400" /><h3 className="truncate font-medium">{s.filename}</h3></div>
          <dl className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
            {[["Tamanho", fmtBytes(s.sizeBytes)], ["Duração", s.durationSec ? fmtTime(s.durationSec) : "—"], ["Resolução", s.width ? `${s.width}×${s.height}` : "—"], ["Formato", `${s.format ?? "—"} · ${s.fps ?? "?"} fps`], ["Origem", project.sourceType === "url" ? "Link" : "Upload"], ["Áudio", s.hasAudio ? "Sim" : "Não"]].map(([k, v]) => (
              <div key={k}><dt className="text-[11px] uppercase tracking-wider text-zinc-500">{k}</dt><dd className="text-zinc-200">{v}</dd></div>
            ))}
          </dl>
          <p className="mt-3 text-xs text-zinc-500">Metadados lidos com FFprobe. Upload e link usam exatamente o mesmo pipeline.</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <Btn size="sm" variant="danger" loading={busy} onClick={async () => { setBusy(true); await del(`/api/projects/${project.id}/source`); setBusy(false); onChange(); }}><Trash2 className="size-3.5" />Remover arquivo</Btn>
            <span className="self-center text-xs text-zinc-500">Para substituir, remova e envie outro (a análise anterior é descartada).</span>
          </div>
        </div>
      </div>
    </Card>
  );
}

export function ImportPanel({ project, onChange }: { project: ProjectFull; onChange: () => void }) {
  const [tab, setTab] = useState<"upload" | "link">("upload");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [drag, setDrag] = useState(false);
  const [up, setUp] = useState<number | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [url, setUrl] = useState("");
  const [probe, setProbe] = useState<Probe | null>(null);
  const [checking, setChecking] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  const abortRef = useRef<(() => void) | null>(null);
  const { job, track, cancel, running } = useJob((j) => { if (j.status === "done") onChange(); });

  const choose = (f: File | undefined) => {
    setErr(null);
    if (!f) return;
    if (!/\.(mp4|mov|mkv|webm|m4v)$/i.test(f.name)) { setErr("Formato não suportado. Use MP4, MOV, MKV ou WEBM."); return; }
    if (preview) URL.revokeObjectURL(preview);
    setFile(f);
    setPreview(URL.createObjectURL(f));
  };
  const send = async () => {
    if (!file) return;
    setErr(null); setUp(0);
    const u = uploadFile(`/api/projects/${project.id}/source?filename=${encodeURIComponent(file.name)}`, file, setUp);
    abortRef.current = u.abort;
    try { await u.promise; setFile(null); setPreview(null); onChange(); } catch (e) { setErr(e instanceof Error ? e.message : "Falha"); }
    setUp(null);
  };
  const importUrl = async () => {
    setErr(null); setProbe(null); setChecking(true);
    try {
      const p = await post<Probe>("/api/url/probe", { url });
      setProbe(p);
      if (p.supported) track((await post<{ jobId: string }>(`/api/projects/${project.id}/import`, { url })).jobId);
    } catch (e) { setErr(e instanceof Error ? e.message : "Falha"); }
    setChecking(false);
  };

  return (
    <Card className="rise">
      <div className="mb-4 inline-flex rounded-xl bg-black/40 p-1 text-sm">
        {([["upload", "Enviar arquivo", UploadCloud], ["link", "Importar por link", Link2]] as const).map(([k, l, I]) => (
          <button key={k} onClick={() => setTab(k)} className={`flex items-center gap-2 rounded-lg px-4 py-2 transition ${tab === k ? "bg-white/10 text-white" : "text-zinc-400 hover:text-zinc-200"}`}><I className="size-4" />{l}</button>
        ))}
      </div>
      {tab === "upload" ? (
        <div>
          {!file ? (
            <div onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={(e) => { e.preventDefault(); setDrag(false); choose(e.dataTransfer.files[0]); }} onClick={() => input.current?.click()}
              className={`grid cursor-pointer place-items-center rounded-2xl border-2 border-dashed px-6 py-14 text-center transition ${drag ? "border-violet-400 bg-violet-500/10" : "border-white/10 hover:border-white/25 hover:bg-white/[0.02]"}`}>
              <UploadCloud className="mb-3 size-10 text-violet-300" />
              <p className="font-medium">Arraste e solte o vídeo aqui</p>
              <p className="mt-1 text-sm text-zinc-500">ou clique para selecionar · MP4, MOV, MKV, WEBM</p>
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-[300px_1fr]">
              {preview && <video src={preview} controls className="aspect-video w-full rounded-xl bg-black" />}
              <div>
                <div className="flex items-center gap-2"><FileVideo className="size-5 text-violet-300" /><span className="truncate font-medium">{file.name}</span></div>
                <p className="mt-1 text-sm text-zinc-400">{fmtBytes(file.size)} · {file.type || file.name.split(".").pop()}</p>
                {up !== null && <div className="mt-3 space-y-1"><Progress value={up * 100} /><p className="text-xs text-zinc-500">Enviando… {Math.round(up * 100)}% (grava direto em disco)</p></div>}
                <div className="mt-4 flex flex-wrap gap-2">
                  <Btn variant="primary" onClick={send} disabled={up !== null}>Enviar e preparar</Btn>
                  <Btn onClick={() => input.current?.click()} disabled={up !== null}><Replace className="size-4" />Substituir</Btn>
                  <Btn variant="ghost" onClick={() => { if (up !== null) abortRef.current?.(); setFile(null); setPreview(null); }}><Trash2 className="size-4" />Remover</Btn>
                </div>
              </div>
            </div>
          )}
          <input ref={input} type="file" accept=".mp4,.mov,.mkv,.webm,.m4v,video/*" className="hidden" onChange={(e) => { choose(e.target.files?.[0]); e.target.value = ""; }} />
        </div>
      ) : (
        <div className="space-y-3">
          <div className="flex flex-col gap-2 sm:flex-row">
            <input className={inputCls} placeholder="Cole aqui o link do vídeo (URL direta de .mp4/.webm ou de uma plataforma)" value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === "Enter" && url && importUrl()} />
            <Btn variant="primary" onClick={importUrl} loading={checking} disabled={!url || running} className="shrink-0">Importar vídeo</Btn>
          </div>
          <Notice tone="blue">Importamos URLs <b>diretas</b> de mídia com download seguro (anti-SSRF, limites de tamanho/duração). Plataformas como YouTube, TikTok, Instagram, Facebook, Twitch, Vimeo e X não oferecem importação direta autorizada: não contornamos DRM, login nem proteções — nesses casos use o upload manual.</Notice>
          {probe && !probe.supported && (
            <div className="rise rounded-xl border border-amber-500/30 bg-amber-500/10 p-4 text-sm">
              <div className="mb-2 flex items-center gap-2"><ShieldAlert className="size-5 text-amber-300" /><b>{probe.platform.name}</b><Badge tone="amber">importação direta indisponível</Badge></div>
              <div className="flex gap-3">
                {probe.thumbnail && /* eslint-disable-next-line @next/next/no-img-element */ <img src={probe.thumbnail} alt="" className="h-20 rounded-lg object-cover" />}
                <div><p className="text-amber-100">{probe.reason}</p>{probe.title && <p className="mt-1 text-zinc-300">“{probe.title}” {probe.author && <span className="text-zinc-500">— {probe.author}</span>}</p>}{probe.official && <p className="mt-1 text-xs text-zinc-400">Método oficial: {probe.official}</p>}</div>
              </div>
              <Btn size="sm" className="mt-3" onClick={() => setTab("upload")}>Enviar arquivo manualmente</Btn>
            </div>
          )}
          {probe?.supported && <p className="text-xs text-emerald-300">✓ {probe.platform.name}: {probe.reason}</p>}
          <JobBar job={job} onCancel={cancel} />
        </div>
      )}
      {err && <div className="mt-3"><Notice tone="rose">{err}</Notice></div>}
    </Card>
  );
}

/** Garante projeto + vídeo antes de exibir uma ferramenta. */
export function RequireProject({ children, needSource = true }: { children: (p: ProjectFull) => ReactNode; needSource?: boolean }) {
  const { project, loading, reload } = useProject();
  if (loading) return <div className="shimmer h-40 rounded-2xl" />;
  if (!project) return <Empty title="Nenhum projeto selecionado" icon={<FileVideo className="size-10" />}><p>Selecione um projeto no menu lateral ou crie um novo.</p><Link href="/new" className="grad-bg mt-4 inline-block rounded-xl px-4 py-2 text-sm font-medium text-white">Novo projeto</Link></Empty>;
  if (needSource && !project.source) return <div className="space-y-4"><Notice tone="blue">O projeto “{project.name}” ainda não tem vídeo. Envie um arquivo ou importe por link.</Notice><ImportPanel project={project} onChange={reload} /></div>;
  return <>{children(project)}</>;
}
