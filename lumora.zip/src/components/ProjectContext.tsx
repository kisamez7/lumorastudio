"use client";
import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { api } from "@/lib/client";

export type AssetDto = { id: string; projectId: string | null; kind: string; filename: string; mime: string | null; sizeBytes: number; durationSec: number | null; width: number | null; height: number | null; fps: number | null; format: string | null; hasAudio: boolean | null; meta: Record<string, unknown>; createdAt: string; url: string };
export type ProjectLite = { id: string; name: string; kind: string; status: string; sourceType: string | null; sourceUrl: string | null; createdAt: string; updatedAt: string; source: AssetDto | null; clipCount: number; renderedCount: number; settings: Record<string, unknown> };
export type ProjectFull = Omit<ProjectLite, "source" | "clipCount" | "renderedCount"> & { source: AssetDto | null; transcript: { engine: string; language: string } | null; analysis: { status: string; coverage: Record<string, unknown> | null; hasSummary: boolean; hasMindmap: boolean } | null };

type Ctx = { projects: ProjectLite[]; currentId: string | null; project: ProjectFull | null; setCurrent: (id: string | null) => void; reload: () => Promise<void>; loading: boolean };
const C = createContext<Ctx>({ projects: [], currentId: null, project: null, setCurrent: () => {}, reload: async () => {}, loading: true });
export const useProject = () => useContext(C);

export function ProjectProvider({ children }: { children: ReactNode }) {
  const [projects, setProjects] = useState<ProjectLite[]>([]);
  const [currentId, setId] = useState<string | null>(null);
  const [project, setProject] = useState<ProjectFull | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => { setId(localStorage.getItem("lumora.project")); }, []);

  const reload = useCallback(async () => {
    try {
      const list = await api<ProjectLite[]>("/api/projects");
      setProjects(list);
      const id = localStorage.getItem("lumora.project");
      if (id && list.some((p) => p.id === id)) setProject(await api<ProjectFull>(`/api/projects/${id}`));
      else { setProject(null); if (id) { localStorage.removeItem("lumora.project"); setId(null); } }
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { void reload(); }, [reload, currentId]);

  const setCurrent = useCallback((id: string | null) => {
    if (id) localStorage.setItem("lumora.project", id); else localStorage.removeItem("lumora.project");
    setId(id);
  }, []);

  return <C.Provider value={{ projects, currentId, project, setCurrent, reload, loading }}>{children}</C.Provider>;
}
