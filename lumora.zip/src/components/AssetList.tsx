"use client";
import { useCallback, useEffect, useState } from "react";
import { Download, Trash2 } from "lucide-react";
import { api, del, fmtBytes } from "@/lib/client";
import { Badge, Btn, Card, Empty } from "@/components/ui";
import type { AssetDto } from "@/components/ProjectContext";
import { fmtTime } from "@/lib/types";

const KINDS = ["", "source", "clip", "compilation", "download", "audio", "image", "music", "export"];

export function AssetList({ kinds, empty }: { kinds?: string; empty?: string }) {
  const [rows, setRows] = useState<AssetDto[]>([]);
  const [kind, setKind] = useState("");
  const load = useCallback(() => api<AssetDto[]>(`/api/assets?kind=${kinds ?? kind}`).then(setRows).catch(() => {}), [kinds, kind]);
  useEffect(() => { void load(); }, [load]);
  return (
    <div className="space-y-4">
      {!kinds && <div className="flex flex-wrap gap-2">{KINDS.map((k) => <button key={k} onClick={() => setKind(k)} className={`rounded-full px-3 py-1 text-xs ${kind === k ? "bg-violet-500/25 text-violet-200" : "bg-white/[0.06] text-zinc-400 hover:bg-white/10"}`}>{k || "todos"}</button>)}</div>}
      {!rows.length ? <Empty title={empty || "Nenhum arquivo"} /> : (
        <div className="grid gap-3 md:grid-cols-2">
          {rows.map((a) => (
            <Card key={a.id} className="flex items-center gap-4 !p-4">
              {a.mime?.startsWith("video") ? <video src={`${a.url}#t=0.5`} preload="metadata" muted className="h-16 w-28 shrink-0 rounded-lg bg-black object-cover" /> : a.mime?.startsWith("image") ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={a.url} alt="" className="h-16 w-28 shrink-0 rounded-lg object-cover" /> : <div className="grid h-16 w-28 shrink-0 place-items-center rounded-lg bg-white/5 text-xs text-zinc-500">{a.format}</div>}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{a.filename}</p>
                <div className="mt-1 flex flex-wrap items-center gap-1.5 text-[11px] text-zinc-500"><Badge>{a.kind}</Badge>{fmtBytes(a.sizeBytes)}{a.durationSec ? ` · ${fmtTime(a.durationSec)}` : ""}{a.width ? ` · ${a.width}×${a.height}` : ""}</div>
              </div>
              <div className="flex flex-col gap-1.5">
                <a href={`${a.url}?download=1`}><Btn size="sm" variant="primary"><Download className="size-3.5" /></Btn></a>
                <Btn size="sm" variant="danger" onClick={async () => { if (!confirm("Excluir arquivo?")) return; try { await del(`/api/assets/${a.id}`); load(); } catch (e) { alert(e instanceof Error ? e.message : "Erro"); } }}><Trash2 className="size-3.5" /></Btn>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

