"use client";
import { useRef, useState } from "react";
import type { Rect } from "@/lib/types";

/** Seleção de região sobre um quadro do vídeo (arraste para desenhar). Coordenadas em frações 0..1. */
export function RectPicker({ src, value, onChange, color = "#2dd4a0", label }: { src: string; value: Rect | null; onChange: (r: Rect | null) => void; color?: string; label?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const [drag, setDrag] = useState<{ x: number; y: number } | null>(null);
  const [tmp, setTmp] = useState<Rect | null>(null);
  const pos = (e: React.PointerEvent) => {
    const b = ref.current!.getBoundingClientRect();
    return { x: Math.min(1, Math.max(0, (e.clientX - b.left) / b.width)), y: Math.min(1, Math.max(0, (e.clientY - b.top) / b.height)) };
  };
  const r = tmp ?? value;
  return (
    <div>
      <div ref={ref} className="relative cursor-crosshair select-none overflow-hidden rounded-xl bg-black"
        onPointerDown={(e) => { (e.target as HTMLElement).setPointerCapture?.(e.pointerId); setDrag(pos(e)); }}
        onPointerMove={(e) => { if (!drag) return; const p = pos(e); setTmp({ x: Math.min(drag.x, p.x), y: Math.min(drag.y, p.y), w: Math.abs(p.x - drag.x), h: Math.abs(p.y - drag.y) }); }}
        onPointerUp={() => { if (tmp && tmp.w > 0.03 && tmp.h > 0.03) onChange(tmp); setTmp(null); setDrag(null); }}>
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={src} alt="Quadro do vídeo" draggable={false} className="block w-full" />
        {r && <div className="pointer-events-none absolute border-2" style={{ left: `${r.x * 100}%`, top: `${r.y * 100}%`, width: `${r.w * 100}%`, height: `${r.h * 100}%`, borderColor: color, background: color + "22" }}><span className="absolute -top-5 left-0 rounded px-1 text-[10px] font-medium text-black" style={{ background: color }}>{label}</span></div>}
      </div>
      <div className="mt-2 flex items-center justify-between text-xs text-zinc-500"><span>{value ? `x ${(value.x * 100).toFixed(0)}% · y ${(value.y * 100).toFixed(0)}% · ${(value.w * 100).toFixed(0)}×${(value.h * 100).toFixed(0)}%` : "Arraste sobre a imagem para marcar a região"}</span>{value && <button className="text-rose-300 hover:underline" onClick={() => onChange(null)}>limpar</button>}</div>
    </div>
  );
}
