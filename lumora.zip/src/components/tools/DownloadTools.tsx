"use client";
import { useEffect, useState } from "react";
import { AudioLines, Download, FolderDown, RefreshCw, ShieldAlert } from "lucide-react";
import { api, fmtBytes, post, useJob, waitJob } from "@/lib/client";
import { fmtTime } from "@/lib/types";
import { Badge, Btn, Card, Field, inputCls, JobBar, Notice, PageHeader } from "../ui";
import type { AssetDto } from "../ProjectContext";
import { AssetList } from "../AssetList";

type Probe = { platform: { name: string; direct: boolean }; supported: boolean; status: string; reason: string; contentType?: string; size?: number | null; filename?: string; title?: string; thumbnail?: string; author?: string; official?: string };
const META: Record<string, [string, string, React.ReactNode]> = {
  downloader: ["Baixar vídeos", "Cole um link, veja o que a fonte realmente oferece e baixe MP4/MP3 de mídias que você tem autorização para usar.", <Download key="i" className="size-5" />],
  converter: ["Conversor de vídeos", "Converta para MP4/WebM sem ampliar a resolução original.", <RefreshCw key="i" className="size-5" />],
  "audio-extract": ["Extração de áudio", "Extraia o áudio de qualquer arquivo da plataforma em MP3 ou WAV.", <AudioLines key="i" className="size-5" />],
  downloads: ["Arquivos baixados", "Mídias baixadas e convertidas, prontas para download no computador ou celular.", <FolderDown key="i" className="size-5" />],
};

export function DownloadTool({ tool }: { tool: string }) {
  const m = META[tool];
  return (
    <div>
      <PageHeader title={m[0]} subtitle={m[1]} icon={m[2]} />
      {tool === "downloader" && <Downloader />}
      {tool === "converter" && <Converter mode="convert" />}
      {tool === "audio-extract" && <Converter mode="audio" />}
      {tool === "downloads" && <AssetList kinds="download,audio,export" empty="Nada baixado ainda" />}
    </div>
  );
}

function Downloader() {
  const [url, setUrl] = useState(""); const [rights, setRights] = useState(false);
  const [probe, setProbe] = useState<Probe | null>(null); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  const [asset, setAsset] = useState<AssetDto | null>(null);
  const [conv, setConv] = useState<{ id: string; label: string; url?: string; err?: string }[]>([]);
  const { job, track, cancel } = useJob(async (j) => { if (j.status === "done") setAsset(await api<AssetDto[]>("/api/assets?kind=download").then((l) => l.find((a) => a.id === (j.result as { assetId: string }).assetId) ?? null)); });
  const search = async () => { setBusy(true); setErr(""); setProbe(null); setAsset(null); setConv([]); try { setProbe(await post<Probe>("/api/url/probe", { url })); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); } setBusy(false); };
  const start = async () => { try { track((await post<{ jobId: string }>("/api/downloads", { url, rights })).jobId); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); } };
  const convert = async (a: AssetDto, o: { format: string; height?: number }, label: string) => {
    const key = `${o.format}${o.height ?? ""}`; setConv((c) => [...c.filter((x) => x.id !== key), { id: key, label }]);
    try { const r = await post<{ jobId: string }>(`/api/assets/${a.id}/convert`, o); const j = await waitJob(r.jobId); setConv((c) => c.map((x) => (x.id === key ? { ...x, url: j.status === "done" ? `/api/assets/${(j.result as { assetId: string }).assetId}?download=1` : undefined, err: j.error ?? undefined } : x))); } catch (e) { setConv((c) => c.map((x) => (x.id === key ? { ...x, err: e instanceof Error ? e.message : "Erro" } : x))); }
  };
  const heights = asset?.height ? [2160, 1440, 1080, 720, 480].filter((h) => h <= asset.height! - 8 || h === asset.height) : [];
  useEffect(() => { void 0; }, []);
  return (
    <div className="space-y-5">
      <Card>
        <div className="flex flex-col gap-2 sm:flex-row"><input className={inputCls} placeholder="Cole o link do vídeo ou arquivo de mídia" value={url} onChange={(e) => setUrl(e.target.value)} onKeyDown={(e) => e.key === "Enter" && url && search()} /><Btn variant="primary" onClick={search} loading={busy} disabled={!url} className="shrink-0">Buscar vídeo</Btn></div>
        <label className="mt-3 flex items-start gap-2 text-xs text-zinc-400"><input type="checkbox" className="mt-0.5 accent-violet-500" checked={rights} onChange={(e) => setRights(e.target.checked)} />Declaro que tenho os direitos ou a autorização necessária para baixar e usar este conteúdo.</label>
        <div className="mt-3"><Notice tone="blue">Compatibilidade depende de métodos autorizados: baixamos <b>URLs diretas</b> de arquivos (mp4, webm, mov, mkv, mp3…). Não removemos marcas d’água, logos ou atribuições, e não contornamos DRM, login ou proteções. Só oferecemos resoluções que existem no arquivo original — nunca ampliamos para “4K”.</Notice></div>
        {err && <div className="mt-3"><Notice tone="rose">{err}</Notice></div>}
      </Card>
      {probe && (
        <Card className="rise">
          <div className="flex flex-wrap items-center gap-2"><b>{probe.platform.name}</b>{probe.supported ? <Badge tone="green">disponível</Badge> : <Badge tone="amber">{probe.status === "platform-restricted" ? "importação direta indisponível" : probe.status === "not-media" ? "não é arquivo de mídia" : "indisponível"}</Badge>}</div>
          <div className="mt-3 flex gap-4">
            {probe.thumbnail && /* eslint-disable-next-line @next/next/no-img-element */ <img src={probe.thumbnail} alt="" className="h-24 rounded-lg object-cover" />}
            <div className="text-sm"><p className="text-zinc-300">{probe.reason}</p>{probe.title && <p className="mt-1">“{probe.title}” <span className="text-zinc-500">{probe.author}</span></p>}{probe.filename && <p className="mt-1 text-zinc-400">{probe.filename} · {probe.contentType}{probe.size ? ` · ${fmtBytes(probe.size)}` : ""}</p>}{probe.official && <p className="mt-2 flex items-start gap-1.5 text-xs text-amber-200"><ShieldAlert className="mt-0.5 size-4 shrink-0" />Método oficial: {probe.official} Depois, envie o arquivo em Novo projeto.</p>}</div>
          </div>
          {probe.supported && <Btn variant="primary" className="mt-4" onClick={start} disabled={!rights || (!!job && job.status === "running")}>Baixar arquivo</Btn>}
          {probe.supported && !rights && <p className="mt-2 text-xs text-zinc-500">Confirme os direitos para habilitar o download.</p>}
          <div className="mt-3"><JobBar job={job} onCancel={cancel} /></div>
        </Card>
      )}
      {asset && (
        <Card className="rise">
          <h3 className="mb-3 font-medium">Arquivo obtido</h3>
          {asset.mime?.startsWith("video") && <video src={asset.url} controls className="mb-3 max-h-60 rounded-xl bg-black" />}
          <p className="text-sm text-zinc-300">{asset.filename} · {fmtBytes(asset.sizeBytes)}{asset.durationSec ? ` · ${fmtTime(asset.durationSec)}` : ""}{asset.width ? ` · ${asset.width}×${asset.height} (original)` : ""}</p>
          <div className="mt-4 flex flex-wrap gap-2">
            <a href={`${asset.url}?download=1`}><Btn variant="primary"><Download className="size-4" />Original (melhor qualidade disponível)</Btn></a>
            {asset.hasAudio && <Btn onClick={() => convert(asset, { format: "mp3" }, "MP3")}>Extrair MP3</Btn>}
            {heights.filter((h) => h < (asset.height ?? 0)).map((h) => <Btn key={h} onClick={() => convert(asset, { format: "mp4", height: h }, `MP4 ${h}p`)}>MP4 {h}p</Btn>)}
          </div>
          <p className="mt-2 text-xs text-zinc-500">Resolução máxima real: {asset.height ? `${asset.height}p` : "n/d"}. Imagens e slideshows em ZIP dependem de conectores oficiais da fonte e não estão disponíveis para URLs diretas de vídeo.</p>
          {conv.length > 0 && <ul className="mt-3 space-y-1 text-sm">{conv.map((c) => <li key={c.id} className="flex items-center gap-3">{c.label}: {c.url ? <a className="text-violet-300 underline" href={c.url}>baixar</a> : c.err ? <span className="text-rose-300">{c.err}</span> : <span className="text-zinc-500">convertendo…</span>}</li>)}</ul>}
        </Card>
      )}
    </div>
  );
}

function Converter({ mode }: { mode: "convert" | "audio" }) {
  const [assets, setAssets] = useState<AssetDto[]>([]); const [id, setId] = useState(""); const [format, setFormat] = useState(mode === "audio" ? "mp3" : "mp4"); const [height, setHeight] = useState("");
  const { job, track, cancel, running } = useJob((j) => { if (j.status === "done") setOut((j.result as { assetId: string }).assetId); });
  const [out, setOut] = useState<string | null>(null); const [err, setErr] = useState("");
  useEffect(() => { api<AssetDto[]>("/api/assets?kind=source,download,clip,compilation,audio,export").then((r) => { setAssets(r); if (r[0]) setId(r[0].id); }); }, []);
  const a = assets.find((x) => x.id === id);
  const run = async () => { setErr(""); setOut(null); try { track((await post<{ jobId: string }>(`/api/assets/${id}/convert`, { format, height: height ? Number(height) : undefined })).jobId); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); } };
  return (
    <Card className="space-y-4">
      <Field label="Arquivo de origem"><select className={inputCls} value={id} onChange={(e) => setId(e.target.value)}>{assets.map((x) => <option key={x.id} value={x.id}>{x.filename} ({x.kind}{x.height ? ` · ${x.height}p` : ""})</option>)}</select></Field>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field label="Formato de saída"><select className={inputCls} value={format} onChange={(e) => setFormat(e.target.value)}>{(mode === "audio" ? ["mp3", "wav"] : ["mp4", "webm", "mp3", "wav"]).map((f) => <option key={f}>{f}</option>)}</select></Field>
        {mode === "convert" && (format === "mp4" || format === "webm") && <Field label="Altura (opcional)" hint={a?.height ? `Original: ${a.height}p — só reduzir` : undefined}><select className={inputCls} value={height} onChange={(e) => setHeight(e.target.value)}><option value="">Manter original</option>{[1440, 1080, 720, 480, 360].filter((h) => !a?.height || h < a.height).map((h) => <option key={h} value={h}>{h}p</option>)}</select></Field>}
      </div>
      <Btn variant="primary" onClick={run} disabled={!id || running}>{mode === "audio" ? "Extrair áudio" : "Converter"}</Btn>
      <JobBar job={job} onCancel={cancel} />
      {err && <Notice tone="rose">{err}</Notice>}
      {out && <a href={`/api/assets/${out}?download=1`}><Btn variant="primary"><Download className="size-4" />Baixar resultado</Btn></a>}
      {!assets.length && <p className="text-sm text-zinc-500">Nenhum arquivo disponível. Envie um vídeo em Novo projeto ou baixe um em Downloader.</p>}
    </Card>
  );
}
