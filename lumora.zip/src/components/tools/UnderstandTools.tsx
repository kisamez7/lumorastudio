"use client";
import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import { Brain, Download, FileText, MessageSquare, Network, Search, Scissors, Send, StickyNote, Captions } from "lucide-react";
import { api, del, post, put, useAutosave, useJob } from "@/lib/client";
import { fmtTime, type Segment } from "@/lib/types";
import { Badge, Btn, Card, Empty, inputCls, JobBar, Notice, PageHeader } from "../ui";
import { RequireProject } from "../ImportPanel";
import { useProject, type ProjectFull } from "../ProjectContext";

const META: Record<string, [string, string, React.ReactNode]> = {
  summary: ["Resumo de vídeos", "Resumos curto, detalhado e cronológico, tópicos, acontecimentos e conclusões com marcações de tempo.", <FileText key="i" className="size-5" />],
  transcript: ["Transcrição", "Transcrição integral com busca, edição, marcação de tempo e exportação TXT/SRT.", <Captions key="i" className="size-5" />],
  moments: ["Busca de momentos", "Pesquise situações no vídeo (transcrição + áudio + imagem) e transforme em cortes.", <Search key="i" className="size-5" />],
  chat: ["Chat com vídeos", "Pergunte sobre o conteúdo; respostas baseadas na transcrição, com marcações de tempo.", <MessageSquare key="i" className="size-5" />],
  mindmap: ["Mapas mentais", "Tema central, tópicos e subtópicos extraídos do conteúdo. Exportação SVG/Markdown.", <Network key="i" className="size-5" />],
  notes: ["Anotações", "Notas organizadas por tempo para aulas, palestras e reuniões. Edite e exporte.", <StickyNote key="i" className="size-5" />],
};

export function UnderstandTool({ tool }: { tool: string }) {
  const m = META[tool];
  return (
    <div>
      <PageHeader title={m[0]} subtitle={m[1]} icon={m[2]} />
      <RequireProject>{(p) => (tool === "transcript" ? <TranscriptView project={p} /> : <NeedsTranscript project={p}>{tool === "summary" ? <SummaryView project={p} /> : tool === "moments" ? <MomentsView project={p} /> : tool === "chat" ? <ChatView project={p} /> : tool === "mindmap" ? <MindmapView project={p} /> : <NotesView project={p} />}</NeedsTranscript>)}</RequireProject>
    </div>
  );
}

function NeedsTranscript({ project, children }: { project: ProjectFull; children: React.ReactNode }) {
  if (project.transcript) return <>{children}</>;
  return <Empty title="Este recurso precisa da transcrição" icon={<Brain className="size-10" />}><p>Gere com o Whisper local ou importe um SRT/VTT.</p><Link href="/t/transcript" className="grad-bg mt-4 inline-block rounded-xl px-4 py-2 text-sm font-medium text-white">Ir para Transcrição</Link></Empty>;
}

function download(name: string, text: string, type = "text/plain") {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(new Blob([text], { type: type + ";charset=utf-8" }));
  a.download = name; a.click(); URL.revokeObjectURL(a.href);
}

/* ------------------------------ Transcrição ------------------------------ */
function TranscriptView({ project }: { project: ProjectFull }) {
  const { reload } = useProject();
  const [segs, setSegs] = useState<Segment[]>([]);
  const [q, setQ] = useState("");
  const [lang, setLang] = useState("pt");
  const [srt, setSrt] = useState("");
  const [msg, setMsg] = useState("");
  const [dirty, setDirty] = useState(false);
  const vid = useRef<HTMLVideoElement>(null);
  const load = useCallback(() => api<{ segments: Segment[] }>(`/api/projects/${project.id}/transcript`).then((r) => { setSegs(r.segments); setDirty(false); }), [project.id]);
  useEffect(() => { void load(); }, [load]);
  const { job, track, cancel, running } = useJob((j) => { if (j.status === "done") { void load(); void reload(); } });
  const state = useAutosave(segs, (v) => put(`/api/projects/${project.id}/transcript`, { segments: v }), dirty);
  const hits = q ? segs.filter((s) => s.text.toLowerCase().includes(q.toLowerCase())) : segs;
  const importSrt = async (text: string) => { try { await put(`/api/projects/${project.id}/transcript`, { srt: text }); setMsg("Transcrição importada."); setSrt(""); await load(); await reload(); } catch (e) { setMsg(e instanceof Error ? e.message : "Erro"); } };
  return (
    <div className="space-y-5">
      {project.source && <video ref={vid} src={project.source.url} controls className="max-h-64 rounded-xl bg-black" />}
      <Card>
        <h2 className="mb-3 font-medium">Gerar ou importar</h2>
        <div className="flex flex-wrap items-center gap-3">
          <select className={`${inputCls} !w-44`} value={lang} onChange={(e) => setLang(e.target.value)}>{[["pt", "Português (BR)"], ["en", "English"], ["es", "Español"], ["auto", "Detectar"]].map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
          <Btn variant="primary" disabled={running} onClick={async () => track((await post<{ jobId: string }>(`/api/projects/${project.id}/transcript`, { language: lang })).jobId)}>Transcrever com Whisper local</Btn>
          <label className="cursor-pointer rounded-xl border border-white/10 bg-white/[0.06] px-4 py-2.5 text-sm hover:bg-white/10">Importar SRT/VTT<input type="file" accept=".srt,.vtt,text/*" className="hidden" onChange={async (e) => { const f = e.target.files?.[0]; if (f) await importSrt(await f.text()); e.target.value = ""; }} /></label>
        </div>
        <textarea className={`${inputCls} mt-3 font-mono text-xs`} rows={3} placeholder="…ou cole aqui o conteúdo de um SRT/VTT" value={srt} onChange={(e) => setSrt(e.target.value)} />
        {srt && <Btn size="sm" className="mt-2" onClick={() => importSrt(srt)}>Importar texto colado</Btn>}
        <div className="mt-3"><JobBar job={job} onCancel={cancel} /></div>
        {msg && <div className="mt-3"><Notice tone="blue">{msg}</Notice></div>}
        <p className="mt-3 text-xs text-zinc-500">Whisper roda localmente na CPU (modelo baixado no primeiro uso; vídeos longos levam tempo). Separação de falantes não está disponível (sem diarização).</p>
      </Card>
      {segs.length > 0 && (
        <Card>
          <div className="mb-3 flex flex-wrap items-center gap-3">
            <input className={`${inputCls} max-w-sm`} placeholder="Buscar palavra ou frase…" value={q} onChange={(e) => setQ(e.target.value)} />
            <Badge>{hits.length} / {segs.length} trechos</Badge>
            <Badge tone={state === "saving" ? "amber" : "green"}>{dirty ? (state === "saving" ? "salvando…" : "salvo") : "sem alterações"}</Badge>
            <div className="ml-auto flex gap-2"><a href={`/api/projects/${project.id}/transcript?format=txt`}><Btn size="sm"><Download className="size-3.5" />TXT</Btn></a><a href={`/api/projects/${project.id}/transcript?format=srt`}><Btn size="sm"><Download className="size-3.5" />SRT</Btn></a></div>
          </div>
          <div className="max-h-[560px] space-y-1 overflow-y-auto pr-1">
            {segs.map((s, i) => (!q || s.text.toLowerCase().includes(q.toLowerCase())) && (
              <div key={i} className="group flex items-start gap-3 rounded-lg px-2 py-1.5 hover:bg-white/[0.04]">
                <button className="mt-1 w-12 shrink-0 text-xs tabular-nums text-violet-300 hover:underline" onClick={() => { if (vid.current) { vid.current.currentTime = s.start; void vid.current.play(); } }}>{fmtTime(s.start)}</button>
                <textarea rows={1} value={s.text} onChange={(e) => { const v = e.target.value; setSegs((p) => p.map((x, k) => (k === i ? { ...x, text: v } : x))); setDirty(true); }} className="min-h-0 flex-1 resize-none bg-transparent text-sm text-zinc-200 outline-none focus:bg-black/30" style={{ fieldSizing: "content" } as React.CSSProperties} />
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

/* ------------------------------ Resumo ------------------------------ */
type Summary = { short: string; detailed: string; topics: { name: string; count: number }[]; bullets: { t: number; text: string }[]; chronological: { t: number; text: string }[]; events: { t: number; text: string }[]; conclusions: string[]; engine: string };
const TL = ({ t, text }: { t: number; text: string }) => <li className="flex gap-3 text-sm"><span className="w-12 shrink-0 tabular-nums text-violet-300">{fmtTime(t)}</span><span className="text-zinc-300">{text}</span></li>;

function SummaryView({ project }: { project: ProjectFull }) {
  const [s, setS] = useState<Summary | null>(null);
  const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  useEffect(() => { api<{ summary: Summary | null }>(`/api/projects/${project.id}/understand`).then((r) => setS(r.summary)); }, [project.id]);
  const gen = async () => { setBusy(true); setErr(""); try { setS((await post<{ summary: Summary }>(`/api/projects/${project.id}/understand`, { kind: "summary" })).summary); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); } setBusy(false); };
  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3"><Btn variant="primary" onClick={gen} loading={busy}>{s ? "Gerar novamente" : "Gerar resumo"}</Btn>{s && <Badge tone="violet">{s.engine}</Badge>}</div>
      {err && <Notice tone="rose">{err}</Notice>}
      {s && (
        <div className="grid gap-5 lg:grid-cols-2">
          <Card><h3 className="mb-2 font-medium">Resumo curto</h3><p className="text-sm leading-relaxed text-zinc-300">{s.short}</p></Card>
          <Card><h3 className="mb-2 font-medium">Principais assuntos</h3><div className="flex flex-wrap gap-2">{s.topics.map((t) => <Badge key={t.name} tone="blue">{t.name} · {t.count}</Badge>)}</div></Card>
          <Card className="lg:col-span-2"><h3 className="mb-2 font-medium">Resumo detalhado</h3><p className="whitespace-pre-line text-sm leading-relaxed text-zinc-300">{s.detailed}</p></Card>
          <Card><h3 className="mb-3 font-medium">Por tópicos</h3><ul className="space-y-2">{s.bullets.map((b, i) => <TL key={i} {...b} />)}</ul></Card>
          <Card><h3 className="mb-3 font-medium">Cronológico</h3><ul className="space-y-2">{s.chronological.map((b, i) => <TL key={i} {...b} />)}</ul></Card>
          <Card><h3 className="mb-3 font-medium">Principais acontecimentos</h3>{s.events.length ? <ul className="space-y-2">{s.events.map((b, i) => <TL key={i} {...b} />)}</ul> : <p className="text-sm text-zinc-500">Nenhum evento marcante detectado na fala.</p>}</Card>
          <Card><h3 className="mb-3 font-medium">Conclusões</h3><ul className="list-disc space-y-2 pl-5 text-sm text-zinc-300">{s.conclusions.map((c, i) => <li key={i}>{c}</li>)}</ul></Card>
        </div>
      )}
    </div>
  );
}

/* ------------------------------ Find Moments ------------------------------ */
type Hit = { t: number; end: number; text: string; score: number; reason: string; kind: string };
function MomentsView({ project }: { project: ProjectFull }) {
  const [q, setQ] = useState(""); const [hits, setHits] = useState<Hit[] | null>(null); const [busy, setBusy] = useState(false); const [err, setErr] = useState(""); const [done, setDone] = useState<Record<number, string>>({});
  const run = async (query: string) => { setQ(query); setBusy(true); setErr(""); try { setHits((await post<{ hits: Hit[] }>(`/api/projects/${project.id}/find`, { query })).hits); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); } setBusy(false); };
  return (
    <div className="space-y-5">
      <div className="flex gap-2"><input className={inputCls} placeholder="Ex.: encontre todas as risadas · quando alguém menciona dinheiro" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && q && run(q)} /><Btn variant="primary" loading={busy} onClick={() => run(q)} disabled={!q}><Search className="size-4" />Buscar</Btn></div>
      <div className="flex flex-wrap gap-2">{["Encontre todas as risadas", "Encontre as melhores jogadas", "Encontre quando alguém menciona dinheiro", "Encontre os momentos de surpresa", "Encontre os momentos mais engraçados"].map((s) => <button key={s} onClick={() => run(s)} className="rounded-full bg-white/[0.06] px-3 py-1.5 text-xs text-zinc-300 hover:bg-white/10">{s}</button>)}</div>
      {err && <Notice tone="rose">{err}</Notice>}
      {hits && !hits.length && <Empty title="Nada encontrado">Tente outras palavras. A busca usa transcrição, sinais de áudio (volume) e movimento visual.</Empty>}
      <div className="grid gap-4 sm:grid-cols-2">
        {hits?.map((h, i) => (
          <Card key={i} className="rise !p-3"><div className="flex gap-3">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={`/api/projects/${project.id}/frame?t=${Math.floor(h.t)}&w=320`} alt="" loading="lazy" className="h-20 w-36 shrink-0 rounded-lg bg-black object-cover" />
            <div className="min-w-0 flex-1"><div className="flex items-center gap-2"><b className="text-sm text-violet-300">{fmtTime(h.t)}</b><Badge tone={h.kind === "sinal audiovisual" ? "amber" : "blue"}>{h.kind}</Badge></div><p className="mt-1 line-clamp-2 text-sm text-zinc-300">{h.text}</p><p className="mt-1 text-[11px] text-zinc-500">{h.reason}</p></div>
          </div>
            <div className="mt-3 flex items-center gap-2"><Btn size="sm" variant="primary" onClick={async () => { try { await post(`/api/projects/${project.id}/clips`, { around: h.t }); setDone((d) => ({ ...d, [i]: "Corte criado (60–90 s) em Criador de cortes." })); } catch (e) { setDone((d) => ({ ...d, [i]: e instanceof Error ? e.message : "Erro" })); } }}><Scissors className="size-3.5" />Transformar em corte</Btn>{done[i] && <span className="text-xs text-emerald-300">{done[i]}</span>}</div>
          </Card>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------ Chat ------------------------------ */
type Msg = { id?: string; role: string; content: string; refs: { t: number; text: string }[]; engine?: string };
function ChatView({ project }: { project: ProjectFull }) {
  const [msgs, setMsgs] = useState<Msg[]>([]); const [q, setQ] = useState(""); const [busy, setBusy] = useState(false); const end = useRef<HTMLDivElement>(null);
  useEffect(() => { api<Msg[]>(`/api/projects/${project.id}/chat`).then(setMsgs); }, [project.id]);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);
  const ask = async (text: string) => {
    if (!text.trim()) return; setQ(""); setBusy(true); setMsgs((m) => [...m, { role: "user", content: text, refs: [] }]);
    try { const r = await post<Msg>(`/api/projects/${project.id}/chat`, { question: text }); setMsgs((m) => [...m, r]); } catch (e) { setMsgs((m) => [...m, { role: "assistant", content: e instanceof Error ? e.message : "Erro", refs: [] }]); }
    setBusy(false);
  };
  return (
    <Card className="flex h-[640px] flex-col !p-0">
      <div className="flex-1 space-y-4 overflow-y-auto p-5">
        {!msgs.length && <div className="text-sm text-zinc-500"><p className="mb-3">Pergunte sobre o vídeo:</p><div className="flex flex-wrap gap-2">{["Quais são os cinco principais assuntos?", "O que acontece no final?", "Em que momento ocorre a melhor jogada?", "Qual foi a conclusão da conversa?"].map((s) => <button key={s} onClick={() => ask(s)} className="rounded-full bg-white/[0.06] px-3 py-1.5 text-xs text-zinc-300 hover:bg-white/10">{s}</button>)}</div></div>}
        {msgs.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : ""}`}><div className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm ${m.role === "user" ? "grad-bg text-white" : "bg-white/[0.06] text-zinc-200"}`}>
            <p className="whitespace-pre-line">{m.content}</p>
            {m.refs?.length > 0 && m.role !== "user" && <div className="mt-2 flex flex-wrap gap-1.5">{m.refs.map((r, k) => <span key={k} title={r.text} className="rounded bg-black/30 px-1.5 py-0.5 text-[11px] text-violet-300">{fmtTime(r.t)}</span>)}</div>}
            {m.engine && <p className="mt-1.5 text-[10px] text-zinc-500">{m.engine}</p>}
          </div></div>
        ))}
        {busy && <div className="shimmer h-10 w-48 rounded-2xl" />}
        <div ref={end} />
      </div>
      <div className="flex gap-2 border-t border-white/[0.06] p-3"><input className={inputCls} placeholder="Pergunte algo sobre o vídeo…" value={q} onChange={(e) => setQ(e.target.value)} onKeyDown={(e) => e.key === "Enter" && ask(q)} /><Btn variant="primary" onClick={() => ask(q)} disabled={busy}><Send className="size-4" /></Btn><Btn variant="ghost" onClick={async () => { await del(`/api/projects/${project.id}/chat`); setMsgs([]); }}>Limpar</Btn></div>
    </Card>
  );
}

/* ------------------------------ Mapa mental ------------------------------ */
type MNode = { id: string; label: string; t?: number; children: MNode[] };
function MindmapView({ project }: { project: ProjectFull }) {
  const [m, setM] = useState<MNode | null>(null); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  useEffect(() => { api<{ mindmap: MNode | null }>(`/api/projects/${project.id}/understand`).then((r) => setM(r.mindmap)); }, [project.id]);
  const gen = async () => { setBusy(true); setErr(""); try { setM((await post<{ mindmap: MNode }>(`/api/projects/${project.id}/understand`, { kind: "mindmap" })).mindmap); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); } setBusy(false); };
  const rows: { x: number; y: number; n: MNode; depth: number; parent?: { x: number; y: number } }[] = [];
  let y = 30; const RH = 54;
  if (m) { const place = (n: MNode, depth: number, parent?: { x: number; y: number }): number => { const x = 20 + depth * 330; if (!n.children.length) { const yy = y; y += RH; rows.push({ x, y: yy, n, depth, parent }); return yy; } const me = { x, y: 0 }; const ys = n.children.map((c) => place(c, depth + 1, me)); me.y = (ys[0] + ys[ys.length - 1]) / 2; rows.push({ x, y: me.y, n, depth, parent }); return me.y; };
    const rootY = place(m, 0); void rootY; }
  const H = Math.max(y + 20, 200);
  const svgRef = useRef<SVGSVGElement>(null);
  const md = (n: MNode, d = 0): string => `${"  ".repeat(d)}- ${n.label}${n.t !== undefined ? ` (${fmtTime(n.t)})` : ""}\n${n.children.map((c) => md(c, d + 1)).join("")}`;
  const colors = ["#7c5cff", "#3b82f6", "#2dd4a0"];
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-3"><Btn variant="primary" onClick={gen} loading={busy}>{m ? "Gerar novamente" : "Gerar mapa mental"}</Btn>
        {m && <><Btn onClick={() => svgRef.current && download("mapa-mental.svg", new XMLSerializer().serializeToString(svgRef.current), "image/svg+xml")}><Download className="size-4" />SVG</Btn><Btn onClick={() => download("mapa-mental.md", md(m), "text/markdown")}><Download className="size-4" />Markdown</Btn></>}</div>
      {err && <Notice tone="rose">{err}</Notice>}
      {m && (
        <Card className="overflow-x-auto">
          <svg ref={svgRef} xmlns="http://www.w3.org/2000/svg" width={1020} height={H} style={{ background: "#0e0e16" }} fontFamily="sans-serif">
            {rows.map((r, i) => r.parent && <path key={"l" + i} d={`M${r.parent.x + 250} ${r.parent.y} C ${r.parent.x + 290} ${r.parent.y}, ${r.x - 40} ${r.y}, ${r.x} ${r.y}`} stroke={colors[r.depth % 3]} strokeOpacity={0.6} fill="none" strokeWidth={2} />)}
            {rows.map((r, i) => (<g key={i}><rect x={r.x} y={r.y - 20} width={250} height={40} rx={12} fill={r.depth === 0 ? colors[0] : "#171724"} stroke={colors[r.depth % 3]} /><text x={r.x + 12} y={r.y + 5} fill="#fff" fontSize={r.depth === 2 ? 11 : 13}>{r.n.label.length > 34 ? r.n.label.slice(0, 33) + "…" : r.n.label}{r.n.t !== undefined ? `  [${fmtTime(r.n.t)}]` : ""}</text></g>))}
          </svg>
        </Card>
      )}
    </div>
  );
}

/* ------------------------------ Anotações ------------------------------ */
function NotesView({ project }: { project: ProjectFull }) {
  const [notes, setNotes] = useState(""); const [dirty, setDirty] = useState(false); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  useEffect(() => { api<{ notes: string | null }>(`/api/projects/${project.id}/understand`).then((r) => setNotes(r.notes ?? "")); }, [project.id]);
  const st = useAutosave(notes, (v) => put(`/api/projects/${project.id}/understand`, { notes: v }), dirty);
  const gen = async () => { setBusy(true); setErr(""); try { setNotes((await post<{ notes: string }>(`/api/projects/${project.id}/understand`, { kind: "notes" })).notes); setDirty(false); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); } setBusy(false); };
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3"><Btn variant="primary" onClick={gen} loading={busy}>{notes ? "Regenerar (substitui o texto)" : "Gerar anotações"}</Btn><Btn onClick={() => download("anotacoes.md", notes, "text/markdown")} disabled={!notes}><Download className="size-4" />Exportar .md</Btn>{dirty && <Badge tone={st === "saving" ? "amber" : "green"}>{st === "saving" ? "salvando…" : "salvo"}</Badge>}</div>
      {err && <Notice tone="rose">{err}</Notice>}
      <textarea className={`${inputCls} min-h-[480px] font-mono text-[13px] leading-relaxed`} value={notes} onChange={(e) => { setNotes(e.target.value); setDirty(true); }} placeholder="As anotações aparecem aqui (Markdown). Você pode editar livremente." />
    </div>
  );
}
