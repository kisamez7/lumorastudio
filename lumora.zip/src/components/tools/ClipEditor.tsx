"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Clapperboard, Download, Pause, Play, Redo2, Trash2, Undo2 } from "lucide-react";
import { api, patch, post, uploadFile, useAutosave, useJob, waitJob } from "@/lib/client";
import {
  CLIP_MAX, CLIP_MIN, captionPresets, defaultAudioFx, defaultHook, fmtTime, safeCaptionY,
  type AudioFx, type Caption, type CaptionStyle, type EditorElement, type HookConfig, type HookOption, type LayoutConfig, type LayoutMode, type Rect,
} from "@/lib/types";
import { Badge, Btn, Card, Empty, Field, inputCls, JobBar, Notice, PageHeader, Progress } from "../ui";
import { RequireProject } from "../ImportPanel";
import { RectPicker } from "../RectPicker";
import type { AssetDto, ProjectFull } from "../ProjectContext";
import type { ClipDto } from "./ClipsTool";

type Editable = { title: string; hook: HookConfig; captionStyle: CaptionStyle; captions: Caption[]; layout: LayoutConfig; audioFx: AudioFx; elements: EditorElement[] };
type ClipFull = ClipDto & Editable & { source: AssetDto | null; hookOptions: HookOption[] };
type Fmt = "9:16" | "1:1" | "16:9";

const TABS = [["trecho", "Trecho"], ["hooks", "Hooks"], ["legendas", "Legendas"], ["reenquadramento", "Reenquadramento"], ["audio", "Áudio"], ["elementos", "Elementos & B-roll"], ["modelos", "Modelos"]] as const;
const PANEL_TAB: Record<string, string> = { editor: "trecho", hooks: "hooks", captions: "legendas", reframe: "reenquadramento", audio: "audio", broll: "elementos" };
const TITLES: Record<string, string> = { editor: "Editor profissional", hooks: "Hooks", captions: "Legendas", reframe: "Reenquadramento", audio: "Áudio", broll: "B-roll e elementos" };
const uid = () => Math.random().toString(36).slice(2, 9);

export function ClipEditor({ panel }: { panel: string }) {
  return (
    <div>
      <PageHeader title={TITLES[panel] || "Editor"} subtitle="Pré-visualização em tempo real, timeline, hooks, legendas, enquadramento e áudio. Tudo é salvo automaticamente." icon={<Clapperboard className="size-5" />} />
      <RequireProject>{(p) => <Inner project={p} initialTab={PANEL_TAB[panel] || "trecho"} />}</RequireProject>
    </div>
  );
}

function Inner({ project, initialTab }: { project: ProjectFull; initialTab: string }) {
  const [list, setList] = useState<ClipDto[]>([]);
  const [id, setId] = useState<string | null>(null);
  const [full, setFull] = useState<ClipFull | null>(null);
  const [c, setC] = useState<Editable | null>(null);
  const [dirty, setDirty] = useState(false);
  const [tab, setTab] = useState(initialTab);
  const [fmt, setFmt] = useState<Fmt>("9:16");
  const [t, setT] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [err, setErr] = useState("");
  const hist = useRef<Editable[]>([]);
  const redo = useRef<Editable[]>([]);

  useEffect(() => {
    api<ClipDto[]>(`/api/projects/${project.id}/clips`).then((cs) => {
      const only = cs.filter((x) => x.type === "clip");
      setList(only);
      const saved = localStorage.getItem("lumora.clip");
      setId(only.find((x) => x.id === saved)?.id ?? only[0]?.id ?? null);
    });
  }, [project.id]);

  const loadClip = useCallback(async (cid: string) => {
    const d = await api<ClipFull>(`/api/clips/${cid}`);
    setFull(d);
    setC({ title: d.title, hook: d.hook, captionStyle: d.captionStyle, captions: d.captions as Caption[], layout: d.layout, audioFx: d.audioFx, elements: d.elements });
    setDirty(false); hist.current = []; redo.current = []; setT(0);
  }, []);
  useEffect(() => { if (id) { localStorage.setItem("lumora.clip", id); void loadClip(id); } }, [id, loadClip]);

  const upd = useCallback((patchFn: (e: Editable) => Editable) => {
    setC((prev) => { if (!prev) return prev; hist.current = [...hist.current.slice(-49), prev]; redo.current = []; return patchFn(prev); });
    setDirty(true);
  }, []);
  const undo = () => setC((prev) => { const h = hist.current.pop(); if (!h || !prev) return prev; redo.current.push(prev); setDirty(true); return h; });
  const redoFn = () => setC((prev) => { const h = redo.current.pop(); if (!h || !prev) return prev; hist.current.push(prev); setDirty(true); return h; });

  const saveState = useAutosave(c, async (v) => { if (!id || !v) return; try { await patch(`/api/clips/${id}`, v); setErr(""); } catch (e) { setErr(e instanceof Error ? e.message : "Erro ao salvar"); throw e; } }, dirty && !!c);

  const { job, track, cancel, running } = useJob(() => { if (id) void loadClip(id); });
  const render = async () => { if (!id) return; if (dirty) await new Promise((r) => setTimeout(r, 1500)); track((await post<{ jobId: string }>(`/api/clips/${id}/render`)).jobId); };

  if (!list.length) return <Empty title="Nenhum corte para editar">Gere cortes no <a href="/t/clips" className="text-violet-300 underline">Criador de cortes</a> primeiro.</Empty>;
  if (!full || !c) return <div className="shimmer h-80 rounded-2xl" />;
  const d = full.endSec - full.startSec;

  return (
    <div className="space-y-5">
      <Card className="flex flex-wrap items-center gap-3 !p-3">
        <select className={`${inputCls} max-w-xs`} value={id ?? ""} onChange={(e) => setId(e.target.value)}>{list.map((x) => <option key={x.id} value={x.id}>{x.score ? `[${x.score}] ` : ""}{x.title}</option>)}</select>
        <Btn size="sm" onClick={undo} disabled={!hist.current.length}><Undo2 className="size-3.5" />Desfazer</Btn>
        <Btn size="sm" onClick={redoFn} disabled={!redo.current.length}><Redo2 className="size-3.5" />Refazer</Btn>
        <Badge tone={saveState === "error" ? "rose" : saveState === "saving" ? "amber" : "green"}>{saveState === "saving" ? "salvando…" : saveState === "error" ? "erro ao salvar" : "salvo automaticamente"}</Badge>
        <div className="ml-auto flex items-center gap-2">
          <div className="inline-flex rounded-lg bg-black/40 p-0.5 text-xs">{(["9:16", "1:1", "16:9"] as Fmt[]).map((f) => <button key={f} onClick={() => setFmt(f)} className={`rounded-md px-2.5 py-1 ${fmt === f ? "bg-white/15 text-white" : "text-zinc-400"}`}>{f}</button>)}</div>
          <Btn variant="primary" size="sm" onClick={render} disabled={running}>Renderizar MP4</Btn>
        </div>
      </Card>
      {err && <Notice tone="rose">{err}</Notice>}
      <JobBar job={job} onCancel={cancel} />
      {full.output && full.status === "rendered" && (
        <Card className="flex flex-wrap items-center gap-4 !p-4"><video src={full.output.url} controls className="h-48 rounded-lg bg-black" /><div className="text-sm"><p className="font-medium text-emerald-300">Render pronto — duração real verificada: {full.renderedDuration?.toFixed(2)} s</p><p className="text-xs text-zinc-500">1080×1920 · H.264/AAC · sem marca d’água</p><div className="mt-2 flex gap-2"><a href={`${full.output.url}?download=1`}><Btn size="sm"><Download className="size-3.5" />Baixar MP4</Btn></a><a href={`/api/clips/${full.id}/srt`}><Btn size="sm">Exportar SRT</Btn></a></div></div></Card>
      )}

      <div className="grid gap-5 xl:grid-cols-[380px_1fr]">
        <div className="space-y-3">
          <Preview source={full.source} full={full} c={c} fmt={fmt} t={t} setT={setT} playing={playing} setPlaying={setPlaying} d={d} />
        </div>
        <div className="min-w-0 space-y-4">
          <Timeline c={c} d={d} t={t} setT={setT} upd={upd} />
          <Card>
            <div className="mb-4 flex flex-wrap gap-1.5">{TABS.map(([k, l]) => <button key={k} onClick={() => setTab(k)} className={`rounded-lg px-3 py-1.5 text-xs transition ${tab === k ? "bg-violet-500/25 text-violet-100 ring-1 ring-violet-400/40" : "bg-white/[0.05] text-zinc-400 hover:bg-white/10"}`}>{l}</button>)}</div>
            {tab === "trecho" && <RangePanel full={full} c={c} upd={upd} reload={() => loadClip(full.id)} setErr={setErr} />}
            {tab === "hooks" && <HooksPanel full={full} c={c} upd={upd} d={d} setFull={setFull} />}
            {tab === "legendas" && <CaptionsPanel full={full} c={c} upd={upd} reload={() => loadClip(full.id)} setErr={setErr} />}
            {tab === "reenquadramento" && <LayoutPanel project={project} full={full} c={c} upd={upd} t={t} />}
            {tab === "audio" && <AudioPanel project={project} c={c} upd={upd} />}
            {tab === "elementos" && <ElementsPanel project={project} full={full} c={c} upd={upd} d={d} />}
            {tab === "modelos" && <TemplatesPanel project={project} c={c} upd={upd} />}
          </Card>
        </div>
      </div>
    </div>
  );
}

/* ----------------------------- Preview (canvas) ----------------------------- */
function lerpFocus(l: LayoutConfig, t: number) {
  const k = [...l.focus].sort((a, b) => a.t - b.t);
  if (!k.length) return l.focusX;
  if (t <= k[0].t) return k[0].x;
  for (let i = 0; i < k.length - 1; i++) if (t < k[i + 1].t) { const u = Math.min(1, (t - k[i].t) / Math.max(0.1, k[i + 1].t - k[i].t)); return k[i].x + (k[i + 1].x - k[i].x) * (u * u * (3 - 2 * u)); }
  return k[k.length - 1].x;
}

function Preview({ source, full, c, fmt, t, setT, playing, setPlaying, d }: { source: AssetDto | null; full: ClipFull; c: Editable; fmt: Fmt; t: number; setT: (n: number) => void; playing: boolean; setPlaying: (b: boolean) => void; d: number }) {
  const vid = useRef<HTMLVideoElement>(null);
  const cv = useRef<HTMLCanvasElement>(null);
  const st = useRef({ c, fmt, start: full.startSec, d, images: new Map<string, HTMLImageElement>() });
  st.current.c = c; st.current.fmt = fmt; st.current.start = full.startSec; st.current.d = d;
  const [size, setSize] = useState({ w: 360, h: 640 });

  useEffect(() => { setSize(fmt === "9:16" ? { w: 360, h: 640 } : fmt === "1:1" ? { w: 360, h: 360 } : { w: 360, h: 203 }); }, [fmt]);
  useEffect(() => { if (vid.current) vid.current.currentTime = full.startSec; }, [full.startSec, full.id]);
  useEffect(() => { const v = vid.current; if (!v) return; if (playing) void v.play().catch(() => setPlaying(false)); else v.pause(); }, [playing, setPlaying]);

  useEffect(() => {
    let raf = 0;
    const draw = () => {
      raf = requestAnimationFrame(draw);
      const v = vid.current, cvs = cv.current;
      if (!v || !cvs || v.readyState < 2) return;
      const { c: cc, fmt: f, start, d: dur } = st.current;
      if (v.currentTime >= start + dur) { v.pause(); v.currentTime = start; setPlaying(false); }
      const tt = Math.max(0, v.currentTime - start);
      if (!v.paused) setT(tt);
      const W = f === "9:16" ? 1080 : 1080, H = f === "9:16" ? 1920 : f === "1:1" ? 1080 : 608;
      const ctx = cvs.getContext("2d")!;
      const sc = cvs.width / W;
      ctx.setTransform(sc, 0, 0, sc, 0, 0);
      ctx.clearRect(0, 0, W, H);
      const vw = v.videoWidth, vh = v.videoHeight;
      const px = (r: Rect | null) => (r ? { x: r.x * vw, y: r.y * vh, w: r.w * vw, h: r.h * vh } : { x: 0, y: 0, w: vw, h: vh });
      const fit = (s: { x: number; y: number; w: number; h: number }, bx: number, by: number, bw: number, bh: number) => { const k = Math.min(bw / s.w, bh / s.h); const w = s.w * k, h = s.h * k; ctx.drawImage(v, s.x, s.y, s.w, s.h, bx + (bw - w) / 2, by + (bh - h) / 2, w, h); };
      const fill = (s: { x: number; y: number; w: number; h: number }, bx: number, by: number, bw: number, bh: number, fx = 0.5) => { const k = Math.max(bw / s.w, bh / s.h); const cw = bw / k, ch = bh / k; ctx.drawImage(v, s.x + (s.w - cw) * fx, s.y + (s.h - ch) / 2, cw, ch, bx, by, bw, bh); };
      if (f !== "9:16") {
        if (f === "16:9") ctx.drawImage(v, 0, 0, W, H); else fill(px(null), 0, 0, W, H, lerpFocus(cc.layout, tt));
      } else {
        const L = cc.layout; let mode: LayoutMode = L.mode;
        if ((mode === "A" || mode === "B" || mode === "C") && !L.cam) mode = "fit";
        ctx.save(); ctx.filter = "blur(28px) brightness(0.75)"; fill(px(null), -40, -40, W + 80, H + 80); ctx.restore();
        if (mode === "fit") fit(px(null), 0, 0, W, H);
        else if (mode === "A") { fit(px(L.game), 0, 260, W, 640); fit(px(L.cam), 0, 920, W, 640); }
        else if (mode === "B") { fit(px(L.cam), 0, 200, W, 900); fit(px(L.game), 0, 1140, W, 608); }
        else if (mode === "C") { fill(px(L.game), 0, 260, W, 1260, L.focusX); const cm = px(L.cam), sd = Math.min(cm.w, cm.h); ctx.drawImage(v, cm.x + (cm.w - sd) / 2, cm.y + (cm.h - sd) / 2, sd, sd, 700, 1156, 340, 340); }
        else { const cw = Math.min(vw, vh * 9 / 16), x = (vw - cw) * lerpFocus(L, tt); ctx.drawImage(v, x, 0, cw, vh, 0, 0, W, H); }
      }
      // legendas
      const cs = cc.captionStyle;
      const SY = f === "9:16" ? H : 1920;
      const fscale = f === "9:16" ? 1 : H / 1920 * (f === "16:9" ? 1.6 : 1);
      const line = cc.captions.find((l) => tt >= l.start && tt < l.end);
      ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.lineJoin = "round";
      const word = (txt: string, x: number, y: number, size: number, col: string, outline: number, font: string) => { ctx.font = `${size}px ${font}`; ctx.lineWidth = outline * 2; ctx.strokeStyle = "#000"; ctx.strokeText(txt, x, y); ctx.fillStyle = col; ctx.fillText(txt, x, y); };
      const fontOf = (n: string) => (n === "Anton" ? "Anton, Impact, 'Arial Narrow', sans-serif" : "Poppins, 'Segoe UI', Arial, sans-serif");
      if (cs.enabled && line) {
        const sz = cs.size * fscale * (f === "9:16" ? 1 : 1);
        const ws = line.words.map((w) => (cs.uppercase ? w.text.toUpperCase() : w.text));
        ctx.font = `${sz}px ${fontOf(cs.font)}`;
        const gap = sz * 0.28;
        const widths = ws.map((w) => ctx.measureText(w).width);
        let total = widths.reduce((a, b) => a + b, 0) + gap * (ws.length - 1);
        const maxW = W - 120;
        let scale2 = 1; if (total > maxW) scale2 = maxW / total;
        const y = (cs.yPct / 100) * (f === "9:16" ? H : H) ;
        if (cs.bg) { ctx.fillStyle = "rgba(0,0,0,0.6)"; ctx.fillRect(W / 2 - (total * scale2) / 2 - 20, y - sz * 0.7, total * scale2 + 40, sz * 1.4); }
        let x = W / 2 - (total * scale2) / 2;
        ws.forEach((w, i) => {
          const active = cs.preset === "viral" ? tt >= line.words[i].start && tt < (line.words[i + 1]?.start ?? line.end) : line.words[i].hl && cs.preset !== "minimalista";
          const ww = widths[i] * scale2;
          if (cs.preset === "dinamico") { if (tt >= line.words[i].start && tt < (line.words[i + 1]?.start ?? line.end)) word(w, W / 2, y, sz, line.words[i].hl ? cs.highlight : cs.color, cs.outline, fontOf(cs.font)); return; }
          word(w, x + ww / 2, y, sz * scale2, active ? cs.highlight : cs.color, cs.outline * scale2, fontOf(cs.font));
          x += ww + gap * scale2;
        });
      }
      // hook
      const h = cc.hook;
      if (h.enabled && h.text && tt >= h.start && tt <= h.start + h.duration) {
        const a = Math.min(1, (tt - h.start) / 0.2, (h.start + h.duration - tt) / 0.25);
        ctx.globalAlpha = Math.max(0, a);
        const sz = h.size * fscale; const words = h.text.toUpperCase().split(/\s+/);
        ctx.font = `${sz}px ${fontOf(h.font)}`;
        const lines: string[][] = [[]]; let lw = 0;
        for (const w of words) { const ww = ctx.measureText(w + " ").width; if (lw + ww > W - 160 && lines[lines.length - 1].length) { lines.push([]); lw = 0; } lines[lines.length - 1].push(w); lw += ww; }
        let accent = -1, al = 4; words.forEach((w, i) => { if (w.length > al) { al = w.length; accent = i; } });
        let wi = 0; const y0 = (h.yPct / 100) * SY * (f === "9:16" ? 1 : H / 1920) + sz * 0.55;
        lines.forEach((ln, li) => {
          const text = ln.join(" "); const full2 = ctx.measureText(text).width; let x = W / 2 - full2 / 2;
          ln.forEach((w) => { const ww = ctx.measureText(w).width; ctx.textAlign = "left"; word(w, x, y0 + li * sz * 1.12, sz, wi === accent ? h.accent : h.color, h.outline ? 8 : 0, fontOf(h.font)); ctx.textAlign = "left"; x += ww + ctx.measureText(" ").width; wi++; });
        });
        ctx.textAlign = "center"; ctx.globalAlpha = 1;
      }
      // elementos
      for (const el of cc.elements) {
        if (tt < el.start || tt > el.end) continue;
        const x = (el.x / 100) * W, y = (el.y / 100) * (f === "9:16" ? H : H);
        if (el.type === "text") word(el.text || "", x, y, (el.size || 60) * fscale, el.color || "#fff", 4, fontOf("Poppins"));
        else if (el.type === "rect") { ctx.fillStyle = (el.color || "#7C5CFF") + "BF"; const w = ((el.w || 30) / 100) * W, hh = ((el.h || 8) / 100) * H; ctx.fillRect(x - w / 2, y - hh / 2, w, hh); }
        else if (el.type === "image" && el.assetId) {
          let im = st.current.images.get(el.assetId);
          if (!im) { im = new Image(); im.src = `/api/assets/${el.assetId}`; st.current.images.set(el.assetId, im); }
          if (im.complete && im.naturalWidth) { const w = ((el.w || 40) / 100) * W; ctx.drawImage(im, x - w / 2, y - (w * im.naturalHeight / im.naturalWidth) / 2, w, w * im.naturalHeight / im.naturalWidth); }
        }
      }
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [setPlaying, setT]);

  const seek = (n: number) => { setT(n); if (vid.current) vid.current.currentTime = full.startSec + n; };
  return (
    <Card className="!p-3">
      {source && <video ref={vid} src={source.url} preload="auto" playsInline className="hidden" crossOrigin="anonymous" />}
      <canvas ref={cv} width={size.w * 1.5} height={size.h * 1.5} style={{ width: size.w, height: size.h }} className="mx-auto max-w-full rounded-xl bg-black" />
      <div className="mt-3 flex items-center gap-3">
        <Btn size="sm" variant="primary" onClick={() => setPlaying(!playing)}>{playing ? <Pause className="size-4" /> : <Play className="size-4" />}</Btn>
        <input type="range" min={0} max={d} step={0.05} value={t} onChange={(e) => seek(Number(e.target.value))} className="flex-1" />
        <span className="w-20 text-right text-xs tabular-nums text-zinc-400">{t.toFixed(1)} / {d.toFixed(1)}s</span>
      </div>
      <p className="mt-2 text-[11px] text-zinc-600">Pré-visualização aproximada (canvas). O resultado final é gerado pelo FFmpeg com a mesma composição. O áudio processado só é aplicado no render.</p>
    </Card>
  );
}

/* ----------------------------- Timeline ----------------------------- */
function Timeline({ c, d, t, setT, upd }: { c: Editable; d: number; t: number; setT: (n: number) => void; upd: (f: (e: Editable) => Editable) => void }) {
  const area = useRef<HTMLDivElement>(null);
  const pct = (x: number) => `${(x / d) * 100}%`;
  const click = (e: React.PointerEvent) => { const b = area.current!.getBoundingClientRect(); setT(Math.max(0, Math.min(d, ((e.clientX - b.left) / b.width) * d))); };
  const dragHook = (e: React.PointerEvent) => {
    e.stopPropagation(); const el = e.currentTarget as HTMLElement; el.setPointerCapture(e.pointerId);
    const b = area.current!.getBoundingClientRect(); const x0 = e.clientX; const s0 = c.hook.start;
    const move = (ev: PointerEvent) => { const ns = Math.max(0, Math.min(d - c.hook.duration, s0 + ((ev.clientX - x0) / b.width) * d)); upd((p) => ({ ...p, hook: { ...p.hook, start: Math.round(ns * 10) / 10 } })); };
    const up = () => { el.removeEventListener("pointermove", move); el.removeEventListener("pointerup", up); };
    el.addEventListener("pointermove", move); el.addEventListener("pointerup", up);
  };
  const rows: { name: string; color: string; blocks: { s: number; e: number; label?: string; drag?: boolean }[] }[] = [
    { name: "Vídeo", color: "bg-blue-500/60", blocks: [{ s: 0, e: d, label: "Fonte recortada" }] },
    { name: "Áudio", color: "bg-emerald-500/50", blocks: [{ s: 0, e: d, label: [c.audioFx.normalize && "normalizar", c.audioFx.denoise && "ruído", c.audioFx.voice && "voz", c.audioFx.musicAssetId && "música"].filter(Boolean).join(" · ") || "original" }] },
    { name: "Legendas", color: "bg-sky-400/60", blocks: c.captions.map((l) => ({ s: l.start, e: l.end })) },
    { name: "Hooks", color: "bg-fuchsia-500/70", blocks: c.hook.enabled && c.hook.text ? [{ s: c.hook.start, e: c.hook.start + c.hook.duration, label: c.hook.text, drag: true }] : [] },
    { name: "Textos", color: "bg-amber-400/70", blocks: c.elements.filter((e) => e.type === "text").map((e) => ({ s: e.start, e: e.end, label: e.text })) },
    { name: "Gráficos", color: "bg-rose-400/60", blocks: c.elements.filter((e) => e.type === "rect").map((e) => ({ s: e.start, e: e.end, label: "forma" })) },
    { name: "B-roll", color: "bg-teal-400/60", blocks: c.elements.filter((e) => e.type === "image").map((e) => ({ s: e.start, e: e.end, label: "imagem" })) },
    { name: "Transições", color: "bg-zinc-400/50", blocks: c.audioFx.fade ? [{ s: 0, e: 0.3, label: "" }, { s: d - 0.4, e: d, label: "" }] : [] },
  ];
  return (
    <Card className="!p-3">
      <div className="flex">
        <div className="w-20 shrink-0 space-y-1 pt-5 text-[11px] text-zinc-500">{rows.map((r) => <div key={r.name} className="flex h-6 items-center">{r.name}</div>)}</div>
        <div ref={area} onPointerDown={click} className="relative min-w-0 flex-1 cursor-pointer">
          <div className="flex h-5 justify-between text-[10px] text-zinc-600">{[0, 0.25, 0.5, 0.75, 1].map((f) => <span key={f}>{fmtTime(d * f)}</span>)}</div>
          <div className="space-y-1">{rows.map((r) => (
            <div key={r.name} className="relative h-6 rounded bg-white/[0.04]">
              {r.blocks.map((b, i) => <div key={i} onPointerDown={b.drag ? dragHook : undefined} title={b.label} style={{ left: pct(b.s), width: `max(3px, ${pct(Math.max(0.05, b.e - b.s))})` }} className={`absolute inset-y-0.5 overflow-hidden whitespace-nowrap rounded px-1 text-[10px] leading-5 text-white/90 ${r.color} ${b.drag ? "cursor-grab ring-1 ring-white/40" : ""}`}>{b.label}</div>)}
            </div>))}</div>
          <div className="pointer-events-none absolute bottom-0 top-5 w-px bg-white" style={{ left: pct(t) }} />
        </div>
      </div>
      <p className="mt-1 text-[11px] text-zinc-600">Clique para posicionar o cursor · arraste o bloco do hook para mudar quando aparece.</p>
    </Card>
  );
}

type Upd = (f: (e: Editable) => Editable) => void;

/* ----------------------------- Painéis ----------------------------- */
function RangePanel({ full, c, upd, reload, setErr }: { full: ClipFull; c: Editable; upd: Upd; reload: () => void; setErr: (s: string) => void }) {
  const [s, setS] = useState(full.startSec), [e, setE] = useState(full.endSec);
  const dur = e - s; const ok = dur >= CLIP_MIN && dur <= CLIP_MAX;
  return (
    <div className="space-y-4">
      <Field label="Título"><input className={inputCls} value={c.title} onChange={(ev) => upd((p) => ({ ...p, title: ev.target.value }))} /></Field>
      <div className="grid grid-cols-3 gap-3">
        <Field label="Início (s)"><input type="number" step="0.1" className={inputCls} value={s} onChange={(ev) => setS(Number(ev.target.value))} /></Field>
        <Field label="Fim (s)"><input type="number" step="0.1" className={inputCls} value={e} onChange={(ev) => setE(Number(ev.target.value))} /></Field>
        <div className="self-end pb-2.5 text-sm"><b className={ok ? "text-emerald-300" : "text-rose-300"}>{dur.toFixed(1)} s</b><p className="text-[11px] text-zinc-500">permitido: {CLIP_MIN}–{CLIP_MAX} s</p></div>
      </div>
      <Btn size="sm" variant="primary" disabled={!ok} onClick={async () => { try { await patch(`/api/clips/${full.id}`, { startSec: s, endSec: e }); setErr(""); reload(); } catch (x) { setErr(x instanceof Error ? x.message : "Erro"); } }}>Aplicar novo trecho (reconstrói legendas)</Btn>
      <p className="text-xs text-zinc-500">O backend recusa qualquer intervalo fora de 60–90 s. Ajuste respeitando frases completas: ouça o início e o fim na pré-visualização.</p>
    </div>
  );
}

function HooksPanel({ full, c, upd, d, setFull }: { full: ClipFull; c: Editable; upd: Upd; d: number; setFull: (f: ClipFull) => void }) {
  const h = c.hook; const set = (p: Partial<HookConfig>) => upd((e) => ({ ...e, hook: { ...e.hook, ...p } }));
  const [busy, setBusy] = useState(false); const [msg, setMsg] = useState("");
  return (
    <div className="space-y-4">
      <Notice tone="blue">Hooks nunca inventam acontecimentos: sugestões usam apenas palavras e sinais reais do trecho. Revise antes de publicar. Hook ≠ legenda: os dois aparecem juntos.</Notice>
      <Field label="Texto do hook"><textarea rows={2} className={inputCls} value={h.text} onChange={(e) => set({ text: e.target.value.toUpperCase() })} /></Field>
      <div className="flex flex-wrap gap-2">{full.hookOptions.map((o) => <button key={o.text} onClick={() => set({ text: o.text, enabled: true })} className={`rounded-lg border px-2.5 py-1.5 text-left text-xs ${h.text === o.text ? "border-violet-400/60 bg-violet-500/15" : "border-white/10 bg-white/[0.03] hover:bg-white/[0.08]"}`}><b>{o.text}</b><span className="block text-[10px] text-zinc-500">{o.approach}{o.recommended ? " · recomendado" : ""} · {o.source}</span></button>)}</div>
      <div className="flex items-center gap-3"><Btn size="sm" loading={busy} onClick={async () => { setBusy(true); setMsg(""); try { const o = await post<HookOption[]>(`/api/clips/${full.id}/hooks`); setFull({ ...full, hookOptions: o }); } catch (e) { setMsg(e instanceof Error ? e.message : "Erro"); } setBusy(false); }}>Gerar novas sugestões</Btn>{msg && <span className="text-xs text-amber-300">{msg}</span>}</div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-violet-500" checked={h.enabled} onChange={(e) => set({ enabled: e.target.checked })} />Hook ativo</label>
        <Field label="Aparece em (s)"><input type="number" step="0.1" min={0} max={d - 1} className={inputCls} value={h.start} onChange={(e) => set({ start: Number(e.target.value) })} /></Field>
        <Field label={`Duração: ${h.duration.toFixed(1)} s`} hint="Recomendado: 2–4 s"><input type="range" min={1} max={8} step={0.1} value={h.duration} onChange={(e) => set({ duration: Number(e.target.value) })} className="w-full" /></Field>
        <Field label="Cor do texto"><input type="color" value={h.color} onChange={(e) => set({ color: e.target.value })} className="h-10 w-full rounded-lg bg-transparent" /></Field>
        <Field label="Cor de destaque"><input type="color" value={h.accent} onChange={(e) => set({ accent: e.target.value })} className="h-10 w-full rounded-lg bg-transparent" /></Field>
        <Field label="Fonte"><select className={inputCls} value={h.font} onChange={(e) => set({ font: e.target.value as HookConfig["font"] })}><option>Anton</option><option>Poppins</option></select></Field>
        <Field label={`Tamanho: ${h.size}`}><input type="range" min={40} max={160} value={h.size} onChange={(e) => set({ size: Number(e.target.value) })} className="w-full" /></Field>
        <Field label="Animação"><select className={inputCls} value={h.animation} onChange={(e) => set({ animation: e.target.value as HookConfig["animation"] })}>{["pop", "fade", "slide", "none"].map((a) => <option key={a}>{a}</option>)}</select></Field>
        <Field label={`Posição vertical: ${h.yPct}%`} hint="Evite cobrir rostos/HUD"><input type="range" min={3} max={85} value={h.yPct} onChange={(e) => set({ yPct: Number(e.target.value) })} className="w-full" /></Field>
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-violet-500" checked={h.outline} onChange={(e) => set({ outline: e.target.checked })} />Contorno</label>
        <Btn size="sm" variant="danger" onClick={() => set({ enabled: false })}><Trash2 className="size-3.5" />Remover hook</Btn>
        <Btn size="sm" onClick={() => set({ ...defaultHook(), text: h.text })}>Restaurar estilo</Btn>
      </div>
    </div>
  );
}

function CaptionsPanel({ full, c, upd, reload, setErr }: { full: ClipFull; c: Editable; upd: Upd; reload: () => void; setErr: (s: string) => void }) {
  const s = c.captionStyle; const set = (p: Partial<CaptionStyle>) => upd((e) => ({ ...e, captionStyle: { ...e.captionStyle, ...p } }));
  const editLine = (i: number, text: string) => upd((e) => {
    const l = e.captions[i]; const toks = text.split(/\s+/).filter(Boolean); const span = l.end - l.start;
    const words = toks.map((w, k) => ({ text: w, start: l.start + (span * k) / Math.max(1, toks.length), end: l.start + (span * (k + 1)) / Math.max(1, toks.length), hl: false }));
    let bi = -1, bl = 4; words.forEach((w, k) => { if (w.text.length > bl) { bl = w.text.length; bi = k; } }); if (bi >= 0) words[bi].hl = true;
    return { ...e, captions: e.captions.map((x, k) => (k === i ? { ...x, words } : x)) };
  });
  const setTime = (i: number, k: "start" | "end", v: number) => upd((e) => ({ ...e, captions: e.captions.map((x, j) => (j === i ? { ...x, [k]: v } : x)) }));
  const shift = (dt: number) => upd((e) => ({ ...e, captions: e.captions.map((l) => ({ ...l, start: Math.max(0, l.start + dt), end: Math.max(0.2, l.end + dt), words: l.words.map((w) => ({ ...w, start: Math.max(0, w.start + dt), end: Math.max(0.1, w.end + dt) })) })) }));
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-2">{(Object.keys(captionPresets) as (keyof typeof captionPresets)[]).map((k) => <button key={k} onClick={() => set({ ...captionPresets[k], yPct: safeCaptionY(c.layout.mode) ?? captionPresets[k].yPct })} className={`rounded-lg border px-3 py-2 text-xs capitalize ${s.preset === k ? "border-violet-400/60 bg-violet-500/15" : "border-white/10 bg-white/[0.03] hover:bg-white/[0.08]"}`}>{k}</button>)}</div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-violet-500" checked={s.enabled} onChange={(e) => set({ enabled: e.target.checked })} />Legendas ativas</label>
        <Field label="Fonte"><select className={inputCls} value={s.font} onChange={(e) => set({ font: e.target.value as CaptionStyle["font"], preset: "personalizado" })}><option>Anton</option><option>Poppins</option></select></Field>
        <Field label={`Tamanho: ${s.size}`}><input type="range" min={30} max={150} value={s.size} onChange={(e) => set({ size: Number(e.target.value), preset: "personalizado" })} className="w-full" /></Field>
        <Field label="Cor"><input type="color" value={s.color} onChange={(e) => set({ color: e.target.value, preset: "personalizado" })} className="h-10 w-full rounded-lg bg-transparent" /></Field>
        <Field label="Destaque"><input type="color" value={s.highlight} onChange={(e) => set({ highlight: e.target.value, preset: "personalizado" })} className="h-10 w-full rounded-lg bg-transparent" /></Field>
        <Field label={`Posição: ${s.yPct}%`} hint={safeCaptionY(c.layout.mode) ? `Sugerido p/ layout ${c.layout.mode}: ${safeCaptionY(c.layout.mode)}%` : undefined}><input type="range" min={10} max={95} value={s.yPct} onChange={(e) => set({ yPct: Number(e.target.value) })} className="w-full" /></Field>
        <Field label={`Contorno: ${s.outline}`}><input type="range" min={0} max={14} value={s.outline} onChange={(e) => set({ outline: Number(e.target.value), preset: "personalizado" })} className="w-full" /></Field>
        <Field label={`Sombra: ${s.shadow}`}><input type="range" min={0} max={8} value={s.shadow} onChange={(e) => set({ shadow: Number(e.target.value), preset: "personalizado" })} className="w-full" /></Field>
        <Field label={`Palavras/linha: ${s.wordsPerLine}`}><input type="range" min={1} max={8} value={s.wordsPerLine} onChange={(e) => set({ wordsPerLine: Number(e.target.value) })} className="w-full" /></Field>
        {([["bg", "Fundo"], ["animation", "Animações"], ["uppercase", "MAIÚSCULAS"]] as const).map(([k, l]) => <label key={k} className="flex items-center gap-2 text-sm"><input type="checkbox" className="accent-violet-500" checked={s[k]} onChange={(e) => set({ [k]: e.target.checked, preset: "personalizado" })} />{l}</label>)}
      </div>
      <div className="flex flex-wrap gap-2">
        <Btn size="sm" onClick={async () => { try { await patch(`/api/clips/${full.id}`, { captionStyle: s, rebuildCaptions: true }); reload(); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); } }}>Reagrupar legendas a partir da transcrição</Btn>
        <Btn size="sm" onClick={() => shift(-0.1)}>◀ −0,1 s (todas)</Btn><Btn size="sm" onClick={() => shift(0.1)}>+0,1 s (todas) ▶</Btn>
        <a href={`/api/clips/${full.id}/srt`}><Btn size="sm"><Download className="size-3.5" />Exportar SRT</Btn></a>
      </div>
      {!c.captions.length ? <Notice>Este corte não tem legendas: gere/importe a transcrição e use “Reagrupar”.</Notice> : (
        <div className="max-h-80 space-y-1.5 overflow-y-auto pr-1">
          {c.captions.map((l, i) => (
            <div key={i} className="flex items-center gap-2 text-xs">
              <input type="number" step="0.05" className={`${inputCls} !w-20 !px-2 !py-1.5`} value={Number(l.start.toFixed(2))} onChange={(e) => setTime(i, "start", Number(e.target.value))} />
              <input type="number" step="0.05" className={`${inputCls} !w-20 !px-2 !py-1.5`} value={Number(l.end.toFixed(2))} onChange={(e) => setTime(i, "end", Number(e.target.value))} />
              <input className={`${inputCls} !py-1.5`} defaultValue={l.words.map((w) => w.text).join(" ")} key={l.words.length + l.words[0]?.text} onBlur={(e) => editLine(i, e.target.value)} />
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function LayoutPanel({ project, full, c, upd, t }: { project: ProjectFull; full: ClipFull; c: Editable; upd: Upd; t: number }) {
  const L = c.layout; const set = (p: Partial<LayoutConfig>) => upd((e) => ({ ...e, layout: { ...e.layout, ...p } }));
  const mode = (m: LayoutMode) => upd((e) => { const sy = safeCaptionY(m); return { ...e, layout: { ...e.layout, mode: m }, captionStyle: sy ? { ...e.captionStyle, yPct: sy } : e.captionStyle }; });
  const [msg, setMsg] = useState("");
  const frame = `/api/projects/${project.id}/frame?t=${Math.round(full.startSec + 8)}&w=960`;
  const MODES: [LayoutMode, string, string][] = [["fit", "Fundo desfocado", "Vídeo inteiro centralizado"], ["A", "A · Gameplay + webcam", "Jogo em cima, webcam embaixo"], ["B", "B · Webcam destacada", "Webcam grande, jogo menor"], ["C", "C · Webcam reposicionada", "Jogo cheio + webcam em PiP"], ["D", "D · Dinâmico", "Recorte 9:16 que acompanha o foco"]];
  return (
    <div className="space-y-4">
      <div className="grid gap-2 sm:grid-cols-2">{MODES.map(([m, l, s]) => <button key={m} onClick={() => mode(m)} className={`rounded-xl border p-3 text-left text-sm ${L.mode === m ? "border-violet-400/60 bg-violet-500/15" : "border-white/10 bg-white/[0.03] hover:bg-white/[0.08]"}`}><b>{l}</b><span className="block text-xs text-zinc-500">{s}</span></button>)}</div>
      {["A", "B", "C"].includes(L.mode) && !L.cam && <Notice>Defina a região da webcam abaixo; sem ela o layout usa o fundo desfocado.</Notice>}
      <div className="grid gap-4 lg:grid-cols-2">
        <div><p className="mb-1.5 text-xs font-medium text-emerald-300">Webcam</p><RectPicker src={frame} value={L.cam} onChange={(r) => set({ cam: r })} label="WEBCAM" /></div>
        <div><p className="mb-1.5 text-xs font-medium text-blue-300">Região principal do jogo (padrão: quadro inteiro)</p><RectPicker src={frame} value={L.game} onChange={(r) => set({ game: r })} color="#60a5fa" label="JOGO" /></div>
      </div>
      <Field label={`Foco horizontal: ${(L.focusX * 100).toFixed(0)}%`} hint="Layouts C e D"><input type="range" min={0} max={1} step={0.01} value={L.focusX} onChange={(e) => set({ focusX: Number(e.target.value) })} className="w-full" /></Field>
      {L.mode === "D" && (
        <div className="space-y-2"><div className="flex items-center gap-2"><Btn size="sm" onClick={() => set({ focus: [...L.focus.filter((k) => Math.abs(k.t - t) > 0.2), { t: Math.round(t * 10) / 10, x: L.focusX }] })}>Adicionar keyframe em {t.toFixed(1)} s</Btn><span className="text-xs text-zinc-500">Transições entre keyframes são suavizadas (smoothstep).</span></div>
          <div className="flex flex-wrap gap-2">{[...L.focus].sort((a, b) => a.t - b.t).map((k) => <span key={k.t} className="flex items-center gap-1 rounded-lg bg-white/[0.06] px-2 py-1 text-xs">{k.t}s → {(k.x * 100).toFixed(0)}%<button onClick={() => set({ focus: L.focus.filter((z) => z !== k) })} className="text-rose-300">×</button></span>)}</div></div>
      )}
      <div className="flex flex-wrap items-center gap-2"><Btn size="sm" onClick={async () => { try { const r = await post<{ cam?: Rect | null }>(`/api/projects/${project.id}/webcam`); if (r.cam) set({ cam: r.cam }); else setMsg("Nenhuma webcam detectada."); } catch (e) { setMsg(e instanceof Error ? e.message : "Erro"); } }}>Detectar webcam (serviço CV)</Btn>{msg && <span className="text-xs text-amber-300">{msg}</span>}</div>
      <p className="text-xs text-zinc-500">Os recortes mantêm a proporção original (sem deformação). Se a webcam está embutida na gravação, o sistema recorta a região — não reconstrói a parte do jogo coberta por ela.</p>
    </div>
  );
}

function useLibrary(kind: string, projectId?: string) {
  const [rows, setRows] = useState<AssetDto[]>([]);
  const load = useCallback(() => api<AssetDto[]>(`/api/assets?kind=${kind}`).then(setRows).catch(() => {}), [kind]);
  useEffect(() => { void load(); }, [load]);
  const upload = async (f: File) => { await uploadFile(`/api/assets?kind=${kind}&filename=${encodeURIComponent(f.name)}${projectId ? `&projectId=${projectId}` : ""}`, f).promise; await load(); };
  return { rows, upload, load };
}

function AudioPanel({ project, c, upd }: { project: ProjectFull; c: Editable; upd: Upd }) {
  const a = c.audioFx; const set = (p: Partial<AudioFx>) => upd((e) => ({ ...e, audioFx: { ...e.audioFx, ...p } }));
  const lib = useLibrary("music");
  const [o, setO] = useState({ denoise: true, normalize: true, voice: true, removeSilence: false });
  const { job, track, cancel } = useJob();
  const [out, setOut] = useState<string | null>(null);
  return (
    <div className="space-y-4">
      <div className="grid gap-2 sm:grid-cols-2">
        {([["normalize", "Normalizar volume (EBU R128, −16 LUFS)"], ["denoise", "Redução de ruído (FFT)"], ["voice", "Melhoria de voz (compressor + EQ)"], ["fade", "Fade in/out (vídeo e áudio)"]] as const).map(([k, l]) => <label key={k} className="flex items-center gap-2 rounded-xl bg-white/[0.04] p-3 text-sm"><input type="checkbox" className="accent-violet-500" checked={a[k]} onChange={(e) => set({ [k]: e.target.checked })} />{l}</label>)}
      </div>
      <div className="space-y-2">
        <Field label="Música de fundo (sua biblioteca)"><select className={inputCls} value={a.musicAssetId ?? ""} onChange={(e) => set({ musicAssetId: e.target.value || null })}><option value="">Sem música</option>{lib.rows.map((m) => <option key={m.id} value={m.id}>{m.filename}</option>)}</select></Field>
        <Field label={`Volume da música: ${Math.round(a.musicVolume * 100)}%`}><input type="range" min={0} max={0.6} step={0.01} value={a.musicVolume} onChange={(e) => set({ musicVolume: Number(e.target.value) })} className="w-full" /></Field>
        <label className="inline-block"><span className="cursor-pointer rounded-xl border border-white/10 bg-white/[0.06] px-3 py-2 text-xs hover:bg-white/10">Enviar música (mp3/wav/m4a)</span><input type="file" accept="audio/*" className="hidden" onChange={(e) => e.target.files?.[0] && lib.upload(e.target.files[0])} /></label>
        <p className="text-[11px] text-zinc-600">Use apenas músicas que você tem direito de usar. Efeitos sonoros: envie como música curta (mixagem simples).</p>
      </div>
      <Notice tone="blue">Remoção de silêncio e de palavras de preenchimento altera a duração e dessincroniza legendas, por isso <b>não é aplicada aos cortes de 60–90 s</b>. Use o processamento abaixo para gerar um MP3 limpo do vídeo inteiro. Redução automática de “hum/né” não está disponível (exige alinhamento por palavra com modelo dedicado).</Notice>
      <div className="rounded-xl border border-white/10 p-4">
        <p className="mb-2 text-sm font-medium">Processar áudio do vídeo de origem → MP3</p>
        <div className="mb-3 flex flex-wrap gap-4 text-sm">{([["denoise", "Ruído"], ["normalize", "Normalizar"], ["voice", "Voz"], ["removeSilence", "Remover silêncios"]] as const).map(([k, l]) => <label key={k} className="flex items-center gap-1.5"><input type="checkbox" className="accent-violet-500" checked={o[k]} onChange={(e) => setO({ ...o, [k]: e.target.checked })} />{l}</label>)}</div>
        <Btn size="sm" variant="primary" onClick={async () => { if (!project.source) return; setOut(null); const r = await post<{ jobId: string }>(`/api/assets/${project.source.id}/convert`, { mode: "audio", ...o }); track(r.jobId); void waitJob(r.jobId).then((j) => j.status === "done" && setOut((j.result as { assetId: string }).assetId)); }}>Processar áudio</Btn>
        <div className="mt-3"><JobBar job={job} onCancel={cancel} /></div>
        {out && <a href={`/api/assets/${out}?download=1`}><Btn size="sm" className="mt-2"><Download className="size-3.5" />Baixar MP3 processado</Btn></a>}
      </div>
      <Btn size="sm" onClick={() => set(defaultAudioFx())}>Restaurar padrão</Btn>
    </div>
  );
}

function ElementsPanel({ project, full, c, upd, d }: { project: ProjectFull; full: ClipFull; c: Editable; upd: Upd; d: number }) {
  const lib = useLibrary("image", project.id);
  const [txt, setTxt] = useState(""); const [rejected, setRejected] = useState<string[]>([]);
  const add = (el: Partial<EditorElement>) => upd((e) => ({ ...e, elements: [...e.elements, { id: uid(), type: "text", start: 2, end: Math.min(d, 7), x: 50, y: 50, ...el } as EditorElement] }));
  const upEl = (id: string, p: Partial<EditorElement>) => upd((e) => ({ ...e, elements: e.elements.map((x) => (x.id === id ? { ...x, ...p } : x)) }));
  const words = new Set(`${full.topic} ${full.spokenText}`.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").match(/[a-z]{3,}/g) || []);
  const suggestions = lib.rows.filter((a) => !rejected.includes(a.id) && !c.elements.some((e) => e.assetId === a.id) && (a.filename.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").match(/[a-z]{3,}/g) || []).some((w) => words.has(w)));
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end gap-2">
        <div className="min-w-[200px] flex-1"><Field label="Texto / emoji"><input className={inputCls} value={txt} onChange={(e) => setTxt(e.target.value)} placeholder="Ex.: Dica importante" /></Field></div>
        <Btn size="sm" disabled={!txt} onClick={() => { add({ type: "text", text: txt, size: 64, color: "#FFFFFF", y: 30 }); setTxt(""); }}>Adicionar texto</Btn>
        <Btn size="sm" onClick={() => add({ type: "rect", w: 40, h: 6, color: "#7C5CFF", y: 45 })}>Adicionar forma/destaque</Btn>
      </div>
      <p className="text-[11px] text-zinc-600">Emojis aparecem na pré-visualização; no render dependem das fontes do servidor (a fonte embutida não inclui emojis coloridos).</p>
      <div>
        <p className="mb-2 text-sm font-medium">Biblioteca de imagens (B-roll / overlays)</p>
        <div className="flex flex-wrap gap-2">{lib.rows.map((a) => (<button key={a.id} onClick={() => add({ type: "image", assetId: a.id, w: 60, y: 40, start: 3, end: Math.min(d, 8) })} className="overflow-hidden rounded-lg border border-white/10 hover:border-violet-400/60" title={`Adicionar ${a.filename}`}>{/* eslint-disable-next-line @next/next/no-img-element */}<img src={a.url} alt={a.filename} className="h-16 w-24 object-cover" /></button>))}
          <label className="grid h-16 w-24 cursor-pointer place-items-center rounded-lg border border-dashed border-white/15 text-xs text-zinc-500 hover:bg-white/5">+ enviar<input type="file" accept="image/*" className="hidden" onChange={(e) => e.target.files?.[0] && lib.upload(e.target.files[0])} /></label></div>
      </div>
      <div>
        <p className="mb-2 text-sm font-medium">Sugestões de B-roll</p>
        {suggestions.length ? <div className="space-y-2">{suggestions.map((a) => (<div key={a.id} className="flex items-center gap-3 rounded-xl bg-white/[0.04] p-2">{/* eslint-disable-next-line @next/next/no-img-element */}<img src={a.url} alt="" className="h-12 w-20 rounded object-cover" /><span className="flex-1 truncate text-xs">{a.filename}<span className="block text-zinc-500">nome corresponde ao assunto do corte</span></span><Btn size="sm" variant="primary" onClick={() => add({ type: "image", assetId: a.id, w: 60, y: 40, start: 3, end: Math.min(d, 8) })}>Aceitar</Btn><Btn size="sm" variant="ghost" onClick={() => setRejected([...rejected, a.id])}>Rejeitar</Btn></div>))}</div>
          : <p className="text-xs text-zinc-500">Sem sugestões. Sugerimos somente mídias da sua biblioteca cujo nome combine com o assunto (“{full.topic}”). Nenhuma mídia de terceiros é inserida sem sua autorização.</p>}
      </div>
      <div className="space-y-2">{c.elements.map((e) => (
        <div key={e.id} className="grid grid-cols-2 items-end gap-2 rounded-xl bg-white/[0.04] p-3 text-xs sm:grid-cols-6">
          <span className="col-span-2 truncate font-medium sm:col-span-1">{e.type === "text" ? e.text : e.type === "rect" ? "forma" : "imagem"}</span>
          {([["start", "Início"], ["end", "Fim"], ["x", "X%"], ["y", "Y%"]] as const).map(([k, l]) => <label key={k}>{l}<input type="number" step={k === "start" || k === "end" ? 0.1 : 1} className={`${inputCls} !px-2 !py-1.5`} value={e[k]} onChange={(ev) => upEl(e.id, { [k]: Number(ev.target.value) })} /></label>)}
          <div className="flex items-end gap-1">{e.type !== "image" && <input type="color" value={e.color || "#ffffff"} onChange={(ev) => upEl(e.id, { color: ev.target.value })} className="h-8 w-8 rounded bg-transparent" />}<Btn size="sm" variant="danger" onClick={() => upd((p) => ({ ...p, elements: p.elements.filter((x) => x.id !== e.id) }))}><Trash2 className="size-3" /></Btn></div>
        </div>))}</div>
    </div>
  );
}

const TEMPLATES: { name: string; desc: string; caption: keyof typeof captionPresets; hook: Partial<HookConfig>; layout: LayoutMode; cam?: LayoutMode; audio: Partial<AudioFx> }[] = [
  { name: "Podcast", desc: "Legenda limpa, termos em amarelo", caption: "podcast", hook: { font: "Poppins", size: 70, accent: "#FFE14D" }, layout: "fit", audio: { denoise: true, voice: true, normalize: true } },
  { name: "Gameplay", desc: "Legendas virais, jogo + webcam", caption: "viral", hook: { font: "Anton", size: 84, accent: "#39FF88" }, layout: "fit", cam: "A", audio: { normalize: true } },
  { name: "Entrevista", desc: "Texto discreto, voz realçada", caption: "podcast", hook: { font: "Poppins", size: 64, accent: "#FFFFFF" }, layout: "fit", audio: { voice: true, normalize: true } },
  { name: "Educativo", desc: "Destaque em azul, texto grande", caption: "podcast", hook: { font: "Poppins", size: 72, accent: "#4DD2FF" }, layout: "fit", audio: { normalize: true, denoise: true } },
  { name: "Reação", desc: "Palavra por palavra, webcam em PiP", caption: "dinamico", hook: { font: "Anton", size: 90, accent: "#FF4D6D" }, layout: "fit", cam: "C", audio: { normalize: true } },
  { name: "Marketing", desc: "Legenda com fundo, destaque roxo", caption: "personalizado", hook: { font: "Anton", size: 80, accent: "#7C5CFF" }, layout: "fit", audio: { normalize: true, voice: true } },
];

function TemplatesPanel({ c, upd }: { project: ProjectFull; c: Editable; upd: Upd }) {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {TEMPLATES.map((t) => (
        <button key={t.name} onClick={() => upd((e) => { const mode = t.cam && e.layout.cam ? t.cam : t.layout; const sy = safeCaptionY(mode); return { ...e, captionStyle: { ...captionPresets[t.caption], yPct: sy ?? captionPresets[t.caption].yPct }, hook: { ...e.hook, ...t.hook }, layout: { ...e.layout, mode }, audioFx: { ...e.audioFx, ...t.audio } }; })} className="rounded-xl border border-white/10 bg-white/[0.03] p-4 text-left transition hover:border-violet-400/50 hover:bg-white/[0.07]">
          <p className="font-medium">{t.name}</p><p className="text-xs text-zinc-500">{t.desc}</p>
        </button>
      ))}
      <p className="col-span-full text-xs text-zinc-500">Modelos aplicam cor, fonte, estilo de legenda, hook, enquadramento e áudio de uma vez (você pode ajustar depois). Layouts com webcam só são usados quando a região da webcam está definida. {c.layout.cam ? "Webcam definida ✓" : "Webcam não definida."}</p>
    </div>
  );
}

void useMemo; void Progress;
