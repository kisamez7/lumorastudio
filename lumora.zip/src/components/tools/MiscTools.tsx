"use client";
import { useEffect, useRef, useState } from "react";
import { ArrowDown, ArrowUp, Download, Frame, Languages, Layers, Wand2 } from "lucide-react";
import { api, post, useJob } from "@/lib/client";
import { fmtTime } from "@/lib/types";
import { Badge, Btn, Card, Empty, Field, inputCls, JobBar, Notice, PageHeader } from "../ui";
import { RequireProject } from "../ImportPanel";
import type { AssetDto, ProjectFull } from "../ProjectContext";
import type { ClipDto } from "./ClipsTool";

const META: Record<string, [string, string, React.ReactNode]> = {
  compile: ["Compilador de vídeos", "Una vários momentos em uma compilação com transições. Compilações têm duração livre e não são cortes individuais.", <Layers key="i" className="size-5" />],
  "ai-video": ["Gerador de vídeos com IA", "Transforme um roteiro em vídeo de slides animados — local, sem APIs pagas e independente do motor de cortes.", <Wand2 key="i" className="size-5" />],
  thumbnails: ["Miniaturas e capas", "Escolha um quadro do vídeo, adicione texto e exporte capas por rede social.", <Frame key="i" className="size-5" />],
  translate: ["Tradução", "Traduza transcrições e legendas com um modelo local (Ollama).", <Languages key="i" className="size-5" />],
};

export function MiscTool({ tool }: { tool: string }) {
  const m = META[tool];
  return (
    <div>
      <PageHeader title={m[0]} subtitle={m[1]} icon={m[2]} />
      {tool === "ai-video" ? <ScriptVideo /> : <RequireProject>{(p) => (tool === "compile" ? <Compile project={p} /> : tool === "thumbnails" ? <Thumbs project={p} /> : <Translate project={p} />)}</RequireProject>}
    </div>
  );
}

function Compile({ project }: { project: ProjectFull }) {
  const [clips, setClips] = useState<ClipDto[]>([]); const [sel, setSel] = useState<string[]>([]); const [tr, setTr] = useState("fade"); const [title, setTitle] = useState("Melhores momentos"); const [err, setErr] = useState("");
  const load = () => api<ClipDto[]>(`/api/projects/${project.id}/clips`).then(setClips);
  useEffect(() => { void load(); }, [project.id]); // eslint-disable-line react-hooks/exhaustive-deps
  const { job, track, cancel, running } = useJob(() => void load());
  const singles = clips.filter((c) => c.type === "clip"); const comps = clips.filter((c) => c.type === "compilation");
  const move = (i: number, d: number) => setSel((s) => { const n = [...s]; [n[i], n[i + d]] = [n[i + d], n[i]]; return n; });
  const total = sel.reduce((a, id) => { const c = singles.find((x) => x.id === id); return a + (c ? c.endSec - c.startSec : 0); }, 0);
  return (
    <div className="space-y-5">
      <Card>
        <h3 className="mb-3 font-medium">1. Escolha os trechos</h3>
        {!singles.length ? <p className="text-sm text-zinc-500">Gere cortes primeiro.</p> : <div className="grid gap-2 sm:grid-cols-2">{singles.map((c) => <label key={c.id} className="flex cursor-pointer items-center gap-3 rounded-xl bg-white/[0.04] p-3 text-sm"><input type="checkbox" className="accent-violet-500" checked={sel.includes(c.id)} onChange={(e) => setSel((s) => (e.target.checked ? [...s, c.id] : s.filter((x) => x !== c.id)))} /><span className="flex-1 truncate">{c.title}</span><Badge>{c.score}</Badge></label>)}</div>}
      </Card>
      {sel.length > 0 && (
        <Card>
          <h3 className="mb-3 font-medium">2. Ordem e transições <span className="text-sm font-normal text-zinc-500">· ~{fmtTime(total)} no total</span></h3>
          <ul className="space-y-1.5">{sel.map((id, i) => <li key={id} className="flex items-center gap-2 rounded-lg bg-white/[0.04] px-3 py-2 text-sm"><span className="w-5 text-zinc-500">{i + 1}</span><span className="flex-1 truncate">{singles.find((c) => c.id === id)?.title}</span><button disabled={i === 0} onClick={() => move(i, -1)} className="disabled:opacity-30"><ArrowUp className="size-4" /></button><button disabled={i === sel.length - 1} onClick={() => move(i, 1)} className="disabled:opacity-30"><ArrowDown className="size-4" /></button></li>)}</ul>
          <div className="mt-4 grid gap-3 sm:grid-cols-2"><Field label="Título"><input className={inputCls} value={title} onChange={(e) => setTitle(e.target.value)} /></Field><Field label="Transição"><select className={inputCls} value={tr} onChange={(e) => setTr(e.target.value)}><option value="fade">Fade (crossfade)</option><option value="zoomin">Zoom</option><option value="slideleft">Deslizar</option><option value="none">Corte seco</option></select></Field></div>
          <Btn variant="primary" className="mt-4" disabled={sel.length < 2 || running} onClick={async () => { setErr(""); try { track((await post<{ jobId: string }>(`/api/projects/${project.id}/compile`, { clipIds: sel, transition: tr, title })).jobId); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); } }}>Criar compilação</Btn>
          <p className="mt-2 text-xs text-zinc-500">Trechos ainda não renderizados são renderizados primeiro (com hooks e legendas).</p>
          <div className="mt-3"><JobBar job={job} onCancel={cancel} /></div>{err && <Notice tone="rose">{err}</Notice>}
        </Card>
      )}
      {comps.length > 0 && <div><h3 className="mb-3 font-medium">Compilações</h3><div className="grid gap-4 sm:grid-cols-2">{comps.map((c) => <Card key={c.id}><div className="mb-2 flex items-center gap-2"><b className="truncate">{c.title}</b><Badge tone="violet">compilação · {fmtTime(c.renderedDuration ?? 0)}</Badge></div>{c.output && <><video src={c.output.url} controls className="max-h-80 rounded-xl bg-black" /><a href={`${c.output.url}?download=1`}><Btn size="sm" className="mt-2"><Download className="size-3.5" />Baixar MP4</Btn></a></>}</Card>)}</div></div>}
    </div>
  );
}

function ScriptVideo() {
  const [script, setScript] = useState(""); const [aspect, setAspect] = useState("9:16"); const [sec, setSec] = useState(5); const [pal, setPal] = useState(0); const [out, setOut] = useState<AssetDto | null>(null); const [err, setErr] = useState("");
  const { job, track, cancel, running } = useJob(async (j) => { if (j.status === "done") { const id = (j.result as { assetId: string }).assetId; setOut((await api<AssetDto[]>("/api/assets?kind=export")).find((a) => a.id === id) ?? null); } });
  return (
    <div className="space-y-5">
      <Notice tone="blue">Este módulo é independente do motor de cortes e não usa APIs pagas. Gera slides animados com o texto do roteiro (um parágrafo = um slide). <b>Sem narração</b>: síntese de voz local exige um modelo TTS (ex.: Piper) que não está instalado; geração de vídeo por difusão exige GPU e não está incluída.</Notice>
      <Card className="space-y-4">
        <Field label="Roteiro (um parágrafo por linha)"><textarea className={inputCls} rows={8} value={script} onChange={(e) => setScript(e.target.value)} placeholder={"Você sabia que...\nPrimeiro ponto importante\nSegundo ponto\nChame para a ação"} /></Field>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Formato"><select className={inputCls} value={aspect} onChange={(e) => setAspect(e.target.value)}><option>9:16</option><option>16:9</option><option>1:1</option></select></Field>
          <Field label={`Segundos por slide: ${sec}`}><input type="range" min={3} max={12} value={sec} onChange={(e) => setSec(Number(e.target.value))} className="w-full" /></Field>
          <Field label="Paleta"><select className={inputCls} value={pal} onChange={(e) => setPal(Number(e.target.value))}><option value={0}>Violeta / azul</option><option value={1}>Verde / roxo</option><option value={2}>Grafite / magenta</option></select></Field>
        </div>
        <Btn variant="primary" disabled={running || script.trim().length < 5} onClick={async () => { setOut(null); setErr(""); try { track((await post<{ jobId: string }>("/api/ai-video", { script, aspect, secondsPerSlide: sec, palette: pal })).jobId); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); } }}>Gerar vídeo</Btn>
        <JobBar job={job} onCancel={cancel} />{err && <Notice tone="rose">{err}</Notice>}
        {out && <div><video src={out.url} controls className="max-h-96 rounded-xl bg-black" /><a href={`${out.url}?download=1`}><Btn size="sm" className="mt-2"><Download className="size-3.5" />Baixar MP4</Btn></a></div>}
      </Card>
    </div>
  );
}

const COVERS: Record<string, [string, number, number]> = { "TikTok / Reels (9:16)": ["9:16", 720, 1280], "YouTube Shorts (9:16)": ["9:16", 720, 1280], "YouTube (16:9)": ["16:9", 1280, 720], "Facebook / feed (1:1)": ["1:1", 1080, 1080] };

function Thumbs({ project }: { project: ProjectFull }) {
  const [clips, setClips] = useState<ClipDto[]>([]); const [id, setId] = useState(""); const [t, setT] = useState(0); const [cover, setCover] = useState("YouTube (16:9)"); const [text, setText] = useState(""); const [color, setColor] = useState("#FFE14D"); const [pos, setPos] = useState(70);
  const vid = useRef<HTMLVideoElement>(null); const cv = useRef<HTMLCanvasElement>(null);
  useEffect(() => { api<ClipDto[]>(`/api/projects/${project.id}/clips`).then((c) => { const x = c.filter((k) => k.type === "clip"); setClips(x); if (x[0]) { setId(x[0].id); setT(x[0].startSec + 5); setText(x[0].hook.text); } }); }, [project.id]);
  const clip = clips.find((c) => c.id === id);
  const dur = project.source?.durationSec ?? 0;
  const candidates = clip ? [clip.startSec + 2, clip.startSec + clip.hook.start + 1, Number((clip.extra as { peakT?: number }).peakT ?? clip.startSec + 20), clip.startSec + (clip.endSec - clip.startSec) * 0.6].filter((x) => x >= 0 && x < dur) : [];
  const draw = () => {
    const v = vid.current, c = cv.current; if (!v || !c) return; const [, W, H] = COVERS[cover]; c.width = W; c.height = H; const ctx = c.getContext("2d")!;
    const k = Math.max(W / v.videoWidth, H / v.videoHeight); const w = v.videoWidth * k, h = v.videoHeight * k; ctx.drawImage(v, (W - w) / 2, (H - h) / 2, w, h);
    const g = ctx.createLinearGradient(0, H * 0.4, 0, H); g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, "rgba(0,0,0,0.8)"); ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
    const size = Math.round(Math.min(W, H) * (cover.includes("16:9") ? 0.11 : 0.09)); ctx.font = `${size}px Anton, Impact, sans-serif`; ctx.textAlign = "center"; ctx.lineJoin = "round";
    const words = text.toUpperCase().split(/\s+/).filter(Boolean); const lines: string[] = []; let cur = "";
    for (const wd of words) { if (ctx.measureText((cur + " " + wd).trim()).width > W * 0.88 && cur) { lines.push(cur); cur = wd; } else cur = (cur + " " + wd).trim(); } if (cur) lines.push(cur);
    lines.forEach((l, i) => { const y = (pos / 100) * H + i * size * 1.1; ctx.lineWidth = size * 0.16; ctx.strokeStyle = "#000"; ctx.strokeText(l, W / 2, y); ctx.fillStyle = i === lines.length - 1 ? color : "#fff"; ctx.fillText(l, W / 2, y); });
  };
  useEffect(() => { const v = vid.current; if (!v) return; const on = () => draw(); v.addEventListener("seeked", on); v.currentTime = t; return () => v.removeEventListener("seeked", on); }); // eslint-disable-line react-hooks/exhaustive-deps
  if (!clips.length) return <Empty title="Sem cortes">Gere cortes para escolher quadros e criar capas.</Empty>;
  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_340px]">
      <video ref={vid} src={project.source?.url} preload="auto" muted className="hidden" crossOrigin="anonymous" onLoadedData={draw} />
      <Card className="grid place-items-center"><canvas ref={cv} className="max-h-[560px] max-w-full rounded-xl bg-black" /></Card>
      <Card className="space-y-4">
        <Field label="Corte"><select className={inputCls} value={id} onChange={(e) => { const c = clips.find((x) => x.id === e.target.value)!; setId(c.id); setT(c.startSec + 5); setText(c.hook.text); }}>{clips.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</select></Field>
        <div><p className="mb-1.5 text-xs text-zinc-400">Quadros sugeridos (início, hook, pico, desfecho)</p><div className="flex flex-wrap gap-1.5">{candidates.map((c, i) => <button key={i} onClick={() => setT(c)} className="rounded-lg bg-white/[0.06] px-2.5 py-1 text-xs hover:bg-white/10">{fmtTime(c)}</button>)}</div></div>
        <Field label={`Quadro: ${fmtTime(t)}`}><input type="range" min={clip?.startSec ?? 0} max={clip?.endSec ?? dur} step={0.5} value={t} onChange={(e) => setT(Number(e.target.value))} className="w-full" /></Field>
        <Field label="Modelo de capa"><select className={inputCls} value={cover} onChange={(e) => setCover(e.target.value)}>{Object.keys(COVERS).map((k) => <option key={k}>{k}</option>)}</select></Field>
        <Field label="Texto"><input className={inputCls} value={text} onChange={(e) => setText(e.target.value)} /></Field>
        <div className="grid grid-cols-2 gap-3"><Field label="Cor do destaque"><input type="color" value={color} onChange={(e) => setColor(e.target.value)} className="h-10 w-full bg-transparent" /></Field><Field label={`Posição: ${pos}%`}><input type="range" min={20} max={92} value={pos} onChange={(e) => setPos(Number(e.target.value))} className="w-full" /></Field></div>
        <Btn variant="primary" className="w-full" onClick={() => cv.current?.toBlob((b) => { if (!b) return; const a = document.createElement("a"); a.href = URL.createObjectURL(b); a.download = `capa-${cover.split(" ")[0].toLowerCase()}.png`; a.click(); })}><Download className="size-4" />Baixar PNG</Btn>
        <p className="text-[11px] text-zinc-600">Capas são geradas no navegador a partir do seu próprio vídeo — sem marcas d’água.</p>
      </Card>
    </div>
  );
}

function Translate({ project }: { project: ProjectFull }) {
  const [lang, setLang] = useState("inglês"); const [res, setRes] = useState<{ segments: { start: number; text: string }[]; srt: string } | null>(null); const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  if (!project.transcript) return <Empty title="Sem transcrição">Gere a transcrição antes de traduzir.</Empty>;
  return (
    <div className="space-y-5">
      <Card className="flex flex-wrap items-end gap-3"><div className="w-56"><Field label="Idioma de destino"><select className={inputCls} value={lang} onChange={(e) => setLang(e.target.value)}>{["inglês", "espanhol", "francês", "alemão", "italiano", "português do Brasil", "japonês"].map((l) => <option key={l}>{l}</option>)}</select></Field></div>
        <Btn variant="primary" loading={busy} onClick={async () => { setBusy(true); setErr(""); setRes(null); try { setRes(await post(`/api/projects/${project.id}/translate`, { lang })); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); } setBusy(false); }}>Traduzir transcrição</Btn></Card>
      {err && <Notice>{err}</Notice>}
      <p className="text-xs text-zinc-500">A tradução usa um LLM local (Ollama). Áudio dublado/traduzido exige modelos TTS e não está disponível nesta instalação.</p>
      {res && <Card><div className="mb-3 flex items-center justify-between"><b>Tradução ({lang})</b><Btn size="sm" onClick={() => { const a = document.createElement("a"); a.href = URL.createObjectURL(new Blob([res.srt], { type: "text/plain" })); a.download = `legendas-${lang}.srt`; a.click(); }}><Download className="size-3.5" />Baixar SRT</Btn></div><div className="max-h-96 space-y-1 overflow-y-auto text-sm">{res.segments.map((s, i) => <p key={i}><span className="mr-2 text-violet-300">{fmtTime(s.start)}</span>{s.text}</p>)}</div></Card>}
    </div>
  );
}
