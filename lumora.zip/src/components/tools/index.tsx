"use client";
import { ClipsTool } from "./ClipsTool";
import { ClipEditor } from "./ClipEditor";
import { UnderstandTool } from "./UnderstandTools";
import { DownloadTool } from "./DownloadTools";
import { PublishTool } from "./PublishTools";
import { MiscTool } from "./MiscTools";
import { Empty, PageHeader } from "../ui";

export function ToolRouter({ tool }: { tool: string }) {
  switch (tool) {
    case "clips": return <ClipsTool />;
    case "game": return <ClipsTool game />;
    case "editor": case "captions": case "hooks": case "reframe": case "audio": case "broll":
      return <ClipEditor panel={tool} />;
    case "summary": case "transcript": case "moments": case "chat": case "mindmap": case "notes":
      return <UnderstandTool tool={tool} />;
    case "downloader": case "converter": case "audio-extract": case "downloads":
      return <DownloadTool tool={tool} />;
    case "titles": case "descriptions": case "hashtags": case "publish": case "calendar":
      return <PublishTool tool={tool} />;
    case "compile": case "ai-video": case "thumbnails": case "translate":
      return <MiscTool tool={tool} />;
    default:
      return <div><PageHeader title="Ferramenta não encontrada" /><Empty title="Esta ferramenta não existe" /></div>;
  }
}
