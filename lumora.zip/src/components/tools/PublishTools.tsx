"use client";
import { useCallback, useEffect, useState } from "react";
import { CalendarDays, Copy, Hash, Heading, AlignLeft, Send, Trash2 } from "lucide-react";
import { api, del, patch, post } from "@/lib/client";
import { Badge, Btn, Card, Empty, Field, inputCls, Notice, PageHeader } from "../ui";
import { RequireProject } from "../ImportPanel";
import type { ClipDto } from "./ClipsTool";
import type { ProjectFull } from "../ProjectContext";
import { useProject } from "../ProjectContext";

type Gen = { titles: string[]; platforms: { platform: string; description: string; hashtags: string[] }[] };
type Item = { id: string; projectId: string | null; clipId: string | null; platform: string; title: string; description: string; hashtags: string[]; scheduledAt: string | null; status: string };
const PLAT: Record<string, string> = { tiktok: "TikTok", reels: "Instagram Reels", shorts: "YouTube Shorts", facebook: "Facebook Reels" };
const META: Record<string, [string, string, React.ReactNode]> = {
  titles: ["Gerador de títulos", "Títulos baseados no conteúdo real de cada corte.", <Heading key="i" className="size-5" />],
  descriptions: ["Descrições", "Descrições adaptadas ao limite e estilo de cada rede.", <AlignLeft key="i" className="size-5" />],
  hashtags: ["Hashtags", "Hashtags a partir do assunto e do nicho do trecho.", <Hash key="i" className="size-5" />],
  publish: ["Preparação para publicação", "Organize por rede, edite metadados, agende e exporte para publicação manual.", <Send key="i" className="size-5" />],
  calendar: ["Calendário de conteúdo", "Planejamento mensal dos conteúdos agendados.", <CalendarDays key="i" className="size-5" />],
};
const copy = (t: string) => navigator.clipboard?.writeText(t);

export function PublishTool({ tool }: { tool: string }) {
  const m = META[tool];
  return (
    <div>
      <PageHeader title={m[0]} subtitle={m[1]} icon={m[2]} />
      <RequireProject>{(p) => (tool === "calendar" ? <Calendar project={p} /> : tool === "publish" ? <Prepare project={p} /> : <Generator project={p} tool={tool} />)}</RequireProject>
    </div>
  );
}

function useClips(project: ProjectFull) {
  const [clips, setClips] = useState<ClipDto[]>([]); const [id, setId] = useState("");
  useEffect(() => { api<ClipDto[]>(`/api/projects/${project.id}/clips`).then((c) => { const x = c.filter((k) => k.type === "clip"); setClips(x); setId(localStorage.getItem("lumora.clip") && x.find((k) => k.id === localStorage.getItem("lumora.clip")) ? localStorage.getItem("lumora.clip")! : x[0]?.id ?? ""); }); }, [project.id]);
  return { clips, id, setId, clip: clips.find((c) => c.id === id) };
}

function Generator({ project, tool }: { project: ProjectFull; tool: string }) {
  const { clips, id, setId, clip } = useClips(project);
  const [g, setG] = useState<Gen | null>(null); const [title, setTitle] = useState(""); const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  const gen = async () => { setBusy(true); setMsg(""); try { const r = await post<Gen>("/api/publish/generate", { clipId: id }); setG(r); setTitle(r.titles[0] ?? ""); } catch (e) { setMsg(e instanceof Error ? e.message : "Erro"); } setBusy(false); };
  const save = async () => { if (!g) return; for (const p of g.platforms) await post("/api/publish", { projectId: project.id, clipId: id, platform: p.platform, title, description: p.description, hashtags: p.hashtags }); setMsg("Salvo em Preparação para publicação (um item por rede)."); };
  if (!clips.length) return <Empty title="Sem cortes">Crie cortes antes de gerar metadados.</Empty>;
  return (
    <div className="space-y-5">
      <Card className="flex flex-wrap items-end gap-3"><div className="min-w-[240px] flex-1"><Field label="Corte"><select className={inputCls} value={id} onChange={(e) => { setId(e.target.value); setG(null); }}>{clips.map((c) => <option key={c.id} value={c.id}>{c.title}</option>)}</select></Field></div><Btn variant="primary" loading={busy} onClick={gen}>Gerar com base no conteúdo</Btn></Card>
      {clip && !clip.spokenText && <Notice>Este corte não tem transcrição; os metadados serão genéricos.</Notice>}
      {msg && <Notice tone="blue">{msg}</Notice>}
      {g && (
        <div className="space-y-5">
          {(tool === "titles" || tool === "descriptions") && (
            <Card><h3 className="mb-3 font-medium">Títulos</h3><div className="space-y-2">{g.titles.map((t) => (
              <div key={t} className={`flex items-center gap-3 rounded-xl border p-3 text-sm ${title === t ? "border-violet-400/60 bg-violet-500/10" : "border-white/10"}`}><button className="flex-1 text-left" onClick={() => setTitle(t)}>{t}</button><span className="text-[11px] text-zinc-500">{t.length} car.</span><button onClick={() => copy(t)} className="text-zinc-400 hover:text-white"><Copy className="size-4" /></button></div>))}</div></Card>
          )}
          {(tool === "descriptions" || tool === "hashtags") && (
            <div className="grid gap-4 md:grid-cols-2">{g.platforms.map((p) => (
              <Card key={p.platform}><div className="mb-2 flex items-center justify-between"><b>{PLAT[p.platform]}</b><Badge>{p.description.length} car.</Badge></div>
                {tool === "descriptions" && <p className="whitespace-pre-line text-sm text-zinc-300">{p.description}</p>}
                <div className="mt-3 flex flex-wrap gap-1.5">{p.hashtags.map((h) => <Badge key={h} tone="blue">{h}</Badge>)}</div>
                <Btn size="sm" className="mt-3" onClick={() => copy(`${tool === "descriptions" ? p.description + "\n\n" : ""}${p.hashtags.join(" ")}`)}><Copy className="size-3.5" />Copiar</Btn></Card>))}</div>
          )}
          <Btn variant="primary" onClick={save}>Salvar para publicação</Btn>
        </div>
      )}
    </div>
  );
}

function Prepare({ project }: { project: ProjectFull }) {
  const [items, setItems] = useState<Item[]>([]); const [clips, setClips] = useState<ClipDto[]>([]);
  const load = useCallback(() => api<Item[]>(`/api/publish?projectId=${project.id}`).then(setItems), [project.id]);
  useEffect(() => { void load(); api<ClipDto[]>(`/api/projects/${project.id}/clips`).then(setClips); }, [load, project.id]);
  const save = async (it: Item, p: Partial<Item>) => { await patch("/api/publish", { id: it.id, ...p }); await load(); };
  const by = (pl: string) => items.filter((i) => i.platform === pl);
  return (
    <div className="space-y-5">
      <Notice tone="blue">Publicação automática só é possível via APIs oficiais com as permissões da sua conta — nenhuma integração está configurada nesta instalação. Use “Copiar metadados” e o download do vídeo para publicar manualmente.</Notice>
      {!items.length && <Empty title="Nada preparado ainda">Gere títulos/descrições em <a href="/t/titles" className="text-violet-300 underline">Gerador de títulos</a> e salve aqui.</Empty>}
      {Object.keys(PLAT).map((pl) => by(pl).length > 0 && (
        <div key={pl}><h3 className="mb-2 font-medium">{PLAT[pl]}</h3>
          <div className="space-y-3">{by(pl).map((it) => { const clip = clips.find((c) => c.id === it.clipId); return (
            <Card key={it.id} className="space-y-3">
              <div className="flex flex-wrap items-center gap-2"><Badge tone={it.status === "published" ? "green" : it.status === "scheduled" ? "violet" : "zinc"}>{it.status}</Badge><span className="text-xs text-zinc-500">{clip?.title}</span></div>
              <input className={inputCls} defaultValue={it.title} onBlur={(e) => e.target.value !== it.title && save(it, { title: e.target.value })} />
              <textarea className={inputCls} rows={3} defaultValue={it.description} onBlur={(e) => e.target.value !== it.description && save(it, { description: e.target.value })} />
              <input className={inputCls} defaultValue={it.hashtags.join(" ")} onBlur={(e) => save(it, { hashtags: e.target.value.split(/\s+/).filter(Boolean) })} />
              <div className="flex flex-wrap items-center gap-2">
                <input type="datetime-local" className={`${inputCls} !w-auto`} defaultValue={it.scheduledAt ? new Date(new Date(it.scheduledAt).getTime() - new Date().getTimezoneOffset() * 60000).toISOString().slice(0, 16) : ""} onBlur={(e) => e.target.value && save(it, { scheduledAt: new Date(e.target.value).toISOString(), status: "scheduled" })} />
                <Btn size="sm" onClick={() => copy(`${it.title}\n\n${it.description}\n\n${it.hashtags.join(" ")}`)}><Copy className="size-3.5" />Copiar metadados</Btn>
                {clip?.output && <a href={`${clip.output.url}?download=1`}><Btn size="sm">Baixar vídeo</Btn></a>}
                <Btn size="sm" onClick={() => save(it, { status: "published" })}>Marcar como publicado</Btn>
                <Btn size="sm" variant="danger" onClick={async () => { await del(`/api/publish?id=${it.id}`); load(); }}><Trash2 className="size-3.5" /></Btn>
              </div>
            </Card>); })}</div></div>
      ))}
    </div>
  );
}

function Calendar({ project }: { project: ProjectFull }) {
  const { projects } = useProject(); void projects;
  const [items, setItems] = useState<Item[]>([]); const [month, setMonth] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); });
  useEffect(() => { api<Item[]>(`/api/publish?projectId=${project.id}`).then(setItems); }, [project.id]);
  const first = month.getDay(); const days = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const cells = Array.from({ length: first + days }, (_, i) => (i < first ? null : i - first + 1));
  const at = (d: number) => items.filter((i) => i.scheduledAt && new Date(i.scheduledAt).getFullYear() === month.getFullYear() && new Date(i.scheduledAt).getMonth() === month.getMonth() && new Date(i.scheduledAt).getDate() === d);
  return (
    <Card>
      <div className="mb-4 flex items-center justify-between"><Btn size="sm" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))}>←</Btn><b className="capitalize">{month.toLocaleDateString("pt-BR", { month: "long", year: "numeric" })}</b><Btn size="sm" onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))}>→</Btn></div>
      <div className="grid grid-cols-7 gap-1.5 text-center text-[11px] text-zinc-500">{["D", "S", "T", "Q", "Q", "S", "S"].map((d, i) => <span key={i}>{d}</span>)}</div>
      <div className="mt-1.5 grid grid-cols-7 gap-1.5">{cells.map((d, i) => (
        <div key={i} className={`min-h-20 rounded-lg p-1.5 text-xs ${d ? "bg-white/[0.04]" : ""}`}>{d && <><span className="text-zinc-500">{d}</span>{at(d).map((it) => <div key={it.id} className="mt-1 truncate rounded bg-violet-500/25 px-1 py-0.5 text-[10px] text-violet-100" title={it.title}>{PLAT[it.platform].split(" ")[0]} · {it.title}</div>)}</>}</div>))}</div>
      <p className="mt-4 text-xs text-zinc-500">Agende itens em Preparação para publicação (campo de data/hora). O calendário é de planejamento — não publica sozinho.</p>
    </Card>
  );
}
