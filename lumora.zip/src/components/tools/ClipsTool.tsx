"use client";
import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import { ChevronDown, Clapperboard, Download, Film, Gamepad2, Play, Scissors, Sparkles, Trash2, Wand2 } from "lucide-react";
import { api, del, patch, post, put, useJob, waitJob } from "@/lib/client";
import { CLIP_MAX, CLIP_MIN, fmtTime, safeCaptionY, type HookConfig, type JobInfo, type Rect } from "@/lib/types";
import { Badge, Btn, Card, Empty, Field, inputCls, JobBar, Notice, PageHeader, Progress } from "../ui";
import { RequireProject, SourceCard } from "../ImportPanel";
import { RectPicker } from "../RectPicker";
import type { AssetDto, ProjectFull } from "../ProjectContext";
import { useProject } from "../ProjectContext";

export type ClipDto = {
  id: string; projectId: string; type: string; title: string; startSec: number; endSec: number; score: number; scoreBreakdown: Record<string, { score: number; why: string }>;
  justification: string; description: string; topic: string; context: string; visualEvent: string; spokenText: string; editorialPotential: string;
  hookOptions: { text: string; approach: string; source: string; recommended?: boolean }[]; hook: HookConfig; captions: unknown[]; status: string; renderedDuration: number | null; output: AssetDto | null;
  extra: Record<string, unknown>;
};

export function ClipsTool({ game }: { game?: boolean }) {
  return (
    <div>
      <PageHeader
        title={game ? "Game Clipping" : "Criador de cortes"}
        subtitle={game ? "Encontra jogadas, reações e momentos engraçados e reorganiza gameplay + webcam em vertical." : "A IA analisa 100% do vídeo, compara todos os momentos e entrega cortes de 60 a 90 segundos."}
        icon={game ? <Gamepad2 className="size-5" /> : <Scissors className="size-5" />}
      />
      <RequireProject>{(p) => <Inner project={p} game={!!game} />}</RequireProject>
    </div>
  );
}

function Inner({ project, game }: { project: ProjectFull; game: boolean }) {
  const { reload } = useProject();
  const [clips, setClips] = useState<ClipDto[]>([]);
  const [count, setCount] = useState<string>("auto");
  const [transcribe, setTranscribe] = useState(true);
  const [lang, setLang] = useState("pt");
  const [warnings, setWarnings] = useState<string[]>([]);
  const [jobs, setJobs] = useState<Record<string, JobInfo>>({});
  const [open, setOpen] = useState<string | null>(null);
  const [cam, setCam] = useState<Rect | null>((project.settings.cam as Rect) ?? null);
  const [gameRect, setGameRect] = useState<Rect | null>((project.settings.game as Rect) ?? null);
  const [msg, setMsg] = useState("");
  const load = useCallback(() => api<ClipDto[]>(`/api/projects/${project.id}/clips`).then((c) => setClips(c.filter((x) => x.type === "clip"))), [project.id]);
  useEffect(() => { void load(); }, [load]);
  const { job, track, cancel, running } = useJob((j) => {
    if (j.status === "done") setWarnings(((j.result as { warnings?: string[] })?.warnings) ?? []);
    void load(); void reload();
  });
  const dur = project.source?.durationSec ?? 0;

  const analyze = async () => {
    setWarnings([]);
    const r = await post<{ jobId: string }>(`/api/projects/${project.id}/analyze`, { transcribe, count: count === "auto" ? "auto" : Number(count), kind: game ? "game" : project.kind, language: lang });
    track(r.jobId);
  };
  const render = async (c: ClipDto) => {
    try {
      const r = await post<{ jobId: string }>(`/api/clips/${c.id}/render`);
      const j = await waitJob(r.jobId, (x) => setJobs((s) => ({ ...s, [c.id]: x })));
      if (j.status === "failed") setMsg(j.error || "Falha no render");
    } catch (e) { setMsg(e instanceof Error ? e.message : "Erro"); }
    await load();
    setJobs((s) => { const n = { ...s }; delete n[c.id]; return n; });
  };
  const saveCam = async (apply: boolean) => {
    await patch(`/api/projects/${project.id}`, { settings: { cam, game: gameRect } });
    if (apply) {
      for (const c of clips) {
        const d = await api<{ layout: object; captionStyle: { yPct: number } }>(`/api/clips/${c.id}`);
        const mode = cam ? "A" : "fit";
        await patch(`/api/clips/${c.id}`, { layout: { ...d.layout, mode, cam, game: gameRect }, captionStyle: { ...d.captionStyle, yPct: safeCaptionY(mode) ?? d.captionStyle.yPct } });
      }
      await load();
    }
    setMsg(apply ? "Webcam aplicada a todos os cortes (layout A)." : "Região salva no projeto.");
  };
  const autoCam = async () => {
    try { const r = await post<{ cam?: Rect | null }>(`/api/projects/${project.id}/webcam`); if (r.cam) setCam(r.cam); else setMsg("Nenhuma webcam detectada automaticamente."); } catch (e) { setMsg(e instanceof Error ? e.message : "Erro"); }
  };

  return (
    <div className="space-y-6">
      <SourceCard project={project} onChange={reload} />
      <Card>
        <div className="mb-4 flex items-center gap-2"><Sparkles className="size-5 text-violet-300" /><h2 className="font-medium">Análise inteligente</h2>
          {project.transcript ? <Badge tone="green">transcrição: {project.transcript.engine}</Badge> : <Badge tone="amber">sem transcrição</Badge>}</div>
        <div className="grid gap-4 sm:grid-cols-3">
          <Field label="Quantidade de cortes" hint={`Sempre ${CLIP_MIN}–${CLIP_MAX} s cada. “IA decide” também respeita o intervalo.`}>
            <select className={inputCls} value={count} onChange={(e) => setCount(e.target.value)}><option value="auto">Deixe a IA decidir</option>{[3, 5, 8, 10, 12].map((n) => <option key={n} value={n}>{n} melhores</option>)}</select>
          </Field>
          <Field label="Idioma da fala"><select className={inputCls} value={lang} onChange={(e) => setLang(e.target.value)}>{[["pt", "Português (BR)"], ["en", "English"], ["es", "Español"], ["auto", "Detectar"]].map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></Field>
          <label className="flex items-center gap-2 self-end pb-3 text-sm text-zinc-300"><input type="checkbox" checked={transcribe} onChange={(e) => setTranscribe(e.target.checked)} className="size-4 accent-violet-500" />Transcrever com Whisper local</label>
        </div>
        <p className="mt-3 text-xs text-zinc-500">Etapas reais: áudio (RMS 100%) → imagem (diferença temporal de quadros 100%, 2 fps + refinamento a 8 fps nos trechos escolhidos) → transcrição → comparação global de janelas → hooks, legendas e pontuação. Vídeos longos podem demorar na CPU; a tarefa roda em segundo plano e pode ser cancelada.</p>
        <div className="mt-4 flex flex-wrap items-center gap-3">
          <Btn variant="primary" onClick={analyze} disabled={running}><Wand2 className="size-4" />{clips.length ? "Analisar novamente" : "Analisar e encontrar melhores momentos"}</Btn>
          {!project.transcript && <Link href="/t/transcript" className="text-xs text-violet-300 underline">ou importe um SRT/VTT</Link>}
        </div>
        <div className="mt-4"><JobBar job={job} onCancel={cancel} /></div>
        {warnings.map((w, i) => <div key={i} className="mt-2"><Notice>{w}</Notice></div>)}
        {project.analysis?.coverage && (
          <div className="mt-4 grid grid-cols-2 gap-3 text-xs sm:grid-cols-5">
            {([["Duração", fmtTime(Number(project.analysis.coverage.videoSeconds))], ["Áudio analisado", `${project.analysis.coverage.audioSecondsAnalyzed}s (${project.analysis.coverage.coveragePct}%)`], ["Amostras visuais", `${project.analysis.coverage.visualSamples} @${project.analysis.coverage.visualSampleFps}fps`], ["Cortes de cena", String(project.analysis.coverage.sceneCuts)], ["Janelas avaliadas", String((project.analysis.coverage.selection as { windows?: number })?.windows ?? "—")]] as string[][]).map(([k, v]) => <div key={k} className="rounded-xl bg-white/[0.04] p-3"><p className="text-zinc-500">{k}</p><p className="mt-0.5 font-medium text-zinc-200">{v}</p></div>)}
          </div>
        )}
      </Card>

      {game && (
        <Card>
          <h2 className="mb-1 font-medium">Webcam e gameplay</h2>
          <p className="mb-4 text-xs text-zinc-500">Marque a webcam (em qualquer posição) e, se quiser, a área principal do jogo. Os layouts A/B/C usam esses recortes sem deformar a imagem. Se a webcam já está embutida na gravação, o sistema apenas recorta — não reconstrói a área de jogo coberta.</p>
          <div className="grid gap-5 lg:grid-cols-2">
            <div><p className="mb-2 text-xs font-medium text-emerald-300">Webcam</p><RectPicker src={`/api/projects/${project.id}/frame?t=${Math.round(dur * 0.3)}&w=960`} value={cam} onChange={setCam} label="WEBCAM" /></div>
            <div><p className="mb-2 text-xs font-medium text-blue-300">Área do jogo (opcional — padrão: quadro inteiro)</p><RectPicker src={`/api/projects/${project.id}/frame?t=${Math.round(dur * 0.3)}&w=960`} value={gameRect} onChange={setGameRect} color="#60a5fa" label="JOGO" /></div>
          </div>
          <div className="mt-4 flex flex-wrap gap-2"><Btn onClick={() => saveCam(false)}>Salvar região</Btn><Btn variant="primary" disabled={!clips.length} onClick={() => saveCam(true)}>Salvar e aplicar a todos os cortes</Btn><Btn onClick={autoCam}>Detectar automaticamente (serviço CV)</Btn></div>
        </Card>
      )}
      {msg && <Notice tone="blue">{msg}</Notice>}

      <div>
        <div className="mb-3 flex items-center justify-between"><h2 className="font-medium">Cortes sugeridos <span className="text-sm font-normal text-zinc-500">({clips.length}) · ordenados por nota, não por posição</span></h2></div>
        {!clips.length ? <Empty title="Nenhum corte ainda" icon={<Film className="size-10" />}>Rode a análise. Para vídeos curtos (&lt; 61 s) cortes individuais não se aplicam.</Empty> : (
          <div className="space-y-4">
            {clips.map((c) => {
              const d = c.endSec - c.startSec;
              const j = jobs[c.id];
              return (
                <Card key={c.id} className="rise !p-0 overflow-hidden">
                  <div className="grid gap-0 lg:grid-cols-[1fr_260px]">
                    <div className="p-5">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="grad-bg grid size-12 place-items-center rounded-xl text-lg font-bold text-white">{c.score}</span>
                        <div className="min-w-0 flex-1"><p className="truncate font-medium">{c.title}</p><p className="text-xs text-zinc-500">{fmtTime(c.startSec)} → {fmtTime(c.endSec)} · <b className={d >= CLIP_MIN && d <= CLIP_MAX ? "text-emerald-300" : "text-rose-300"}>{d.toFixed(1)} s</b> · {c.editorialPotential}</p></div>
                        {c.status === "rendered" && <Badge tone="green">renderizado {c.renderedDuration?.toFixed(1)} s</Badge>}
                        {c.status === "failed" && <Badge tone="rose">falhou</Badge>}
                      </div>
                      <p className="mt-3 text-sm text-zinc-300">{c.description}</p>
                      <p className="mt-2 text-xs text-zinc-500">{c.justification}</p>
                      {c.hookOptions.length > 0 ? (
                        <div className="mt-4"><p className="mb-1.5 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">Hooks (frases de impacto) — ativos por padrão</p>
                          <div className="flex flex-wrap gap-2">{c.hookOptions.map((h) => (
                            <button key={h.text} onClick={async () => { await patch(`/api/clips/${c.id}`, { hook: { ...c.hook, text: h.text, enabled: true } }); load(); }} className={`rounded-lg border px-2.5 py-1.5 text-left text-xs transition ${c.hook.text === h.text ? "border-violet-400/60 bg-violet-500/15 text-white" : "border-white/10 bg-white/[0.03] text-zinc-300 hover:bg-white/[0.08]"}`}>
                              <span className="block font-semibold tracking-wide">{h.text}</span><span className="text-[10px] text-zinc-500">{h.approach}{h.recommended ? " · recomendado" : ""}</span></button>
                          ))}</div></div>
                      ) : <p className="mt-3 text-xs text-amber-300">Sem transcrição neste trecho: hooks automáticos indisponíveis (edite manualmente no editor).</p>}
                      <button onClick={() => setOpen(open === c.id ? null : c.id)} className="mt-4 flex items-center gap-1 text-xs text-violet-300"><ChevronDown className={`size-4 transition ${open === c.id ? "rotate-180" : ""}`} />Detalhes da pontuação e contexto</button>
                      {open === c.id && (
                        <div className="rise mt-3 space-y-3 text-xs">
                          <div className="grid gap-2 sm:grid-cols-2">{Object.entries(c.scoreBreakdown).map(([k, v]) => (<div key={k} className="rounded-lg bg-white/[0.04] p-2.5"><div className="mb-1 flex justify-between"><span className="text-zinc-300">{k}</span><span className="font-medium">{v.score}</span></div><Progress value={v.score} /><p className="mt-1 text-[11px] text-zinc-500">{v.why}</p></div>))}</div>
                          <p><b className="text-zinc-300">Assunto:</b> <span className="text-zinc-400">{c.topic}</span></p>
                          <p><b className="text-zinc-300">Contexto:</b> <span className="text-zinc-400">{c.context}</span></p>
                          <p><b className="text-zinc-300">Acontecimento visual:</b> <span className="text-zinc-400">{c.visualEvent}</span></p>
                          <p><b className="text-zinc-300">Conteúdo falado:</b> <span className="text-zinc-400">{c.spokenText || "—"}</span></p>
                          <p className="text-zinc-600">A nota é uma estimativa editorial heurística; não é garantia de viralização.</p>
                        </div>
                      )}
                    </div>
                    <div className="border-t border-white/[0.06] bg-black/20 p-4 lg:border-l lg:border-t-0">
                      {c.output ? <video src={c.output.url} controls className="mx-auto aspect-[9/16] max-h-[360px] rounded-xl bg-black" /> : <div className="mx-auto grid aspect-[9/16] max-h-[200px] place-items-center rounded-xl border border-dashed border-white/10 text-xs text-zinc-600">pré-visualização após renderizar</div>}
                      {j && <div className="mt-3 space-y-1"><Progress value={j.progress} /><p className="text-[11px] text-zinc-500">{j.message} {j.progress}%</p></div>}
                      <div className="mt-3 grid gap-2">
                        <Btn size="sm" variant="primary" onClick={() => render(c)} disabled={!!j}><Play className="size-3.5" />{c.output ? "Renderizar novamente" : "Renderizar corte"}</Btn>
                        <Link href="/t/editor" onClick={() => localStorage.setItem("lumora.clip", c.id)}><Btn size="sm" className="w-full"><Clapperboard className="size-3.5" />Abrir no editor</Btn></Link>
                        {c.output && <a href={`${c.output.url}?download=1`}><Btn size="sm" className="w-full"><Download className="size-3.5" />Baixar MP4</Btn></a>}
                        <Btn size="sm" variant="ghost" onClick={async () => { await del(`/api/clips/${c.id}`); load(); }}><Trash2 className="size-3.5" />Descartar</Btn>
                      </div>
                    </div>
                  </div>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

void put;
