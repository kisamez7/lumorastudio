"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import {
  LayoutDashboard, Plus, Clock, Scissors, Gamepad2, Layers, Wand2, FileText, Captions, Search, MessageSquare, Network, StickyNote, Clapperboard, Type, Zap, Crop, Image as ImageIcon,
  Music, Frame, Languages, Download, RefreshCw, AudioLines, FolderDown, Heading, AlignLeft, Hash, CalendarDays, Send, History, Files, Settings, Menu, X, Sparkles, ChevronsUpDown,
} from "lucide-react";
import { ProjectProvider, useProject } from "./ProjectContext";

const NAV = [
  { title: "Início", items: [["Dashboard", "/dashboard", LayoutDashboard], ["Novo projeto", "/new", Plus], ["Projetos recentes", "/projects", Clock]] },
  { title: "Criar", items: [["Criador de cortes", "/t/clips", Scissors], ["Game Clipping", "/t/game", Gamepad2], ["Compilador de vídeos", "/t/compile", Layers], ["Gerador de vídeos com IA", "/t/ai-video", Wand2]] },
  { title: "Entender", items: [["Resumo de vídeos", "/t/summary", FileText], ["Transcrição", "/t/transcript", Captions], ["Busca de momentos", "/t/moments", Search], ["Chat com vídeos", "/t/chat", MessageSquare], ["Mapas mentais", "/t/mindmap", Network], ["Anotações", "/t/notes", StickyNote]] },
  { title: "Editar", items: [["Editor profissional", "/t/editor", Clapperboard], ["Legendas", "/t/captions", Type], ["Hooks", "/t/hooks", Zap], ["Reenquadramento", "/t/reframe", Crop], ["B-roll", "/t/broll", ImageIcon], ["Áudio", "/t/audio", Music], ["Miniaturas", "/t/thumbnails", Frame], ["Tradução", "/t/translate", Languages]] },
  { title: "Baixar", items: [["Downloader por URL", "/t/downloader", Download], ["Conversor de vídeos", "/t/converter", RefreshCw], ["Extração de áudio", "/t/audio-extract", AudioLines], ["Arquivos baixados", "/t/downloads", FolderDown]] },
  { title: "Publicar", items: [["Gerador de títulos", "/t/titles", Heading], ["Descrições", "/t/descriptions", AlignLeft], ["Hashtags", "/t/hashtags", Hash], ["Calendário de conteúdo", "/t/calendar", CalendarDays], ["Preparação para publicação", "/t/publish", Send]] },
  { title: "Projetos", items: [["Histórico", "/history", History], ["Arquivos", "/files", Files], ["Configurações", "/settings", Settings]] },
] as const;

export function Logo({ size = "md" }: { size?: "md" | "lg" }) {
  return (
    <Link href="/" className="flex items-center gap-2.5">
      <span className={`grad-bg grid place-items-center rounded-xl text-white shadow-lg shadow-violet-500/30 ${size === "lg" ? "size-11" : "size-9"}`}>
        <Sparkles className={size === "lg" ? "size-6" : "size-5"} />
      </span>
      <span className="leading-none">
        <span className={`block font-semibold tracking-tight ${size === "lg" ? "text-2xl" : "text-lg"}`}>Lumora<span className="grad-text">.studio</span></span>
        <span className="mt-0.5 block text-[10px] uppercase tracking-[0.18em] text-zinc-500">IA para vídeos</span>
      </span>
    </Link>
  );
}

function ProjectPicker() {
  const { projects, currentId, setCurrent } = useProject();
  return (
    <div className="relative">
      <ChevronsUpDown className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-zinc-500" />
      <select value={currentId ?? ""} onChange={(e) => setCurrent(e.target.value || null)} className="w-full appearance-none rounded-xl border border-white/10 bg-black/40 py-2.5 pl-3 pr-9 text-sm text-zinc-200 outline-none focus:border-violet-400/60">
        <option value="">Nenhum projeto selecionado</option>
        {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
      </select>
    </div>
  );
}

function Inner({ children }: { children: ReactNode }) {
  const path = usePathname();
  const [open, setOpen] = useState(false);
  const nav = (
    <nav className="flex h-full flex-col gap-5 overflow-y-auto px-4 pb-8">
      {NAV.map((g) => (
        <div key={g.title}>
          <p className="mb-1.5 px-3 text-[10px] font-semibold uppercase tracking-[0.16em] text-zinc-600">{g.title}</p>
          <ul className="space-y-0.5">
            {g.items.map(([label, href, Icon]) => {
              const active = path === href;
              return (
                <li key={href}>
                  <Link href={href} onClick={() => setOpen(false)} className={`group flex items-center gap-3 rounded-xl px-3 py-2 text-[13px] transition ${active ? "bg-gradient-to-r from-violet-500/20 to-blue-500/10 text-white ring-1 ring-violet-400/30" : "text-zinc-400 hover:bg-white/[0.05] hover:text-zinc-100"}`}>
                    <Icon className={`size-4 shrink-0 ${active ? "text-violet-300" : "text-zinc-500 group-hover:text-zinc-300"}`} />
                    {label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </div>
      ))}
    </nav>
  );
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[272px_1fr]">
      <aside className="sticky top-0 hidden h-screen flex-col border-r border-white/[0.06] bg-[#09090f] lg:flex">
        <div className="space-y-4 p-5"><Logo /><ProjectPicker /></div>
        <div className="min-h-0 flex-1">{nav}</div>
      </aside>
      <div className="flex items-center justify-between border-b border-white/[0.06] bg-[#09090f] px-4 py-3 lg:hidden">
        <Logo />
        <button onClick={() => setOpen(true)} aria-label="Abrir menu" className="rounded-lg p-2 hover:bg-white/10"><Menu className="size-5" /></button>
      </div>
      {open && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/70" onClick={() => setOpen(false)} />
          <div className="absolute inset-y-0 left-0 flex w-[290px] flex-col bg-[#09090f]">
            <div className="flex items-center justify-between p-4"><Logo /><button onClick={() => setOpen(false)}><X className="size-5" /></button></div>
            <div className="px-4 pb-3"><ProjectPicker /></div>
            <div className="min-h-0 flex-1">{nav}</div>
          </div>
        </div>
      )}
      <main className="min-w-0 px-4 py-6 sm:px-8 lg:py-9">
        <div className="mx-auto max-w-6xl">{children}</div>
      </main>
    </div>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  return <ProjectProvider><Inner>{children}</Inner></ProjectProvider>;
}
