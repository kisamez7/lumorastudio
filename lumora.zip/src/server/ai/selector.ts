import { PLAN_MAX, PLAN_MIN, fmtTime, type ScoreBreakdown, type Segment } from "@/lib/types";
import { addSignals, cap, isTerminal, jaccard, keywordSet, sentences, signalsOf, textInterest, topKeywords, zeroSignals, type Signals } from "./text";

export type Candidate = {
  start: number;
  end: number;
  score: number;
  raw: number;
  breakdown: ScoreBreakdown;
  justification: string;
  description: string;
  topic: string;
  context: string;
  visualEvent: string;
  spokenText: string;
  editorialPotential: string;
  tags: string[];
  peakT: number;
};

export type SelectInput = {
  duration: number;
  segments: Segment[];
  energy: number[];
  motion: number[];
  cuts: number[];
  kind: string; // general | game | podcast | educational
  count: number | "auto";
};

export type SelectResult = { clips: Candidate[]; stats: { windows: number; startBoundaries: number; endBoundaries: number; mode: string; considered: number }; note?: string };

const clamp01 = (x: number) => Math.max(0, Math.min(1, x));

/** Normalização robusta por percentis (p10..p95) -> 0..1. */
function pnorm(arr: number[], n: number): number[] {
  const a = Array.from({ length: n }, (_, i) => arr[i] ?? 0);
  const s = [...a].sort((x, y) => x - y);
  const lo = s[Math.floor(n * 0.1)] ?? 0;
  const hi = s[Math.floor(n * 0.95)] ?? 1;
  const span = hi - lo;
  if (span < 1e-4) return a.map(() => 0);
  return a.map((v) => clamp01((v - lo) / span));
}

/**
 * Seleção GLOBAL de momentos: avalia janelas candidatas em qualquer posição da linha do tempo
 * (limites alinhados a frases completas/pausas), compara todas e aplica supressão de sobreposição e repetição.
 * Nunca divide o vídeo em blocos sequenciais. Toda janela planejada fica entre 60,5s e 89,5s.
 */
export function selectClips(inp: SelectInput): SelectResult {
  const { duration, segments, kind } = inp;
  const N = Math.ceil(duration);
  if (duration < PLAN_MIN + 1) return { clips: [], stats: { windows: 0, startBoundaries: 0, endBoundaries: 0, mode: "n/a", considered: 0 }, note: "O vídeo tem menos de 61 s: não é possível gerar cortes individuais de 60–90 s." };

  const hasText = segments.length > 0;
  const hasMotion = inp.motion.some((v) => v > 0);
  const e = pnorm(inp.energy, N);
  const m = hasMotion ? pnorm(inp.motion, N) : new Array(N).fill(0);

  // sinais por segmento
  const sigs: Signals[] = segments.map((s) => signalsOf(s.text));
  const segInt = sigs.map(textInterest);
  const t = new Array<number>(N).fill(0);
  const speech = new Array<number>(N).fill(0);
  segments.forEach((s, i) => {
    for (let sec = Math.floor(s.start); sec < Math.min(N, Math.ceil(s.end)); sec++) {
      t[sec] = Math.max(t[sec], segInt[i]);
      speech[sec] = 1;
    }
  });
  if (!hasText) for (let i = 0; i < N; i++) speech[i] = e[i] > 0.2 ? 1 : 0;

  let wt = 0, we = 0, wm = 0;
  if (hasText) {
    if (kind === "game") [wt, we, wm] = [0.25, 0.3, 0.45];
    else if (kind === "podcast" || kind === "educational") [wt, we, wm] = [0.58, 0.34, 0.08];
    else [wt, we, wm] = [0.42, 0.3, 0.28];
  } else [wt, we, wm] = [0, 0.5, 0.5];
  if (!hasMotion) {
    const k = wt + we;
    wt /= k; we /= k; wm = 0;
  }
  const I = new Array<number>(N);
  for (let i = 0; i < N; i++) I[i] = wt * t[i] + we * e[i] + wm * m[i];
  const S = I.map((_, i) => {
    let a = 0, c = 0;
    for (let k = Math.max(0, i - 2); k <= Math.min(N - 1, i + 2); k++) { a += I[k]; c++; }
    return a / c;
  });
  const pre = (arr: number[]) => { const p = [0]; for (const v of arr) p.push(p[p.length - 1] + v); return p; };
  const pI = pre(I), pSp = pre(speech);

  // fronteiras de corte
  type B = { time: number; idx: number };
  let starts: B[] = [];
  let ends: B[] = [];
  let mode = "";
  if (hasText) {
    mode = "frases completas (transcrição)";
    segments.forEach((s, i) => {
      const prev = segments[i - 1];
      const next = segments[i + 1];
      if (i === 0 || isTerminal(prev.text) || s.start - prev.end > 0.7) starts.push({ time: s.start, idx: i });
      if (!next || isTerminal(s.text) || next.start - s.end > 0.7) ends.push({ time: s.end, idx: i });
    });
    if (starts.length < 3 || ends.length < 3) {
      starts = segments.map((s, i) => ({ time: s.start, idx: i }));
      ends = segments.map((s, i) => ({ time: s.end, idx: i }));
    }
  } else {
    mode = "pausas de áudio + mudanças de cena (sem transcrição)";
    const pts: number[] = [0];
    for (let i = 1; i < N - 1; i++) if (e[i] < 0.22 && e[i] <= e[i - 1] && e[i] <= e[i + 1]) pts.push(i + 0.5);
    for (const c of inp.cuts) pts.push(c);
    pts.push(duration);
    const uniq = [...new Set(pts.map((p) => Math.round(p * 2) / 2))].sort((a, b) => a - b);
    starts = uniq.map((time) => ({ time, idx: -1 }));
    ends = starts;
  }

  const segKw = segments.map((s) => keywordSet(s.text));
  const firstSegAt = (time: number) => {
    let lo = 0, hi = segments.length - 1, r = segments.length;
    while (lo <= hi) { const mid = (lo + hi) >> 1; if (segments[mid].end > time) { r = mid; hi = mid - 1; } else lo = mid + 1; }
    return r;
  };

  type W = { s: number; e: number; raw: number; i0: number; i1: number; peakT: number; mean: number; peak: number; open: number; closure: number; density: number; coh: number };
  const wins: W[] = [];
  for (const sb of starts) {
    const prevEnd = sb.idx > 0 ? segments[sb.idx - 1].end : 0;
    const lead = Math.min(0.25, Math.max(0, (sb.time - prevEnd) / 2));
    const cs = Math.max(0, sb.time - lead);
    for (const eb of ends) {
      if (eb.time <= sb.time) continue;
      const nextStart = eb.idx >= 0 && segments[eb.idx + 1] ? segments[eb.idx + 1].start : duration;
      const tail = Math.min(0.4, Math.max(0, (nextStart - eb.time) / 2));
      const ce = Math.min(duration, eb.time + tail);
      const d = ce - cs;
      if (d < PLAN_MIN) continue;
      if (d > PLAN_MAX) break;
      const a = Math.floor(cs), b = Math.min(N, Math.ceil(ce));
      const mean = (pI[b] - pI[a]) / Math.max(1, b - a);
      let peak = 0, peakT = a;
      for (let k = a; k < b; k++) if (S[k] > peak) { peak = S[k]; peakT = k; }
      const pos = (peakT - cs) / d;
      const posB = pos >= 0.2 && pos <= 0.9 ? 1 : 0.65;
      const o0 = a, o1 = Math.min(N, a + 6);
      let open = (pI[o1] - pI[o0]) / Math.max(1, o1 - o0);
      let i0 = -1, i1 = -1;
      if (hasText) {
        i0 = firstSegAt(cs);
        i1 = Math.max(i0, firstSegAt(ce) - 1);
        const s0 = sigs[i0];
        if (s0 && (s0.quest || s0.reveal || s0.surprise)) open = Math.min(1, open + 0.2);
      }
      const closure = hasText ? (eb.idx >= 0 && isTerminal(segments[eb.idx].text) ? 1 : 0.6) : 0.7;
      const density = clamp01((pSp[b] - pSp[a]) / Math.max(1, b - a) / 0.6);
      let coh = 0.5;
      if (hasText && i1 - i0 >= 3) {
        const mid = (i0 + i1) >> 1;
        const A = new Set<string>(), Bs = new Set<string>();
        for (let k = i0; k <= mid; k++) segKw[k].forEach((x) => A.add(x));
        for (let k = mid + 1; k <= i1; k++) segKw[k].forEach((x) => Bs.add(x));
        coh = clamp01(0.35 + jaccard(A, Bs) * 4);
      }
      const raw = 0.3 * mean * 1.6 + 0.24 * peak * posB * 1.4 + 0.16 * open * 1.4 + 0.1 * closure + 0.1 * density + 0.1 * coh;
      wins.push({ s: cs, e: ce, raw: clamp01(raw), i0, i1, peakT, mean, peak, open, closure, density, coh });
    }
  }
  if (!wins.length) return { clips: [], stats: { windows: 0, startBoundaries: starts.length, endBoundaries: ends.length, mode, considered: 0 }, note: "Nenhuma janela de 60–90 s com limites naturais foi encontrada (a transcrição pode ter pausas/frases muito longas)." };

  wins.sort((a, b) => b.raw - a.raw);
  const target = inp.count === "auto" ? Math.max(1, Math.min(12, Math.round(duration / 300))) : inp.count;
  const best = wins[0].raw;
  const chosen: { w: W; kw: Set<string> }[] = [];
  for (const w of wins.slice(0, 4000)) {
    if (chosen.length >= target) break;
    if (inp.count === "auto" && (w.raw < best * 0.72 || w.raw < 0.22) && chosen.length >= 1) break;
    if (chosen.some((c) => w.s < c.w.e + 4 && w.e > c.w.s - 4)) continue;
    let kw = new Set<string>();
    if (hasText) for (let k = w.i0; k <= w.i1; k++) segKw[k].forEach((x) => kw.add(x));
    if (hasText && kw.size >= 4 && chosen.some((c) => jaccard(kw, c.kw) > 0.5)) continue;
    chosen.push({ w, kw });
  }

  const eMax = Math.max(1e-6, ...inp.motion);
  const clips: Candidate[] = chosen.map(({ w }) => {
    const text = hasText ? segments.slice(w.i0, w.i1 + 1).map((s) => s.text).join(" ") : "";
    let sig = zeroSignals();
    for (let k = Math.max(0, w.i0); k <= w.i1 && hasText; k++) sig = addSignals(sig, sigs[k]);
    const dur = w.e - w.s;
    const cutsIn = inp.cuts.filter((c) => c >= w.s && c <= w.e);
    let aPeak = w.s, aMax = -1;
    for (let k = Math.floor(w.s); k < Math.min(N, Math.ceil(w.e)); k++) if (e[k] > aMax) { aMax = e[k]; aPeak = k; }
    let mPeak = w.s, mMax = -1;
    if (hasMotion) for (let k = Math.floor(w.s); k < Math.min(N, Math.ceil(w.e)); k++) if (inp.motion[k] > mMax) { mMax = inp.motion[k]; mPeak = k; }
    const silent = 1 - w.density;
    const mAvgWin = hasMotion ? m.slice(Math.floor(w.s), Math.ceil(w.e)).reduce((a, b) => a + b, 0) / Math.max(1, Math.ceil(w.e) - Math.floor(w.s)) : 0;

    const c01 = clamp01;
    const dims: [string, number, string][] = [
      ["Impacto inicial", w.open, `intensidade média dos 6 s iniciais ${(w.open * 100).toFixed(0)}%${sig.quest ? "; abre com pergunta/gancho" : ""}`],
      ["Retenção", 0.5 * c01(w.mean * 1.6) + 0.5 * w.density, `${Math.round(w.density * 100)}% da janela com fala/áudio ativo; interesse médio ${(w.mean * 100).toFixed(0)}%`],
      ["Curiosidade", c01(0.2 * sig.quest + 0.3 * sig.reveal + 0.12 * sig.story + 0.3 * w.open), `${sig.quest} pergunta(s), ${sig.reveal} sinal(is) de revelação, ${sig.story} de narrativa`],
      ["Entretenimento", c01(0.3 * sig.laugh + 0.2 * sig.surprise + 0.2 * sig.game + 0.5 * w.peak), `${sig.laugh} sinal(is) de risada, ${sig.surprise} de surpresa; pico de energia ${(w.peak * 100).toFixed(0)}%`],
      ["Emoção", c01(0.12 * sig.excl + 0.25 * sig.surprise + 0.6 * aMax), `${sig.excl} exclamação(ões); pico de volume em ${fmtTime(aPeak)}`],
      ["Relevância", c01(0.4 + 0.1 * Math.min(4, topKeywords(text, 6).length) ), `assunto concentrado em: ${topKeywords(text, 3).join(", ") || "n/d"}`],
      ["Clareza", hasText ? c01(0.5 * w.density + 0.5 * w.closure) : 0.4, hasText ? `fala contínua; ${w.closure === 1 ? "termina em frase completa" : "final sem pontuação clara"}` : "sem transcrição para medir clareza"],
      ["Contexto", c01(0.5 * w.coh + 0.5 * w.closure), `coerência temática entre início e fim ${(w.coh * 100).toFixed(0)}%`],
      ["Potencial de comentários", c01(0.25 * sig.opinion + 0.2 * sig.quest + 0.15 * sig.reveal + 0.2), `${sig.opinion} opinião(ões) forte(s), ${sig.quest} pergunta(s)`],
      ["Potencial de compartilhamento", c01(0.5 * w.peak + 0.15 * sig.surprise + 0.1 * sig.story + 0.1 * sig.laugh), `pico de interesse ${(w.peak * 100).toFixed(0)}%; ${sig.surprise} surpresa(s)`],
      ["Qualidade visual (estimada)", hasMotion ? c01(0.35 + 0.65 * mAvgWin + 0.05 * Math.min(4, cutsIn.length)) : 0.5, hasMotion ? `atividade visual média ${(mAvgWin * 100).toFixed(0)}%, ${cutsIn.length} mudança(s) de cena (não mede nitidez)` : "análise visual indisponível"],
      ["Qualidade sonora (estimada)", c01(1 - silent * 0.8), `${Math.round(silent * 100)}% de silêncio na janela (não mede ruído)`],
    ];
    const breakdown: ScoreBreakdown = {};
    for (const [k, v, why] of dims) breakdown[k] = { score: Math.round(v * 100), why };
    const score = Math.max(1, Math.min(99, Math.round(100 * clamp01((w.raw - 0.08) / 0.72))));

    const tags: string[] = [];
    if (sig.laugh) tags.push("humor/risadas");
    if (sig.surprise) tags.push("surpresa");
    if (sig.opinion) tags.push("opinião forte");
    if (sig.reveal) tags.push("revelação/curiosidade");
    if (sig.story) tags.push("história");
    if (sig.quest) tags.push("pergunta e resposta");
    if (sig.advice) tags.push("conselho");
    if (sig.money) tags.push("dinheiro/números");
    if (sig.game || kind === "game") tags.push("gameplay");
    if (!tags.length) tags.push(hasText ? "conteúdo informativo" : "momento de alta atividade audiovisual");

    const evidence: string[] = [`pico de volume em ${fmtTime(aPeak)}`];
    if (hasMotion) evidence.push(`pico de movimento visual em ${fmtTime(mPeak)}`);
    if (sig.laugh) evidence.push(`${sig.laugh} sinal(is) de risada na fala`);
    if (sig.excl) evidence.push(`${sig.excl} exclamação(ões)`);
    if (sig.quest) evidence.push(`${sig.quest} pergunta(s)`);
    if (w.closure === 1) evidence.push("termina em frase completa");
    const sents = sentences(text);
    const first = sents[0] || "";
    const last = sents[sents.length - 1] || "";
    const kws = topKeywords(text, 3);
    const potential = score >= 75 ? "Alto" : score >= 55 ? "Médio" : "Moderado";
    return {
      start: Math.round(w.s * 100) / 100,
      end: Math.round(w.e * 100) / 100,
      score,
      raw: w.raw,
      breakdown,
      justification: `Selecionado entre ${wins.length} janelas avaliadas no vídeo inteiro. Sinais: ${evidence.join("; ")}. Nota = estimativa editorial, não garantia de desempenho.`,
      description: hasText ? `Trecho de ${Math.round(dur)} s sobre ${kws.join(", ") || "o tema do vídeo"}. Começa com: “${cap(first, 110)}”` : `Trecho de ${Math.round(dur)} s com alta atividade de áudio e imagem (sem transcrição).`,
      topic: kws.join(", ") || (kind === "game" ? "gameplay" : "atividade audiovisual"),
      context: hasText ? `De ${fmtTime(w.s)} a ${fmtTime(w.e)}. Abertura: “${cap(first, 100)}”. Desfecho: “${cap(last, 100)}”.` : `De ${fmtTime(w.s)} a ${fmtTime(w.e)}; limites escolhidos em pausas de áudio/mudanças de cena.`,
      visualEvent: hasMotion
        ? `${cutsIn.length} mudança(s) de cena; maior variação visual em ${fmtTime(mPeak)} (${Math.round((mMax / eMax) * 100)}% do pico global). Medido por diferença temporal de quadros — sem modelo de visão semântico.`
        : "Análise visual indisponível para este arquivo.",
      spokenText: cap(text, 1500),
      editorialPotential: `${potential} — ${tags.join(", ")}`,
      tags,
      peakT: Math.max(aPeak, mPeak) === aPeak ? aPeak : mPeak,
    };
  });
  return { clips, stats: { windows: wins.length, startBoundaries: starts.length, endBoundaries: ends.length, mode, considered: Math.min(wins.length, 4000) }, note: clips.length < (typeof inp.count === "number" ? inp.count : 1) ? "Menos cortes que o solicitado: o restante dos trechos se sobrepunha ou era repetitivo (priorizamos qualidade)." : undefined };
}
