// Utilitários linguísticos (PT-BR primeiro, com sinais básicos em inglês).

export const norm = (s: string) => s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");

const STOP_RAW =
  "a o as os um uma uns umas de do da dos das em no na nos nas por para com sem sob sobre e ou mas que se nao e eh foi ser sao era eu tu ele ela nos voce voces eles elas me te lhe meu minha seu sua isso isto esse essa esses essas aquele aquela aqui ali la ja ta tipo entao ne ai pra pro pela pelo como mais muito muita muitos bem tambem so ao aos as ate quando onde porque tem tinha tem vai vou ainda cara gente coisa coisas assim ficar fazer fazendo fiz faz pode podia posso quer quero queria acho achei ver vendo vez vezes agora depois antes sempre nunca todo toda todos todas outro outra outros mesmo mesma tudo nada algo alguem ninguem cada qual quais quanto entre ate desde durante dentro fora num numa dele dela deles delas nosso nossa estou esta estao estava estavam estamos ter tenho tive temos hoje aquilo disso nisso disto nele nela ah eh uh hum the and to of in is it that for on with as was this you are be at have from or an but not they we he she his her there what so if my do does did i me your can will just like yeah okay";
export const STOP = new Set(STOP_RAW.split(/\s+/));

const LEX = {
  laugh: /\b(ha){2,}\b|\bk{3,}\b|\brs{2,}\b|\brisos?\b|\brindo\b|\brisada|\bengracad|\bhilari|\bmorri de rir|\bpiada|\blol\b|\blmao\b|\blaugh/,
  surprise: /\bnossa\b|\bcaramba\b|\bmeu deus\b|\bnao acredito\b|\binacreditavel|\bimpossivel\b|\bdo nada\b|\bde repente\b|\bsurpres|\bchocante|\babsurdo|\bsocorro\b|\buau\b|\bwow\b|\bsem noc?ao\b|\binesperad|\bnao esperava|\bque isso\b|\bpelo amor\b|\bsurreal|\bcrazy\b|\bno way\b|\bomg\b|\bunbelievable/,
  opinion: /\bnunca\b|\bsempre\b|\bpior\b|\bmelhor\b|\bodeio\b|\bamo\b|\bmentira\b|\berrado\b|\ba verdade\b|\btodo mundo\b|\bninguem\b|\bpolemic|\bculpa\b|\bvergonha\b|\bridicul|\bnao concordo\b|\beu acho que\b|\bna minha opiniao\b|\bprecisa\b|\bobrigat/,
  reveal: /\bsegredo\b|\bdescobri\b|\brevel|\bconfess|\ba verdade e\b|\bna real\b|\bo que ninguem\b|\badmito\b|\bnunca contei\b|\bpouca gente\b|\bdetalhe\b|\bculiosidade\b|\bvoce sabia\b|\bsabia que\b|\bsecret\b|\btruth\b/,
  story: /\buma vez\b|\blembro\b|\baconteceu\b|\bhistoria\b|\bdaquela vez\b|\bquando eu\b|\bentao eu\b|\bai eu\b|\bdai eu\b|\bcontando\b|\bcaso\b|\bcerto dia\b|\bstory\b|\bonce\b|\bhappened\b/,
  money: /\bdinheiro\b|\breais\b|\bmilh(ao|oes)\b|\bbilh(ao|oes)\b|\bgrana\b|\bpreco\b|\bcaro\b|\bbarato\b|\blucro\b|\bsalario\b|\binvest|\bmoney\b|\bdollars?\b|\br\$\s?\d|\b\d{2,}\s?(mil|k)\b/,
  advice: /\bdica\b|\bvoce precisa\b|\btem que\b|\bcuidado\b|\baprenda\b|\bevite\b|\blembre\b|\bnunca faca\b|\bpasso\b|\bmetodo\b|\bestrategia\b|\bsegredo para\b|\btip\b|\blearn\b/,
  game: /\bmatei\b|\bmatou\b|\beliminad|\bclutch\b|\bace\b|\bkill\b|\bheadshot\b|\bganhei\b|\bvenci\b|\bperdi\b|\bderrota\b|\bvitoria\b|\bboss\b|\bmorri\b|\bmorreu\b|\bround\b|\bpartida\b|\bgg\b|\bvalorant\b|\bfortnite\b|\bminecraft\b|\bfree fire\b|\bcs\b|\bgta\b|\bwarzone\b|\blol\b|\bjogada\b|\bjogador\b|\bjogo\b|\bgame\b|\bplay\b|\bwin\b|\bdied\b|\bsquad\b|\bloot\b/,
};

export type Signals = { laugh: number; surprise: number; opinion: number; reveal: number; story: number; money: number; advice: number; game: number; excl: number; quest: number; words: number };

export function signalsOf(text: string): Signals {
  const n = norm(text);
  const c = (re: RegExp) => (n.match(new RegExp(re.source, "g")) || []).length;
  return {
    laugh: c(LEX.laugh),
    surprise: c(LEX.surprise),
    opinion: c(LEX.opinion),
    reveal: c(LEX.reveal),
    story: c(LEX.story),
    money: c(LEX.money),
    advice: c(LEX.advice),
    game: c(LEX.game),
    excl: (text.match(/!/g) || []).length,
    quest: (text.match(/\?/g) || []).length,
    words: (n.match(/[a-z0-9]+/g) || []).length,
  };
}

/** Interesse textual 0..1 de um trecho (densidade de sinais editoriais). */
export function textInterest(s: Signals): number {
  const raw = s.laugh * 2 + s.surprise * 1.6 + s.opinion * 0.9 + s.reveal * 1.5 + s.story * 0.5 + s.money * 0.5 + s.advice * 0.6 + s.game * 0.9 + s.excl * 0.7 + s.quest * 0.6;
  const dens = raw / (s.words / 12 + 2.5);
  return 1 - Math.exp(-dens * 0.9);
}

export function addSignals(a: Signals, b: Signals): Signals {
  return {
    laugh: a.laugh + b.laugh, surprise: a.surprise + b.surprise, opinion: a.opinion + b.opinion, reveal: a.reveal + b.reveal, story: a.story + b.story,
    money: a.money + b.money, advice: a.advice + b.advice, game: a.game + b.game, excl: a.excl + b.excl, quest: a.quest + b.quest, words: a.words + b.words,
  };
}
export const zeroSignals = (): Signals => ({ laugh: 0, surprise: 0, opinion: 0, reveal: 0, story: 0, money: 0, advice: 0, game: 0, excl: 0, quest: 0, words: 0 });

/** Palavras-chave (forma original -> frequência), ignorando stopwords. */
export function keywordCounts(text: string): Map<string, { display: string; n: number }> {
  const out = new Map<string, { display: string; n: number }>();
  const toks = text.toLowerCase().match(/[\p{L}\p{N}']+/gu) || [];
  for (const t of toks) {
    const k = norm(t);
    if (k.length < 4 || STOP.has(k) || /^\d+$/.test(k)) continue;
    const cur = out.get(k);
    if (cur) cur.n++;
    else out.set(k, { display: t, n: 1 });
  }
  return out;
}

export function topKeywords(text: string, n = 5): string[] {
  return [...keywordCounts(text).values()]
    .sort((a, b) => b.n - a.n || b.display.length - a.display.length)
    .slice(0, n)
    .map((x) => x.display);
}

export function keywordSet(text: string): Set<string> {
  return new Set([...keywordCounts(text).keys()]);
}

export function jaccard(a: Set<string>, b: Set<string>): number {
  if (!a.size || !b.size) return 0;
  let inter = 0;
  for (const x of a) if (b.has(x)) inter++;
  return inter / (a.size + b.size - inter);
}

export const isTerminal = (t: string) => /[.!?…]["')\]]?\s*$/.test(t.trim());

export function sentences(text: string): string[] {
  return (text.replace(/\s+/g, " ").match(/[^.!?…]+[.!?…]*/g) || []).map((s) => s.trim()).filter((s) => s.length > 2);
}

export function cap(s: string, n: number): string {
  return s.length > n ? s.slice(0, n - 1).trimEnd() + "…" : s;
}
