import { cfg } from "../config";

/** LLM local opcional via Ollama. Sem OLLAMA_URL, todas as funções caem para heurísticas determinísticas. */
export const llmAvailable = () => !!cfg.ollamaUrl;

export async function ollamaGenerate(prompt: string, opts: { json?: boolean; system?: string; timeoutMs?: number; images?: string[]; model?: string } = {}): Promise<string | null> {
  if (!cfg.ollamaUrl) return null;
  try {
    const res = await fetch(`${cfg.ollamaUrl}/api/generate`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        model: opts.model || cfg.ollamaModel,
        prompt,
        system: opts.system,
        stream: false,
        format: opts.json ? "json" : undefined,
        images: opts.images,
        options: { temperature: 0.4 },
      }),
      signal: AbortSignal.timeout(opts.timeoutMs ?? 120000),
    });
    if (!res.ok) return null;
    const j = (await res.json()) as { response?: string };
    return j.response?.trim() || null;
  } catch {
    return null;
  }
}

export async function ollamaJson<T>(prompt: string, system?: string): Promise<T | null> {
  const raw = await ollamaGenerate(prompt, { json: true, system });
  if (!raw) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

export async function ollamaStatus(): Promise<{ reachable: boolean; models: string[] }> {
  if (!cfg.ollamaUrl) return { reachable: false, models: [] };
  try {
    const res = await fetch(`${cfg.ollamaUrl}/api/tags`, { signal: AbortSignal.timeout(3000) });
    const j = (await res.json()) as { models?: { name: string }[] };
    return { reachable: true, models: (j.models || []).map((m) => m.name) };
  } catch {
    return { reachable: false, models: [] };
  }
}
