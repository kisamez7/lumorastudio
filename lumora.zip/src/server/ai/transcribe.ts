import { spawn } from "node:child_process";
import path from "node:path";
import { cfg } from "../config";
import { FFMPEG } from "../ffmpeg";
import type { Segment } from "@/lib/types";

/** Transcrição local com Whisper (transformers.js/ONNX, CPU) em processo filho isolado. */
export function transcribeFile(file: string, lang: string, duration: number, signal?: AbortSignal, onProgress?: (p: number, msg: string) => void): Promise<Segment[]> {
  return new Promise((resolve, reject) => {
    const script = path.join(process.cwd(), "scripts", "transcribe.mjs");
    const child = spawn(process.execPath, [script, file, lang || cfg.whisperLang, cfg.whisperModel], {
      env: { ...process.env, FFMPEG_PATH: FFMPEG },
      stdio: ["ignore", "pipe", "pipe"],
    });
    let buf = "";
    let result: Segment[] | null = null;
    let errMsg = "";
    const onAbort = () => child.kill("SIGKILL");
    signal?.addEventListener("abort", onAbort, { once: true });
    child.stdout.on("data", (d: Buffer) => {
      buf += d.toString();
      let idx: number;
      while ((idx = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, idx).trim();
        buf = buf.slice(idx + 1);
        if (!line.startsWith("{")) continue;
        try {
          const j = JSON.parse(line);
          if (j.type === "progress") onProgress?.(j.p, j.msg);
          else if (j.type === "result") result = j.segments;
          else if (j.type === "error") errMsg = j.message;
        } catch {}
      }
    });
    let stderr = "";
    child.stderr.on("data", (d: Buffer) => (stderr += d.toString().slice(-500)));
    child.on("error", (e) => reject(e));
    child.on("close", (code) => {
      signal?.removeEventListener("abort", onAbort);
      if (signal?.aborted) return reject(new Error("Cancelado"));
      if (code === 0 && result) return resolve(sanitizeSegments(result, duration));
      reject(new Error(`Falha na transcrição local${errMsg ? ": " + errMsg : ""}. Verifique conexão para o primeiro download do modelo (${cfg.whisperModel}) e memória disponível. ${stderr.slice(-160)}`));
    });
  });
}

export function sanitizeSegments(segs: Segment[], duration: number): Segment[] {
  const out: Segment[] = [];
  for (const s of segs) {
    const text = (s.text || "").trim();
    if (!text) continue;
    const start = Math.max(0, Math.min(s.start, duration || s.start));
    let end = Math.max(start + 0.2, duration ? Math.min(s.end, duration) : s.end);
    const words = s.words?.map((w) => ({ ...w, start: Math.min(w.start, end), end: Math.min(Math.max(w.end, w.start), end) }));
    // Whisper às vezes estica a última palavra; limita palavras muito longas
    if (words?.length) {
      const last = words[words.length - 1];
      if (last.end - last.start > 1.5) last.end = last.start + 0.6;
      end = Math.max(end > last.end + 2 ? last.end + 0.3 : end, last.end);
    }
    out.push({ start, end, text, speaker: s.speaker, words });
  }
  return out.sort((a, b) => a.start - b.start);
}

const ts = (t: string) => {
  const m = t.trim().replace(",", ".").match(/(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)/);
  return m ? Number(m[1] || 0) * 3600 + Number(m[2]) * 60 + Number(m[3]) : NaN;
};

/** Importa SRT ou WebVTT. Texto sem marcações de tempo é rejeitado (não inventamos sincronização). */
export function parseSubtitles(raw: string): Segment[] {
  const text = raw.replace(/\r/g, "").replace(/^\uFEFF/, "");
  const blocks = text.split(/\n{2,}/);
  const segs: Segment[] = [];
  for (const b of blocks) {
    const lines = b.split("\n").filter((l) => l.trim());
    const ti = lines.findIndex((l) => l.includes("-->"));
    if (ti < 0) continue;
    const [a, c] = lines[ti].split("-->");
    const start = ts(a);
    const end = ts(c.trim().split(/\s+/)[0]);
    if (!Number.isFinite(start) || !Number.isFinite(end) || end <= start) continue;
    const body = lines.slice(ti + 1).join(" ").replace(/<[^>]+>/g, "").replace(/\s+/g, " ").trim();
    if (body) segs.push({ start, end, text: body });
  }
  return segs;
}

const pad = (n: number, l = 2) => String(Math.floor(n)).padStart(l, "0");
export function srtTime(t: number): string {
  const ms = Math.round((t - Math.floor(t)) * 1000);
  const s = Math.floor(t);
  return `${pad(s / 3600)}:${pad((s % 3600) / 60)}:${pad(s % 60)},${pad(ms, 3)}`;
}

export function toSrt(segs: { start: number; end: number; text: string }[]): string {
  return segs.map((s, i) => `${i + 1}\n${srtTime(s.start)} --> ${srtTime(s.end)}\n${s.text}\n`).join("\n");
}

export function toTxt(segs: Segment[], withTime = true): string {
  const f = (t: number) => `[${pad(t / 60)}:${pad(t % 60)}]`;
  return segs.map((s) => (withTime ? `${f(s.start)} ` : "") + (s.speaker ? `${s.speaker}: ` : "") + s.text).join("\n");
}
