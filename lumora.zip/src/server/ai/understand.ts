import type { Segment } from "@/lib/types";
import { fmtTime } from "@/lib/types";
import type { MindNode, SummaryData } from "@/db/schema";
import { cap, keywordCounts, norm, signalsOf, textInterest, topKeywords } from "./text";
import { llmAvailable, ollamaGenerate, ollamaJson } from "./llm";

type Scored = { seg: Segment; score: number; i: number };

function scoreSegments(segs: Segment[]): Scored[] {
  const kc = keywordCounts(segs.map((s) => s.text).join(" "));
  return segs.map((seg, i) => {
    const toks = norm(seg.text).match(/[a-z0-9]+/g) || [];
    let cov = 0;
    for (const t of toks) cov += kc.get(t)?.n ?? 0;
    const tf = cov / Math.max(8, toks.length);
    const len = Math.min(1, toks.length / 18);
    return { seg, i, score: tf * 0.5 + textInterest(signalsOf(seg.text)) * 2 + len * 0.5 };
  });
}

const transcriptForLlm = (segs: Segment[], max = 12000) => {
  let out = "";
  for (const s of segs) {
    const line = `[${fmtTime(s.start)}] ${s.text}\n`;
    if (out.length + line.length > max) break;
    out += line;
  }
  return out;
};

export async function summarize(segs: Segment[], duration: number): Promise<SummaryData> {
  const sc = scoreSegments(segs);
  const byScore = [...sc].sort((a, b) => b.score - a.score);
  const chrono = (arr: Scored[]) => [...arr].sort((a, b) => a.i - b.i);
  const topics = [...keywordCounts(segs.map((s) => s.text).join(" ")).values()].sort((a, b) => b.n - a.n).slice(0, 10).map((k) => ({ name: k.display, count: k.n }));
  const shortSeg = chrono(byScore.slice(0, 4));
  const detSeg = chrono(byScore.slice(0, 12));
  const buckets = Math.min(8, Math.max(2, Math.round(duration / 240)));
  const chronological: { t: number; text: string }[] = [];
  for (let b = 0; b < buckets; b++) {
    const a = (duration / buckets) * b, z = (duration / buckets) * (b + 1);
    const inB = sc.filter((x) => x.seg.start >= a && x.seg.start < z);
    if (!inB.length) continue;
    const best = inB.sort((x, y) => y.score - x.score)[0];
    const kw = topKeywords(inB.map((x) => x.seg.text).join(" "), 3).join(", ");
    chronological.push({ t: Math.round(best.seg.start), text: `${kw ? `Assuntos: ${kw}. ` : ""}${cap(best.seg.text, 160)}` });
  }
  const events = byScore
    .filter((x) => { const s = signalsOf(x.seg.text); return s.laugh + s.surprise + s.reveal + s.game + s.excl > 0; })
    .slice(0, 8)
    .sort((a, b) => a.i - b.i)
    .map((x) => ({ t: Math.round(x.seg.start), text: cap(x.seg.text, 140) }));
  const tail = sc.filter((x) => x.seg.start > duration * 0.85).sort((a, b) => b.score - a.score).slice(0, 3).sort((a, b) => a.i - b.i);
  const base: SummaryData = {
    short: shortSeg.map((x) => cap(x.seg.text, 160)).join(" "),
    detailed: detSeg.map((x) => `[${fmtTime(x.seg.start)}] ${x.seg.text}`).join("\n"),
    topics,
    bullets: chrono(byScore.slice(0, 8)).map((x) => ({ t: Math.round(x.seg.start), text: cap(x.seg.text, 150) })),
    chronological,
    events,
    conclusions: tail.map((x) => cap(x.seg.text, 160)),
    engine: "extrativo (heurístico, sem LLM)",
  };
  if (llmAvailable()) {
    const tr = transcriptForLlm(segs);
    const r = await ollamaJson<{ short?: string; detailed?: string; conclusions?: string[] }>(
      `Transcrição com marcações de tempo:\n${tr}\n\nProduza em JSON: {"short":"resumo de 2-3 frases","detailed":"resumo detalhado em parágrafos","conclusions":["conclusões principais"]}. Use somente informações presentes na transcrição.`,
      "Você resume vídeos em português do Brasil, sem inventar fatos.",
    );
    if (r?.short) {
      base.short = r.short;
      if (r.detailed) base.detailed = typeof r.detailed === "string" ? r.detailed : JSON.stringify(r.detailed);
      if (Array.isArray(r.conclusions)) base.conclusions = r.conclusions.map(String);
      base.engine = "LLM local (Ollama)";
    }
  }
  return base;
}

export function buildMindmap(title: string, segs: Segment[]): MindNode {
  const full = segs.map((s) => s.text).join(" ");
  const kws = [...keywordCounts(full).entries()].sort((a, b) => b[1].n - a[1].n).slice(0, 7);
  const sc = scoreSegments(segs);
  const used = new Set<number>();
  const children: MindNode[] = kws.map(([k, v], ci) => {
    const hits = sc.filter((x) => norm(x.seg.text).includes(k) && !used.has(x.i)).sort((a, b) => b.score - a.score).slice(0, 3).sort((a, b) => a.i - b.i);
    hits.forEach((h) => used.add(h.i));
    return {
      id: `t${ci}`,
      label: `${v.display} (${v.n}×)`,
      children: hits.map((h, hi) => ({ id: `t${ci}s${hi}`, label: cap(h.seg.text, 72), t: Math.round(h.seg.start), children: [] })),
    };
  });
  return { id: "root", label: cap(title, 40), children };
}

export function buildNotes(title: string, segs: Segment[], duration: number): string {
  const buckets = Math.min(10, Math.max(2, Math.round(duration / 180)));
  const sc = scoreSegments(segs);
  const out: string[] = [`# Anotações — ${title}`, ""];
  for (let b = 0; b < buckets; b++) {
    const a = (duration / buckets) * b, z = (duration / buckets) * (b + 1);
    const inB = sc.filter((x) => x.seg.start >= a && x.seg.start < z);
    if (!inB.length) continue;
    const kw = topKeywords(inB.map((x) => x.seg.text).join(" "), 3).join(", ");
    out.push(`## [${fmtTime(a)}] ${kw || "Trecho"}`);
    for (const x of [...inB].sort((p, q) => q.score - p.score).slice(0, 3).sort((p, q) => p.i - q.i)) out.push(`- ${cap(x.seg.text, 200)} _(${fmtTime(x.seg.start)})_`);
    out.push("");
  }
  return out.join("\n");
}

export type MomentHit = { t: number; end: number; text: string; score: number; reason: string; kind: string };

export function findMoments(query: string, segs: Segment[], energy: number[], motion: number[]): MomentHit[] {
  const q = norm(query);
  const hits: MomentHit[] = [];
  const intents: { re: RegExp; kind: string; test: (s: ReturnType<typeof signalsOf>) => number; label: string }[] = [
    { re: /risad|engrac|rir|humor|piada/, kind: "humor", test: (s) => s.laugh * 2 + s.excl * 0.2, label: "sinais de risada/humor na fala" },
    { re: /jogada|kill|elimin|clutch|vitoria|gameplay|melhor/, kind: "gameplay", test: (s) => s.game + s.excl * 0.4 + s.surprise, label: "termos de jogo/ação e exclamações" },
    { re: /dinheiro|grana|milh|preco|reais|invest/, kind: "dinheiro", test: (s) => s.money * 2, label: "menção a dinheiro/valores" },
    { re: /surpres|inesperad|chocante|absurd/, kind: "surpresa", test: (s) => s.surprise * 2 + s.excl * 0.3, label: "expressões de surpresa" },
    { re: /pergunta|duvida/, kind: "pergunta", test: (s) => s.quest * 2, label: "perguntas" },
    { re: /opiniao|polemic|discuss/, kind: "opinião", test: (s) => s.opinion * 2, label: "opiniões fortes" },
  ];
  const intent = intents.find((i) => i.re.test(q));
  const toks = [...new Set((q.match(/[a-z0-9]+/g) || []).filter((t) => t.length >= 3 && !["encontre", "todas", "todos", "quando", "alguem", "mencion", "momentos", "momento", "trecho", "onde", "falou", "fala"].some((s) => t.startsWith(s)) && !["que", "uma", "dos", "das", "com", "por", "para", "mais", "mas", "ele", "ela"].includes(t)))];
  for (const s of segs) {
    const n = norm(s.text);
    let score = 0;
    const reasons: string[] = [];
    if (toks.length) {
      const m = toks.filter((t) => n.includes(t));
      if (m.length) { score += m.length * 2 + m.length / toks.length; reasons.push(`contém “${m.join(", ")}”`); }
    }
    if (intent) {
      const v = intent.test(signalsOf(s.text));
      if (v > 0) { score += v; reasons.push(intent.label); }
    }
    if (score > 0) hits.push({ t: s.start, end: s.end, text: s.text, score, reason: reasons.join("; "), kind: intent?.kind || "busca" });
  }
  // sem transcrição, ou intenção sonora/visual: picos de energia/movimento (rotulados como tal)
  if (intent && (intent.kind === "humor" || intent.kind === "gameplay" || intent.kind === "surpresa" || !segs.length)) {
    const idx = energy.map((v, i) => ({ i, v: v + (motion[i] ?? 0) * (intent.kind === "gameplay" ? 1 : 0.3) })).sort((a, b) => b.v - a.v).slice(0, 8);
    for (const p of idx) if (p.v > 0) hits.push({ t: p.i, end: p.i + 4, text: "(sem fala associada) pico de volume" + (intent.kind === "gameplay" ? " e movimento visual" : ""), score: p.v * 1.2, reason: "análise de áudio/imagem — possível reação, não confirmado por transcrição", kind: "sinal audiovisual" });
  }
  hits.sort((a, b) => b.score - a.score);
  const out: MomentHit[] = [];
  for (const h of hits) {
    if (out.some((o) => Math.abs(o.t - h.t) < 8)) continue;
    out.push(h);
    if (out.length >= 12) break;
  }
  return out.sort((a, b) => a.t - b.t);
}

export async function answerQuestion(question: string, segs: Segment[], extra: { topics: string[]; clips: { start: number; score: number; topic: string }[]; duration: number }): Promise<{ answer: string; refs: { t: number; text: string }[]; engine: string }> {
  const q = norm(question);
  const sc = scoreSegments(segs);
  let pool = sc;
  if (/final|termina|conclus|encerr/.test(q)) pool = sc.filter((x) => x.seg.start > extra.duration * 0.85);
  else if (/inicio|comeca|abertura/.test(q)) pool = sc.filter((x) => x.seg.start < extra.duration * 0.15);
  const toks = (q.match(/[a-z0-9]+/g) || []).filter((t) => t.length >= 4);
  const ranked = pool
    .map((x) => ({ ...x, r: toks.reduce((a, t) => a + (norm(x.seg.text).includes(t) ? 1 : 0), 0) * 2 + x.score * 0.6 }))
    .sort((a, b) => b.r - a.r)
    .slice(0, 5)
    .sort((a, b) => a.i - b.i);
  const refs = ranked.map((x) => ({ t: Math.round(x.seg.start), text: cap(x.seg.text, 160) }));
  if (llmAvailable()) {
    const ctx = [...ranked.map((x) => `[${fmtTime(x.seg.start)}] ${x.seg.text}`), "", `Principais assuntos: ${extra.topics.join(", ")}`].join("\n");
    const a = await ollamaGenerate(`Contexto do vídeo:\n${ctx}\n\nPergunta: ${question}\nResponda em português, de forma direta, citando marcações de tempo [mm:ss] quando possível. Se a resposta não estiver no contexto, diga que não encontrou.`, { system: "Você responde perguntas sobre um vídeo usando apenas a transcrição fornecida." });
    if (a) return { answer: a, refs, engine: "LLM local (Ollama) + busca na transcrição" };
  }
  if (/assuntos|temas|topicos|tópicos/.test(q) || /assunto/.test(q)) return { answer: `Principais assuntos (por frequência na transcrição): ${extra.topics.slice(0, 5).join(", ")}.`, refs, engine: "extrativo (sem LLM)" };
  if (/melhor (jogada|momento)|mais engracad|melhor trecho/.test(q) && extra.clips.length) {
    const b = [...extra.clips].sort((a, c) => c.score - a.score)[0];
    return { answer: `O trecho com maior nota editorial começa em ${fmtTime(b.start)} (nota ${b.score}, assunto: ${b.topic}).`, refs, engine: "extrativo (sem LLM)" };
  }
  if (!refs.length) return { answer: "Não encontrei trechos relacionados na transcrição.", refs, engine: "extrativo (sem LLM)" };
  return { answer: "Trechos mais relevantes da transcrição para a sua pergunta (resposta extrativa — configure o Ollama para respostas redigidas):\n" + refs.map((r) => `• [${fmtTime(r.t)}] ${r.text}`).join("\n"), refs, engine: "extrativo (sem LLM)" };
}

export async function translateSegments(segs: Segment[], lang: string): Promise<{ start: number; end: number; text: string }[] | null> {
  if (!llmAvailable()) return null;
  const out: { start: number; end: number; text: string }[] = [];
  for (let i = 0; i < segs.length; i += 25) {
    const batch = segs.slice(i, i + 25);
    const r = await ollamaJson<{ t?: string[] }>(`Traduza cada linha para ${lang}, preservando o sentido e a ordem. Responda JSON {"t":[...]} com exatamente ${batch.length} itens.\n${JSON.stringify(batch.map((b) => b.text))}`, "Você é um tradutor profissional de legendas.");
    if (!r?.t || r.t.length !== batch.length) return null;
    batch.forEach((b, k) => out.push({ start: b.start, end: b.end, text: String(r.t![k]) }));
  }
  return out;
}

export function genPublish(opts: { text: string; topic: string; tags: string[]; durationSec: number; hook?: string; kind: string }) {
  const kws = topKeywords(opts.text, 5);
  const K = (s: string) => s.charAt(0).toUpperCase() + s.slice(1);
  const sents = (opts.text.match(/[^.!?…]+[.!?…]*/g) || []).map((s) => s.trim()).filter((s) => s.length > 15);
  const first = sents[0] || "";
  const q = sents.find((s) => s.includes("?"));
  const titles = [
    kws[0] ? `${K(kws[0])}: ${cap(first, 55)}` : cap(first, 70),
    q ? cap(q, 80) : kws[0] ? `Você já pensou sobre ${kws[0]}?` : "Assista até o final",
    kws[1] ? `${K(kws[0] || "Tema")} e ${kws[1]} em ${Math.round(opts.durationSec)} segundos` : `Corte de ${Math.round(opts.durationSec)} segundos`,
    opts.hook ? K(opts.hook.toLowerCase()) : kws[0] ? `O que foi dito sobre ${kws[0]}` : "Momento destacado",
    kws.length ? `Trecho sobre ${kws.slice(0, 3).join(", ")}` : "Trecho em destaque",
  ].filter((t, i, a) => t && a.indexOf(t) === i);
  const hashBase = [...kws.slice(0, 4).map((k) => norm(k).replace(/[^a-z0-9]/g, "")), ...opts.tags.flatMap((t) => (t === "humor/risadas" ? ["humor"] : t === "opinião forte" ? ["opiniao"] : t === "gameplay" ? ["gameplay", "gamer"] : t === "história" ? ["historia"] : t === "conselho" ? ["dicas"] : t === "revelação/curiosidade" ? ["curiosidades"] : []))];
  if (opts.kind === "podcast") hashBase.push("podcast", "cortes");
  if (opts.kind === "educational") hashBase.push("aprendizado");
  const base = [...new Set(hashBase)].filter((h) => h.length >= 3);
  const plat: Record<string, string[]> = { tiktok: ["fyp"], reels: ["reels"], shorts: ["shorts"], facebook: ["reels"] };
  const body = cap(first || `Trecho sobre ${kws.join(", ")}`, 140);
  const cta = "Gostou? Comente o que achou e compartilhe.";
  const mk = (p: string, max: number) => {
    const tags = [...base, ...plat[p]].slice(0, p === "shorts" ? 6 : 8).map((h) => "#" + h);
    const desc = p === "facebook" ? `${body}\n\n${cta}` : cap(`${body} ${cta}`, max);
    return { platform: p, description: desc, hashtags: tags };
  };
  return { titles, platforms: [mk("tiktok", 150), mk("reels", 125), mk("shorts", 100), mk("facebook", 400)] };
}
