import { streamFfmpeg } from "../ffmpeg";
import type { AnalysisAudio, AnalysisVisual } from "@/db/schema";

/**
 * Análise de áudio de 100% da duração: energia RMS (dBFS normalizado 0..1) por segundo.
 * Decodifica em streaming (8 kHz mono) -> memória constante, mesmo para vídeos longos.
 */
export async function analyzeAudio(file: string, duration: number, hasAudio: boolean, signal?: AbortSignal, onProgress?: (p: number) => void): Promise<AnalysisAudio> {
  const n = Math.ceil(duration);
  if (!hasAudio) return { energy: new Array(n).fill(0), silenceRatio: 1, peaks: [] };
  const SR = 8000;
  const sums = new Float64Array(n + 1);
  let carry: Buffer | null = null;
  let sampleIdx = 0;
  await streamFfmpeg(
    ["-i", file, "-vn", "-ac", "1", "-ar", String(SR), "-f", "s16le", "pipe:1"],
    (chunk) => {
      let buf = carry ? Buffer.concat([carry, chunk]) : chunk;
      const usable = buf.length - (buf.length % 2);
      carry = usable < buf.length ? buf.subarray(usable) : null;
      buf = buf.subarray(0, usable);
      for (let i = 0; i < usable; i += 2) {
        const v = buf.readInt16LE(i) / 32768;
        const sec = Math.floor(sampleIdx / SR);
        if (sec <= n) sums[sec] += v * v;
        sampleIdx++;
      }
      if (onProgress && duration) onProgress(Math.min(1, sampleIdx / SR / duration));
    },
    signal,
  );
  const energy: number[] = [];
  let silent = 0;
  for (let i = 0; i < n; i++) {
    const rms = Math.sqrt(sums[i] / SR);
    const db = 20 * Math.log10(Math.max(rms, 1e-6));
    if (db < -48) silent++;
    energy.push(Math.round(Math.max(0, Math.min(1, (db + 60) / 60)) * 1000) / 1000);
  }
  const sorted = [...energy].sort((a, b) => a - b);
  const thr = sorted[Math.floor(sorted.length * 0.92)] ?? 1;
  const peaks: number[] = [];
  for (let i = 1; i < n - 1; i++) if (energy[i] >= thr && energy[i] >= energy[i - 1] && energy[i] >= energy[i + 1]) peaks.push(i);
  return { energy, silenceRatio: n ? silent / n : 0, peaks };
}

/**
 * Análise visual temporal de 100% do vídeo: pontuação de mudança entre quadros (FFmpeg scene score)
 * amostrada a `fps` quadros/s sobre TODA a duração, em resolução reduzida (320px).
 * Gera: curva de movimento por segundo e lista de cortes de cena (score > 0.3).
 */
export async function analyzeVisual(file: string, duration: number, signal?: AbortSignal, onProgress?: (p: number) => void, range?: { start: number; end: number; fps: number }): Promise<AnalysisVisual> {
  const fps = range?.fps ?? 2;
  const offset = range?.start ?? 0;
  const span = range ? range.end - range.start : duration;
  const n = Math.ceil(span);
  const motion = new Array<number>(n).fill(0);
  const cuts: number[] = [];
  let pending = "";
  let curT = 0;
  const args = [
    ...(range ? ["-ss", String(range.start), "-t", String(span)] : []),
    "-i",
    file,
    "-an",
    "-vf",
    `fps=${fps},scale=320:-2,select='gte(scene,0)',metadata=print:file=-`,
    "-f",
    "null",
    "-",
  ];
  await streamFfmpeg(
    args,
    (chunk) => {
      pending += chunk.toString();
      let idx: number;
      while ((idx = pending.indexOf("\n")) >= 0) {
        const line = pending.slice(0, idx);
        pending = pending.slice(idx + 1);
        const t = line.match(/pts_time:([\d.]+)/);
        if (t) {
          curT = Number(t[1]);
          continue;
        }
        const s = line.match(/lavfi\.scene_score=([\d.]+)/);
        if (s) {
          const score = Number(s[1]);
          const sec = Math.min(n - 1, Math.floor(curT));
          if (sec >= 0) motion[sec] = Math.max(motion[sec], Math.round(score * 1000) / 1000);
          if (score > 0.3 && (!cuts.length || curT + offset - cuts[cuts.length - 1] > 1)) cuts.push(Math.round((curT + offset) * 100) / 100);
          if (onProgress && span) onProgress(Math.min(1, curT / span));
        }
      }
    },
    signal,
  );
  return { motion, cuts, sampleFps: fps };
}
