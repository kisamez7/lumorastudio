import type { Caption, CaptionStyle, CaptionWord, EditorElement, HookConfig, Segment } from "@/lib/types";
import { STOP, norm } from "./text";

/** Constrói legendas sincronizadas (tempo relativo ao início do corte) a partir das palavras reconhecidas. */
export function buildCaptions(segments: Segment[], start: number, end: number, style: Pick<CaptionStyle, "wordsPerLine">): Caption[] {
  const words: CaptionWord[] = [];
  for (const s of segments) {
    if (s.end < start || s.start > end) continue;
    let ws = s.words;
    if (!ws?.length) {
      const toks = s.text.split(/\s+/).filter(Boolean);
      const total = toks.reduce((a, t) => a + t.length + 1, 0);
      let cur = s.start;
      ws = toks.map((t) => {
        const d = ((t.length + 1) / total) * (s.end - s.start);
        const w = { text: t, start: cur, end: cur + d };
        cur += d;
        return w;
      });
    }
    for (const w of ws) if (w.start >= start - 0.05 && w.start < end) words.push({ text: w.text, start: Math.max(0, w.start - start), end: Math.min(end - start, Math.max(w.end, w.start + 0.12) - start) });
  }
  const dur = end - start;
  const lines: Caption[] = [];
  let cur: CaptionWord[] = [];
  const flush = () => {
    if (cur.length) lines.push({ start: cur[0].start, end: cur[cur.length - 1].end, words: cur });
    cur = [];
  };
  for (const w of words) {
    const prev = cur[cur.length - 1];
    if (prev && w.start - prev.end > 0.7) flush();
    cur.push(w);
    if (cur.length >= style.wordsPerLine || /[.!?…]$/.test(w.text) || (/[,;:]$/.test(w.text) && cur.length >= Math.max(2, style.wordsPerLine - 1))) flush();
  }
  flush();
  // continuidade: estende fim até o início da próxima linha se a pausa for curta
  for (let i = 0; i < lines.length; i++) {
    const nx = lines[i + 1];
    const lim = nx ? nx.start : dur;
    if (lines[i].end < lim && lim - lines[i].end < 0.4) lines[i].end = lim;
    lines[i].end = Math.min(dur, Math.max(lines[i].end, lines[i].start + 0.25));
    // destaque inteligente: no máximo 1 palavra relevante por linha (texto original preservado)
    let bi = -1, bl = 4;
    lines[i].words.forEach((w, k) => {
      const n = norm(w.text).replace(/[^a-z0-9]/g, "");
      if (n.length > bl && !STOP.has(n)) { bl = n.length; bi = k; }
    });
    lines[i].words.forEach((w, k) => (w.hl = k === bi));
  }
  return lines;
}

const hex = (c: string, a = 0) => {
  const m = c.replace("#", "").padEnd(6, "0");
  return `&H${a.toString(16).padStart(2, "0").toUpperCase()}${m.slice(4, 6)}${m.slice(2, 4)}${m.slice(0, 2)}`.toUpperCase();
};
const fam = (f: string) => (f === "Anton" ? "Anton" : "Poppins ExtraBold");
const tm = (t: number) => {
  const cs = Math.round(Math.max(0, t) * 100);
  return `${Math.floor(cs / 360000)}:${String(Math.floor((cs % 360000) / 6000)).padStart(2, "0")}:${String(Math.floor((cs % 6000) / 100)).padStart(2, "0")}.${String(cs % 100).padStart(2, "0")}`;
};
const esc = (s: string) => s.replace(/[{}\\]/g, "").replace(/\n/g, " ");

export function buildAss(opts: { captions: Caption[]; style: CaptionStyle; hook: HookConfig; elements: EditorElement[]; duration: number }): string {
  const { captions, style, hook, elements, duration } = opts;
  const W = 1080, H = 1920;
  const capStyle = style.bg
    ? `Style: Cap,${fam(style.font)},${style.size},${hex(style.color)},${hex(style.color)},&H99000000,&H00000000,0,0,0,0,100,100,0,0,3,${Math.max(10, style.outline * 2)},0,5,60,60,0,1`
    : `Style: Cap,${fam(style.font)},${style.size},${hex(style.color)},${hex(style.color)},&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,${style.outline},${style.shadow},5,60,60,0,1`;
  const hookStyle = `Style: Hook,${fam(hook.font)},${hook.size},${hex(hook.color)},${hex(hook.color)},&H00000000,&H80000000,0,0,0,0,100,100,1,0,1,${hook.outline ? 8 : 0},4,8,70,70,0,1`;
  const lines: string[] = [
    "[Script Info]", "ScriptType: v4.00+", `PlayResX: ${W}`, `PlayResY: ${H}`, "WrapStyle: 0", "ScaledBorderAndShadow: yes", "",
    "[V4+ Styles]",
    "Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding",
    capStyle, hookStyle, "Style: El,Poppins ExtraBold,60,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,0,0,0,0,100,100,0,0,1,4,2,5,40,40,0,1", "",
    "[Events]", "Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text",
  ];
  const ev = (layer: number, s: number, e: number, st: string, text: string) => lines.push(`Dialogue: ${layer},${tm(s)},${tm(Math.min(e, duration))},${st},,0,0,0,,${text}`);
  const y = Math.round((style.yPct / 100) * H);
  const T = (s: string) => (style.uppercase ? s.toUpperCase() : s);

  if (style.enabled) {
    for (const c of captions) {
      const pos = `\\an5\\pos(${W / 2},${y})`;
      if (style.preset === "dinamico" || style.wordsPerLine === 1) {
        c.words.forEach((w, i) => {
          const nxt = c.words[i + 1];
          const e = nxt ? nxt.start : c.end;
          const col = w.hl ? hex(style.highlight) : hex(style.color);
          const anim = style.animation ? "\\fscx70\\fscy70\\t(0,110,\\fscx108\\fscy108)\\t(110,200,\\fscx100\\fscy100)" : "";
          ev(1, w.start, Math.max(e, w.start + 0.15), "Cap", `{${pos}\\1c${col}${anim}}${esc(T(w.text))}`);
        });
      } else if (style.preset === "viral") {
        c.words.forEach((w, i) => {
          const nxt = c.words[i + 1];
          const s = i === 0 ? c.start : w.start;
          const e = nxt ? nxt.start : c.end;
          const txt = c.words
            .map((x, k) => (k === i ? `{\\1c${hex(style.highlight)}\\fscx114\\fscy114}${esc(T(x.text))}{\\1c${hex(style.color)}\\fscx100\\fscy100}` : esc(T(x.text))))
            .join(" ");
          ev(1, s, Math.max(e, s + 0.12), "Cap", `{${pos}${i === 0 && style.animation ? "\\fad(80,0)" : ""}}${txt}`);
        });
      } else {
        const txt = c.words.map((w) => (w.hl && style.preset !== "minimalista" ? `{\\1c${hex(style.highlight)}}${esc(T(w.text))}{\\1c${hex(style.color)}}` : esc(T(w.text)))).join(" ");
        ev(1, c.start, c.end, "Cap", `{${pos}${style.animation ? "\\fad(100,60)" : ""}}${txt}`);
      }
    }
  }

  if (hook.enabled && hook.text.trim()) {
    const hy = Math.round((hook.yPct / 100) * H);
    const words = esc(hook.text.toUpperCase()).split(/\s+/);
    let ai = -1, al = 4;
    words.forEach((w, i) => { const n = w.replace(/[^A-ZÀ-Ú0-9]/g, ""); if (n.length > al && !STOP.has(norm(n))) { al = n.length; ai = i; } });
    const txt = words.map((w, i) => (i === ai ? `{\\1c${hex(hook.accent)}}${w}{\\1c${hex(hook.color)}}` : w)).join(" ");
    const anim =
      hook.animation === "pop" ? `\\pos(${W / 2},${hy})\\fscx55\\fscy55\\t(0,180,\\fscx110\\fscy110)\\t(180,320,\\fscx100\\fscy100)\\fad(100,250)`
      : hook.animation === "slide" ? `\\move(${W / 2},${hy - 90},${W / 2},${hy},0,240)\\fad(100,250)`
      : hook.animation === "fade" ? `\\pos(${W / 2},${hy})\\fad(350,350)` : `\\pos(${W / 2},${hy})`;
    ev(3, hook.start, hook.start + hook.duration, "Hook", `{\\an8${anim}}${txt}`);
  }

  for (const el of elements) {
    const x = Math.round((el.x / 100) * W), yy = Math.round((el.y / 100) * H);
    if (el.type === "text" && el.text) ev(2, el.start, el.end, "El", `{\\an5\\pos(${x},${yy})\\fs${el.size || 60}\\1c${hex(el.color || "#FFFFFF")}\\fad(120,120)}${esc(el.text)}`);
    else if (el.type === "rect") {
      const w = Math.round(((el.w || 30) / 100) * W), h = Math.round(((el.h || 8) / 100) * H);
      ev(2, el.start, el.end, "El", `{\\an7\\pos(${x - w / 2},${yy - h / 2})\\p1\\bord0\\shad0\\1c${hex(el.color || "#7C5CFF")}\\1a&H40&}m 0 0 l ${w} 0 ${w} ${h} 0 ${h}{\\p0}`);
    }
  }
  return lines.join("\n") + "\n";
}
