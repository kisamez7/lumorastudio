import type { HookOption, Segment } from "@/lib/types";
import { cap, sentences, signalsOf, textInterest, topKeywords } from "./text";
import { llmAvailable, ollamaJson } from "./llm";

const up = (s: string) => s.toUpperCase();
const trimWords = (s: string, n: number) => {
  const w = s.replace(/["“”]/g, "").trim().split(/\s+/);
  return w.length > n ? w.slice(0, n).join(" ") + "…" : w.join(" ");
};

export type HookInput = { text: string; segments?: Segment[]; tags: string[]; durationSec: number; kind: string; peakSec?: number };

/**
 * Gera ≥3 hooks de abordagens distintas. REGRA: nunca inventar acontecimentos.
 * - Modelo local (Ollama), quando disponível, recebe a transcrição e é instruído a se limitar a ela.
 * - Fallback: modelos de frase que só usam palavras reais do trecho e sinais realmente detectados.
 */
export async function makeHooks(inp: HookInput): Promise<HookOption[]> {
  const out: HookOption[] = [];
  if (llmAvailable() && inp.text.length > 80) {
    const r = await ollamaJson<{ hooks?: { text: string; approach: string }[] }>(
      `Transcrição de um corte de vídeo (pt-BR):\n"""${inp.text.slice(0, 3500)}"""\n\nCrie 5 "hooks" (frases curtas de impacto que aparecem na tela nos primeiros segundos), cada um com abordagem diferente (Curiosidade, Surpresa, Humor, Mistério, Pergunta, Revelação, Emoção, Desafio ou Opinião forte). Regras: máximo 9 palavras, em MAIÚSCULAS, baseados ESTRITAMENTE no que a transcrição diz; NÃO invente acontecimentos nem distorça falas. Responda em JSON: {"hooks":[{"text":"...","approach":"..."}]}`,
      "Você é um editor de vídeos curtos honesto, que cria ganchos verdadeiros em português do Brasil.",
    );
    for (const h of r?.hooks || []) {
      const t = (h.text || "").trim();
      if (t && t.length <= 90 && t.split(/\s+/).length <= 12) out.push({ text: up(t), approach: h.approach || "Curiosidade", source: "llm" });
    }
  }
  const sents = sentences(inp.text);
  const ranked = sents
    .map((s) => ({ s, sig: signalsOf(s), w: s.split(/\s+/).length }))
    .filter((x) => x.w >= 4 && x.w <= 22)
    .sort((a, b) => textInterest(b.sig) * (b.w <= 11 ? 1.4 : 1) - textInterest(a.sig) * (a.w <= 11 ? 1.4 : 1));
  const kws = topKeywords(inp.text, 3);
  const kw = kws[0] ? up(kws[0]) : "";
  const tpl: HookOption[] = [];
  const q = ranked.find((x) => x.s.includes("?"));
  const sur = ranked.find((x) => x.sig.surprise > 0 || x.sig.excl > 0);
  const quote = ranked[0];
  if (sur) tpl.push({ text: up(trimWords(sur.s, 9)), approach: "Surpresa", source: "template" });
  if (q) tpl.push({ text: up(trimWords(q.s, 10)), approach: "Pergunta", source: "template" });
  else if (kw) tpl.push({ text: `VOCÊ JÁ PENSOU SOBRE ${kw}?`, approach: "Pergunta", source: "template" });
  if (quote && quote !== sur) tpl.push({ text: up(trimWords(quote.s, 9)), approach: "Revelação", source: "template" });
  if (kw) tpl.push({ text: `ASSISTA ATÉ O FINAL: ${kw}`, approach: "Curiosidade", source: "template" });
  else tpl.push({ text: "ASSISTA ATÉ O FINAL", approach: "Curiosidade", source: "template" });
  if (inp.tags.includes("humor/risadas")) tpl.push({ text: "TEM RISADA NESSE TRECHO", approach: "Humor", source: "template" });
  if (inp.tags.includes("opinião forte") && kw) tpl.push({ text: `OPINIÃO SEM FILTRO SOBRE ${kw}`, approach: "Opinião forte", source: "template" });
  if (inp.tags.includes("gameplay") || inp.kind === "game") tpl.push({ text: "ESPERE ATÉ O FINAL DESSA JOGADA", approach: "Desafio", source: "template" });
  tpl.push({ text: kw ? `O FINAL SOBRE ${kw} VALE A ESPERA` : "O MELHOR VEM NO FINAL", approach: "Mistério", source: "template" });
  for (const h of tpl) if (!out.some((o) => o.text === h.text) && h.text.length <= 90) out.push(h);
  const final = out.slice(0, 7);
  if (final.length) final[0].recommended = true;
  return final.map((h) => ({ ...h, text: cap(h.text, 90) }));
}
