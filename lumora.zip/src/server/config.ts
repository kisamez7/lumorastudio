import path from "node:path";

const num = (v: string | undefined, d: number) => {
  const n = Number(v);
  return v && Number.isFinite(n) ? n : d;
};

export const cfg = {
  mode: (process.env.APP_MODE || "local") as "local" | "hosted",
  storageDir: path.resolve(process.env.STORAGE_DIR || "storage"),
  fontsDir: path.resolve(process.env.FONTS_DIR || "assets/fonts"),
  maxUploadBytes: num(process.env.MAX_UPLOAD_MB, 4096) * 1024 * 1024,
  maxImportBytes: num(process.env.MAX_IMPORT_MB, 2048) * 1024 * 1024,
  maxDurationSec: num(process.env.MAX_VIDEO_MINUTES, 240) * 60,
  storageQuotaBytes: num(process.env.STORAGE_QUOTA_GB, 50) * 1024 * 1024 * 1024,
  whisperModel: process.env.WHISPER_MODEL || "Xenova/whisper-base",
  whisperLang: process.env.WHISPER_LANGUAGE || "pt",
  ollamaUrl: (process.env.OLLAMA_URL || "").replace(/\/$/, ""),
  ollamaModel: process.env.OLLAMA_MODEL || "llama3.1:8b",
  ollamaVisionModel: process.env.OLLAMA_VISION_MODEL || "",
  cvServiceUrl: (process.env.CV_SERVICE_URL || "").replace(/\/$/, ""),
  accessToken: process.env.APP_ACCESS_TOKEN || "",
  allowPrivateUrls: process.env.ALLOW_PRIVATE_URLS === "true",
  jobConcurrency: Math.max(1, num(process.env.JOB_CONCURRENCY, 2)),
  tmpTtlHours: num(process.env.TMP_TTL_HOURS, 24),
};
