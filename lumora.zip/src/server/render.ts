import fs from "node:fs/promises";
import path from "node:path";
import { CLIP_MAX, CLIP_MIN, type LayoutConfig, type Rect } from "@/lib/types";
import type { clips } from "@/db/schema";
import { cfg } from "./config";
import { abs, rmrf, tmpDir } from "./storage";
import { ffprobe, runFfmpeg } from "./ffmpeg";
import { buildAss } from "./ai/subtitles";

export type ClipRow = typeof clips.$inferSelect;
export type SrcInfo = { width: number; height: number; hasAudio: boolean; duration: number };

export class DurationError extends Error {}

/** Validação de backend da regra 60–90 s (cortes individuais). */
export function assertClipRange(start: number, end: number, srcDuration?: number) {
  const d = end - start;
  if (!Number.isFinite(d) || start < 0 || (srcDuration && end > srcDuration + 0.05)) throw new DurationError("Intervalo do corte inválido.");
  if (d < CLIP_MIN || d > CLIP_MAX) throw new DurationError(`Cortes individuais devem ter entre ${CLIP_MIN} e ${CLIP_MAX} segundos (atual: ${d.toFixed(1)} s). Para outras durações use Compilações.`);
}

const even = (n: number) => Math.max(2, Math.round(n / 2) * 2);
function rectPx(r: Rect | null, W: number, H: number) {
  const rr = r ?? { x: 0, y: 0, w: 1, h: 1 };
  const x = Math.min(W - 16, Math.max(0, Math.round(rr.x * W)));
  const y = Math.min(H - 16, Math.max(0, Math.round(rr.y * H)));
  const w = even(Math.min(W - x, Math.max(16, rr.w * W)));
  const h = even(Math.min(H - y, Math.max(16, rr.h * H)));
  return { x: x - (x % 2), y: y - (y % 2), w: Math.min(w, W - x - ((W - x) % 2)), h: Math.min(h, H - y - ((H - y) % 2)) };
}

const OW = 1080, OH = 1920;

function focusExpr(layout: LayoutConfig, range: number): string {
  const kf = [...layout.focus].sort((a, b) => a.t - b.t);
  if (!kf.length) return String((range * layout.focusX).toFixed(2));
  let expr = (range * kf[kf.length - 1].x).toFixed(2);
  for (let i = kf.length - 2; i >= -1; i--) {
    if (i === -1) {
      expr = `if(lt(t,${kf[0].t.toFixed(2)}),${(range * kf[0].x).toFixed(2)},${expr})`;
      continue;
    }
    const a = kf[i], b = kf[i + 1];
    const span = Math.max(0.1, b.t - a.t);
    // interpolação suave (smoothstep) entre keyframes -> movimentos sem trancos
    const u = `clip((t-${a.t.toFixed(2)})/${span.toFixed(2)},0,1)`;
    const s = `(${u}*${u}*(3-2*${u}))`;
    expr = `if(lt(t,${b.t.toFixed(2)}),${(range * a.x).toFixed(2)}+${(range * (b.x - a.x)).toFixed(2)}*${s},${expr})`;
  }
  return expr;
}

export function layoutGraph(layout: LayoutConfig, src: SrcInfo): { graph: string; mode: string; warning?: string } {
  const { width: W, height: H } = src;
  let mode = layout.mode;
  let warning: string | undefined;
  if ((mode === "A" || mode === "B" || mode === "C") && !layout.cam) {
    warning = `Layout ${mode} requer a região da webcam (defina no Reenquadramento). Usando enquadramento com fundo desfocado.`;
    mode = "fit";
  }
  const bg = (inp: string) => `[${inp}]scale=${OW}:${OH}:force_original_aspect_ratio=increase,crop=${OW}:${OH},boxblur=40:6,eq=brightness=-0.1:saturation=1.1[bg]`;
  const fitBox = (inp: string, r: ReturnType<typeof rectPx>, bw: number, bh: number, out: string) =>
    `[${inp}]crop=${r.w}:${r.h}:${r.x}:${r.y},scale=${bw}:${bh}:force_original_aspect_ratio=decrease,setsar=1[${out}]`;
  if (mode === "fit") {
    return { mode, warning, graph: `[0:v]split=2[s0][s1];${bg("s0")};[s1]scale=${OW}:${OH}:force_original_aspect_ratio=decrease,setsar=1[fg];[bg][fg]overlay=(W-w)/2:(H-h)/2,format=yuv420p[v0]` };
  }
  if (mode === "A" || mode === "B") {
    const game = rectPx(layout.game, W, H);
    const cam = rectPx(layout.cam, W, H);
    const [gy, gh, cy, ch] = mode === "A" ? [260, 640, 920, 640] : [1140, 608, 200, 900];
    return {
      mode, warning,
      graph: [
        `[0:v]split=3[s0][s1][s2]`, bg("s0"),
        fitBox("s1", game, OW, gh, "g"), fitBox("s2", cam, OW, ch, "c"),
        `[bg][g]overlay=(W-w)/2:${gy}+(${gh}-h)/2[t1]`, `[t1][c]overlay=(W-w)/2:${cy}+(${ch}-h)/2,format=yuv420p[v0]`,
      ].join(";"),
    };
  }
  if (mode === "C") {
    const game = rectPx(layout.game, W, H);
    const cam = rectPx(layout.cam, W, H);
    const side = Math.min(cam.w, cam.h);
    const cx = cam.x + Math.floor((cam.w - side) / 2), cyy = cam.y + Math.floor((cam.h - side) / 2);
    return {
      mode, warning,
      graph: [
        `[0:v]split=3[s0][s1][s2]`, bg("s0"),
        `[s1]crop=${game.w}:${game.h}:${game.x}:${game.y},scale=${OW}:1260:force_original_aspect_ratio=increase,crop=${OW}:1260:(iw-ow)*${layout.focusX.toFixed(3)}:(ih-oh)/2,setsar=1[g]`,
        `[s2]crop=${even(side)}:${even(side)}:${cx - (cx % 2)}:${cyy - (cyy % 2)},scale=340:340,setsar=1[c]`,
        `[bg][g]overlay=0:260[t1]`, `[t1][c]overlay=700:1156,format=yuv420p[v0]`,
      ].join(";"),
    };
  }
  // D: dinâmico (crop 9:16 acompanhando focos com suavização)
  const cw = even(Math.min(W, (H * 9) / 16));
  const chh = even(Math.min(H, (W * 16) / 9));
  const range = Math.max(0, W - cw);
  return { mode, graph: `[0:v]crop=${cw}:${chh}:'${focusExpr(layout, range)}':'(ih-oh)/2',scale=${OW}:${OH}:flags=lanczos,setsar=1,format=yuv420p[v0]` };
}

export function audioChain(fx: ClipRow["audioFx"], d: number): string {
  const f: string[] = ["aresample=44100"];
  if (fx.denoise) f.push("highpass=f=70", "afftdn=nr=14:nf=-45");
  if (fx.voice) f.push("highpass=f=90", "acompressor=threshold=-20dB:ratio=3:attack=5:release=80", "equalizer=f=3000:t=q:w=1:g=3");
  if (fx.normalize) f.push("loudnorm=I=-16:TP=-1.5:LRA=11");
  if (fx.fade) f.push("afade=t=in:st=0:d=0.3", `afade=t=out:st=${(d - 0.4).toFixed(2)}:d=0.4`);
  return f.join(",");
}

export type RenderOpts = {
  srcAbs: string;
  src: SrcInfo;
  clip: ClipRow;
  outAbs: string;
  imageAssets?: Record<string, string>;
  musicAbs?: string | null;
  signal?: AbortSignal;
  onProgress?: (p: number) => void;
};

/** Renderiza um corte vertical 1080x1920 (H.264/AAC) com reenquadramento, hook, legendas e áudio. */
export async function renderClip(o: RenderOpts): Promise<{ duration: number; warning?: string; layoutMode: string }> {
  const { clip, src } = o;
  assertClipRange(clip.startSec, clip.endSec, src.duration);
  const d = clip.endSec - clip.startSec;
  const dir = await tmpDir();
  try {
    await fs.mkdir(path.join(dir, "fonts"), { recursive: true });
    for (const f of await fs.readdir(cfg.fontsDir).catch(() => [])) if (/\.(ttf|otf)$/i.test(f)) await fs.copyFile(path.join(cfg.fontsDir, f), path.join(dir, "fonts", f));
    await fs.writeFile(path.join(dir, "subs.ass"), buildAss({ captions: clip.captions, style: clip.captionStyle, hook: clip.hook, elements: clip.elements, duration: d }));

    const { graph, warning, mode } = layoutGraph(clip.layout, src);
    const args: string[] = ["-ss", clip.startSec.toFixed(3), "-t", d.toFixed(3), "-i", o.srcAbs];
    let idx = 1;
    const parts = [graph];
    let cur = "v0";
    for (const el of clip.elements.filter((e) => e.type === "image" && e.assetId && o.imageAssets?.[e.assetId])) {
      args.push("-loop", "1", "-t", d.toFixed(3), "-i", o.imageAssets![el.assetId!]);
      const w = even(((el.w || 40) / 100) * OW);
      parts.push(`[${idx}:v]scale=${w}:-2,format=rgba[im${idx}]`);
      parts.push(`[${cur}][im${idx}]overlay=${Math.round((el.x / 100) * OW)}-w/2:${Math.round((el.y / 100) * OH)}-h/2:enable='between(t,${el.start.toFixed(2)},${el.end.toFixed(2)})'[o${idx}]`);
      cur = `o${idx}`;
      idx++;
    }
    parts.push(`[${cur}]ass=subs.ass:fontsdir=fonts${clip.audioFx.fade ? `,fade=t=in:st=0:d=0.3,fade=t=out:st=${(d - 0.4).toFixed(2)}:d=0.4` : ""}[vout]`);
    let aIn = "0:a";
    if (!src.hasAudio) {
      args.push("-f", "lavfi", "-t", d.toFixed(3), "-i", "anullsrc=r=44100:cl=stereo");
      aIn = `${idx}:a`;
      idx++;
    }
    parts.push(`[${aIn}]${audioChain(clip.audioFx, d)}[a0]`);
    let aOut = "a0";
    if (o.musicAbs) {
      args.push("-stream_loop", "-1", "-i", o.musicAbs);
      parts.push(`[${idx}:a]aresample=44100,volume=${clip.audioFx.musicVolume.toFixed(2)}[mus]`, `[a0][mus]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[amix]`);
      aOut = "amix";
      idx++;
    }
    args.push(
      "-filter_complex", parts.join(";"), "-map", "[vout]", "-map", `[${aOut}]`,
      "-t", d.toFixed(3), "-r", "30", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p",
      "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", path.join(dir, "out.mp4"),
    );
    await runFfmpeg(args, { cwd: dir, totalSec: d, onProgress: o.onProgress, signal: o.signal });
    // validação pós-render com a duração REAL do arquivo
    const probe = await ffprobe(path.join(dir, "out.mp4"));
    if (probe.duration < CLIP_MIN - 0.05 || probe.duration > CLIP_MAX + 0.05) throw new DurationError(`Duração renderizada fora de 60–90 s (${probe.duration.toFixed(2)} s). Arquivo descartado.`);
    await fs.mkdir(path.dirname(o.outAbs), { recursive: true });
    await fs.copyFile(path.join(dir, "out.mp4"), o.outAbs);
    return { duration: probe.duration, warning, layoutMode: mode };
  } finally {
    await rmrf(dir);
  }
}

export function absPath(rel: string) {
  return abs(rel);
}
