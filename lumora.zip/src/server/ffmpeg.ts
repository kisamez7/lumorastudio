import { spawn, execFile } from "node:child_process";
import fs from "node:fs";
import path from "node:path";
import ffmpegStatic from "ffmpeg-static";
import { path as ffprobeInstaller } from "@ffprobe-installer/ffprobe";

function resolveBin(envName: string, candidates: (string | null | undefined)[], fallback: string): string {
  const fromEnv = process.env[envName];
  if (fromEnv) return fromEnv;
  for (const c of candidates) if (c && fs.existsSync(c)) return c;
  return fallback;
}

export const FFMPEG = resolveBin("FFMPEG_PATH", [ffmpegStatic, path.join(process.cwd(), "node_modules/ffmpeg-static/ffmpeg")], "ffmpeg");
export const FFPROBE = resolveBin(
  "FFPROBE_PATH",
  [ffprobeInstaller, path.join(process.cwd(), "node_modules/@ffprobe-installer/linux-x64/ffprobe")],
  "ffprobe",
);

export type ProbeResult = {
  duration: number;
  width: number | null;
  height: number | null;
  fps: number | null;
  format: string;
  hasVideo: boolean;
  hasAudio: boolean;
  videoCodec: string | null;
  audioCodec: string | null;
  bitrate: number | null;
  size: number;
};

export function ffprobe(file: string): Promise<ProbeResult> {
  return new Promise((resolve, reject) => {
    execFile(FFPROBE, ["-v", "error", "-print_format", "json", "-show_format", "-show_streams", file], { maxBuffer: 16 * 1024 * 1024, timeout: 60000 }, (err, stdout) => {
      if (err) return reject(new Error("Arquivo inválido ou corrompido (ffprobe falhou)."));
      try {
        const j = JSON.parse(stdout);
        const v = (j.streams || []).find((s: { codec_type: string; disposition?: { attached_pic?: number } }) => s.codec_type === "video" && s.disposition?.attached_pic !== 1);
        const a = (j.streams || []).find((s: { codec_type: string }) => s.codec_type === "audio");
        let fps: number | null = null;
        if (v?.avg_frame_rate && v.avg_frame_rate !== "0/0") {
          const [n, d] = v.avg_frame_rate.split("/").map(Number);
          if (d) fps = Math.round((n / d) * 100) / 100;
        }
        const duration = Number(j.format?.duration ?? v?.duration ?? a?.duration ?? 0);
        resolve({
          duration: Number.isFinite(duration) ? duration : 0,
          width: v?.width ?? null,
          height: v?.height ?? null,
          fps,
          format: String(j.format?.format_name || "").split(",")[0],
          hasVideo: !!v,
          hasAudio: !!a,
          videoCodec: v?.codec_name ?? null,
          audioCodec: a?.codec_name ?? null,
          bitrate: j.format?.bit_rate ? Number(j.format.bit_rate) : null,
          size: Number(j.format?.size ?? 0),
        });
      } catch {
        reject(new Error("Não foi possível interpretar os metadados do arquivo."));
      }
    });
  });
}

export type RunOpts = {
  cwd?: string;
  totalSec?: number;
  onProgress?: (p: number) => void;
  signal?: AbortSignal;
};

/** Executa FFmpeg sem shell (args em array) com progresso real e cancelamento. */
export function runFfmpeg(args: string[], opts: RunOpts = {}): Promise<{ stderr: string }> {
  return new Promise((resolve, reject) => {
    const full = ["-hide_banner", "-nostdin", "-y", "-progress", "pipe:1", "-nostats", ...args];
    const p = spawn(FFMPEG, full, { cwd: opts.cwd, stdio: ["ignore", "pipe", "pipe"] });
    let stderr = "";
    let buf = "";
    const onAbort = () => p.kill("SIGKILL");
    opts.signal?.addEventListener("abort", onAbort, { once: true });
    if (opts.signal?.aborted) onAbort();
    p.stdout.on("data", (d: Buffer) => {
      buf += d.toString();
      let idx: number;
      while ((idx = buf.indexOf("\n")) >= 0) {
        const line = buf.slice(0, idx).trim();
        buf = buf.slice(idx + 1);
        const m = line.match(/^out_time_(?:us|ms)=(\d+)/);
        if (m && opts.totalSec && opts.onProgress) opts.onProgress(Math.min(1, Number(m[1]) / 1e6 / opts.totalSec));
      }
    });
    p.stderr.on("data", (d: Buffer) => {
      stderr += d.toString();
      if (stderr.length > 200000) stderr = stderr.slice(-100000);
    });
    p.on("error", (e) => reject(new Error("FFmpeg indisponível: " + e.message)));
    p.on("close", (code) => {
      opts.signal?.removeEventListener("abort", onAbort);
      if (opts.signal?.aborted) return reject(new Error("Cancelado"));
      if (code === 0) resolve({ stderr });
      else reject(new Error("FFmpeg falhou: " + stderr.split("\n").filter(Boolean).slice(-4).join(" | ")));
    });
  });
}

/** Executa FFmpeg e entrega stdout em streaming (usado na análise de áudio e visual). */
export function streamFfmpeg(args: string[], onStdout: (chunk: Buffer) => void, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    const p = spawn(FFMPEG, ["-hide_banner", "-nostdin", "-v", "error", ...args], { stdio: ["ignore", "pipe", "pipe"] });
    let err = "";
    const onAbort = () => p.kill("SIGKILL");
    signal?.addEventListener("abort", onAbort, { once: true });
    p.stdout.on("data", onStdout);
    p.stderr.on("data", (d: Buffer) => (err += d.toString()));
    p.on("error", (e) => reject(e));
    p.on("close", (code) => {
      signal?.removeEventListener("abort", onAbort);
      if (signal?.aborted) return reject(new Error("Cancelado"));
      if (code === 0) resolve();
      else reject(new Error("FFmpeg falhou na análise: " + err.slice(-300)));
    });
  });
}
