import fs from "node:fs/promises";
import path from "node:path";
import { cfg } from "./config";
import { ffprobe, runFfmpeg } from "./ffmpeg";
import { rmrf, tmpDir } from "./storage";

type Common = { signal?: AbortSignal; onProgress?: (p: number) => void };

/** Conversão/extração a partir de um arquivo local. Nunca amplia resolução acima da original. */
export async function convertMedia(srcAbs: string, outAbs: string, o: Common & { format: "mp4" | "webm" | "mp3" | "wav"; height?: number }) {
  const info = await ffprobe(srcAbs);
  await fs.mkdir(path.dirname(outAbs), { recursive: true });
  const args = ["-i", srcAbs];
  if (o.format === "mp3") args.push("-vn", "-c:a", "libmp3lame", "-q:a", "2");
  else if (o.format === "wav") args.push("-vn", "-c:a", "pcm_s16le", "-ar", "44100");
  else {
    if (!info.hasVideo) throw new Error("O arquivo não possui vídeo.");
    if (o.height && info.height && o.height > info.height) throw new Error(`Resolução ${o.height}p indisponível: o original tem ${info.height}p (não ampliamos artificialmente).`);
    if (o.height && info.height && o.height < info.height) args.push("-vf", `scale=-2:${o.height}`);
    if (o.format === "mp4") args.push("-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart");
    else args.push("-c:v", "libvpx-vp9", "-b:v", "0", "-crf", "33", "-deadline", "realtime", "-cpu-used", "5", "-c:a", "libopus");
  }
  args.push(outAbs);
  await runFfmpeg(args, { totalSec: info.duration, ...o });
  return ffprobe(outAbs);
}

/** Processa o áudio de um arquivo (denoise, normalização, voz, remoção de silêncio) -> MP3. */
export async function processAudio(srcAbs: string, outAbs: string, o: Common & { denoise: boolean; normalize: boolean; voice: boolean; removeSilence: boolean }) {
  const info = await ffprobe(srcAbs);
  if (!info.hasAudio) throw new Error("O arquivo não possui áudio.");
  const f: string[] = [];
  if (o.denoise) f.push("highpass=f=70", "afftdn=nr=14:nf=-45");
  if (o.voice) f.push("highpass=f=90", "acompressor=threshold=-20dB:ratio=3:attack=5:release=80", "equalizer=f=3000:t=q:w=1:g=3");
  if (o.removeSilence) f.push("silenceremove=start_periods=1:start_threshold=-45dB:stop_periods=-1:stop_duration=0.8:stop_threshold=-45dB");
  if (o.normalize) f.push("loudnorm=I=-16:TP=-1.5:LRA=11");
  await fs.mkdir(path.dirname(outAbs), { recursive: true });
  await runFfmpeg(["-i", srcAbs, "-vn", ...(f.length ? ["-af", f.join(",")] : []), "-c:a", "libmp3lame", "-q:a", "2", outAbs], { totalSec: info.duration, ...o });
  return ffprobe(outAbs);
}

/** Compilação: une cortes já renderizados com transições. NÃO é um corte individual (duração livre). */
export async function compileVideos(files: string[], outAbs: string, o: Common & { transition: "fade" | "zoomin" | "slideleft" | "none"; td?: number }) {
  if (files.length < 2) throw new Error("Selecione ao menos 2 trechos para compilar.");
  const infos = await Promise.all(files.map((f) => ffprobe(f)));
  const td = o.transition === "none" ? 0 : o.td ?? 0.5;
  const args: string[] = [];
  const parts: string[] = [];
  files.forEach((f, i) => {
    args.push("-i", f);
    parts.push(`[${i}:v]scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30,format=yuv420p,settb=AVTB[v${i}]`);
    parts.push(`[${i}:a]aresample=44100,aformat=channel_layouts=stereo[a${i}]`);
  });
  let total = infos.reduce((a, b) => a + b.duration, 0);
  if (o.transition === "none") {
    parts.push(`${files.map((_, i) => `[v${i}][a${i}]`).join("")}concat=n=${files.length}:v=1:a=1[vout][aout]`);
  } else {
    let acc = infos[0].duration;
    let vl = "v0", al = "a0";
    for (let i = 1; i < files.length; i++) {
      const off = Math.max(0, acc - td);
      parts.push(`[${vl}][v${i}]xfade=transition=${o.transition}:duration=${td}:offset=${off.toFixed(3)}[x${i}]`);
      parts.push(`[${al}][a${i}]acrossfade=d=${td}[c${i}]`);
      vl = `x${i}`;
      al = `c${i}`;
      acc = off + infos[i].duration;
    }
    total = acc;
    parts.push(`[${vl}]null[vout]`, `[${al}]anull[aout]`);
  }
  await fs.mkdir(path.dirname(outAbs), { recursive: true });
  args.push("-filter_complex", parts.join(";"), "-map", "[vout]", "-map", "[aout]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "20", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", outAbs);
  await runFfmpeg(args, { totalSec: total, ...o });
  return ffprobe(outAbs);
}

function wrapText(t: string, max: number): string {
  const out: string[] = [];
  let line = "";
  for (const w of t.split(/\s+/)) {
    if ((line + " " + w).trim().length > max) { out.push(line); line = w; } else line = (line + " " + w).trim();
  }
  if (line) out.push(line);
  return out.join("\n");
}

/** Gerador de vídeo a partir de roteiro (slides animados com texto). Local, sem APIs pagas, sem narração. */
export async function scriptToVideo(script: string, outAbs: string, o: Common & { aspect: "9:16" | "16:9" | "1:1"; secondsPerSlide: number; palette: number }) {
  const slides = script.split(/\n{1,}/).map((s) => s.trim()).filter(Boolean).slice(0, 40);
  if (!slides.length) throw new Error("Escreva um roteiro (um parágrafo por slide).");
  const [W, H] = o.aspect === "9:16" ? [1080, 1920] : o.aspect === "16:9" ? [1920, 1080] : [1080, 1080];
  const dir = await tmpDir();
  try {
    await fs.mkdir(path.join(dir, "fonts"), { recursive: true });
    await fs.copyFile(path.join(cfg.fontsDir, "Poppins-ExtraBold.ttf"), path.join(dir, "fonts", "f.ttf")).catch(() => { throw new Error("Fonte ausente em assets/fonts."); });
    const colors = [["0x1a1033", "0x0d2a4a"], ["0x0b1f1a", "0x241046"], ["0x1c1c24", "0x2a0f3d"]][o.palette % 3];
    const args: string[] = [];
    const parts: string[] = [];
    const size = o.aspect === "16:9" ? 64 : 70;
    const maxChars = o.aspect === "16:9" ? 34 : 20;
    for (let i = 0; i < slides.length; i++) {
      const dur = Math.max(o.secondsPerSlide, Math.min(12, slides[i].split(/\s+/).length / 2.5));
      await fs.writeFile(path.join(dir, `s${i}.txt`), wrapText(slides[i], maxChars));
      args.push("-f", "lavfi", "-t", dur.toFixed(2), "-i", `color=c=${colors[i % 2]}:s=${W}x${H}:r=30`);
      parts.push(`[${i}:v]drawtext=fontfile=fonts/f.ttf:textfile=s${i}.txt:fontsize=${size}:fontcolor=white:line_spacing=18:x=(w-text_w)/2:y=(h-text_h)/2:borderw=3:bordercolor=black@0.6,fade=t=in:st=0:d=0.4,fade=t=out:st=${(dur - 0.4).toFixed(2)}:d=0.4,format=yuv420p[v${i}]`);
    }
    parts.push(`${slides.map((_, i) => `[v${i}]`).join("")}concat=n=${slides.length}:v=1:a=0[vout]`);
    args.push("-f", "lavfi", "-i", "anullsrc=r=44100:cl=stereo");
    await fs.mkdir(path.dirname(outAbs), { recursive: true });
    args.push("-filter_complex", parts.join(";"), "-map", "[vout]", "-map", `${slides.length}:a`, "-shortest", "-c:v", "libx264", "-preset", "veryfast", "-crf", "21", "-c:a", "aac", "-movflags", "+faststart", path.join(dir, "o.mp4"));
    await runFfmpeg(args, { cwd: dir, totalSec: slides.length * o.secondsPerSlide, ...o });
    await fs.copyFile(path.join(dir, "o.mp4"), outAbs);
    return ffprobe(outAbs);
  } finally {
    await rmrf(dir);
  }
}

export async function extractFrame(srcAbs: string, t: number, outAbs: string, width = 720) {
  await fs.mkdir(path.dirname(outAbs), { recursive: true });
  await runFfmpeg(["-ss", t.toFixed(2), "-i", srcAbs, "-frames:v", "1", "-vf", `scale=${width}:-2`, "-q:v", "3", outAbs]);
}
