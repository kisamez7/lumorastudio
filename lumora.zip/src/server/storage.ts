import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import { Transform } from "node:stream";
import { cfg } from "./config";

/**
 * Camada de armazenamento. Driver atual: disco local/volume persistente (STORAGE_DIR).
 * Todo acesso passa por caminhos relativos -> impede path traversal.
 * Para S3, implemente esta mesma interface (ver README, seção Armazenamento).
 */
export function abs(rel: string): string {
  const full = path.resolve(cfg.storageDir, rel);
  if (!full.startsWith(cfg.storageDir + path.sep)) throw new Error("Caminho inválido");
  return full;
}

export async function ensureDir(rel: string) {
  await fsp.mkdir(abs(rel), { recursive: true });
}

export function newRel(scope: string, ext: string): string {
  const safeExt = ext.replace(/[^a-z0-9]/gi, "").toLowerCase().slice(0, 8) || "bin";
  const id = crypto.randomUUID();
  return path.posix.join(scope.replace(/[^a-z0-9_-]/gi, ""), `${id}.${safeExt}`);
}

export async function tmpDir(): Promise<string> {
  const rel = path.posix.join("tmp", crypto.randomUUID());
  await ensureDir(rel);
  return abs(rel);
}

export async function rmrf(p: string) {
  await fsp.rm(p, { recursive: true, force: true }).catch(() => {});
}

export async function removeRel(rel: string) {
  await fsp.rm(abs(rel), { force: true }).catch(() => {});
}

export class SizeLimitError extends Error {}

/** Grava um stream no disco aplicando limite de bytes. */
export async function saveStream(rel: string, input: Readable | ReadableStream<Uint8Array>, maxBytes: number, signal?: AbortSignal, onBytes?: (n: number) => void): Promise<number> {
  await ensureDir(path.posix.dirname(rel));
  const target = abs(rel);
  let total = 0;
  const limiter = new Transform({
    transform(chunk, _enc, cb) {
      total += chunk.length;
      onBytes?.(total);
      if (total > maxBytes) return cb(new SizeLimitError(`Arquivo excede o limite de ${Math.round(maxBytes / 1048576)} MB`));
      cb(null, chunk);
    },
  });
  const src = input instanceof Readable ? input : Readable.fromWeb(input as never);
  try {
    await pipeline(src, limiter, fs.createWriteStream(target), signal ? { signal } : {});
  } catch (e) {
    await fsp.rm(target, { force: true }).catch(() => {});
    throw e;
  }
  return total;
}

export async function dirSize(dir: string): Promise<number> {
  let total = 0;
  const entries = await fsp.readdir(dir, { withFileTypes: true }).catch(() => []);
  for (const e of entries) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) total += await dirSize(p);
    else total += (await fsp.stat(p).catch(() => null))?.size ?? 0;
  }
  return total;
}

export async function storageUsage() {
  await fsp.mkdir(cfg.storageDir, { recursive: true });
  const used = await dirSize(cfg.storageDir);
  let free: number | null = null;
  try {
    const s = await fsp.statfs(cfg.storageDir);
    free = Number(s.bavail) * Number(s.bsize);
  } catch {}
  return { used, free, quota: cfg.storageQuotaBytes };
}

/** Remove temporários antigos (importações interrompidas, renders abandonados). */
export async function cleanupTmp() {
  const dir = abs("tmp");
  const entries = await fsp.readdir(dir, { withFileTypes: true }).catch(() => []);
  const limit = Date.now() - cfg.tmpTtlHours * 3600 * 1000;
  for (const e of entries) {
    const p = path.join(dir, e.name);
    const st = await fsp.stat(p).catch(() => null);
    if (st && st.mtimeMs < limit) await rmrf(p);
  }
}

export async function assertSpace(bytesNeeded: number) {
  const u = await storageUsage();
  if (u.used + bytesNeeded > u.quota) throw new Error("Cota de armazenamento excedida. Libere espaço em Arquivos.");
  if (u.free !== null && u.free < bytesNeeded + 200 * 1024 * 1024) throw new Error("Espaço em disco insuficiente.");
}
