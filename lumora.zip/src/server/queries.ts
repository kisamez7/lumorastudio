import { desc, eq, inArray, sql } from "drizzle-orm";
import { db } from "@/db";
import { assets, clips, projects } from "@/db/schema";
import { assetDto } from "./assets";

export async function projectList() {
  const rows = await db.select().from(projects).orderBy(desc(projects.updatedAt));
  const ids = rows.map((r) => r.sourceAssetId).filter(Boolean) as string[];
  const as = ids.length ? await db.select().from(assets).where(inArray(assets.id, ids)) : [];
  const counts = await db.select({ projectId: clips.projectId, n: sql<number>`count(*)::int`, rendered: sql<number>`count(*) filter (where ${clips.status} = 'rendered')::int` }).from(clips).groupBy(clips.projectId);
  return rows.map((p) => ({
    ...p,
    createdAt: p.createdAt.toISOString(),
    updatedAt: p.updatedAt.toISOString(),
    source: as.find((a) => a.id === p.sourceAssetId) ? assetDto(as.find((a) => a.id === p.sourceAssetId)!) : null,
    clipCount: counts.find((c) => c.projectId === p.id)?.n ?? 0,
    renderedCount: counts.find((c) => c.projectId === p.id)?.rendered ?? 0,
  }));
}

export async function clipsWithOutput(projectId: string) {
  const rows = await db.select().from(clips).where(eq(clips.projectId, projectId)).orderBy(desc(clips.score), desc(clips.createdAt));
  const ids = rows.map((r) => r.outputAssetId).filter(Boolean) as string[];
  const as = ids.length ? await db.select().from(assets).where(inArray(assets.id, ids)) : [];
  return rows.map((c) => ({
    ...c,
    createdAt: c.createdAt.toISOString(),
    updatedAt: c.updatedAt.toISOString(),
    output: as.find((a) => a.id === c.outputAssetId) ? assetDto(as.find((a) => a.id === c.outputAssetId)!) : null,
  }));
}
