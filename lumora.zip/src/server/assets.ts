import { eq } from "drizzle-orm";
import { db } from "@/db";
import { assets } from "@/db/schema";
import { ffprobe } from "./ffmpeg";
import { abs } from "./storage";
import fsp from "node:fs/promises";

export type AssetRow = typeof assets.$inferSelect;

const MIME: Record<string, string> = { mp4: "video/mp4", webm: "video/webm", mov: "video/quicktime", mkv: "video/x-matroska", m4v: "video/mp4", mp3: "audio/mpeg", wav: "audio/wav", m4a: "audio/mp4", aac: "audio/aac", ogg: "audio/ogg", png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", srt: "text/plain", zip: "application/zip" };
export const mimeFor = (ext: string) => MIME[ext.toLowerCase()] || "application/octet-stream";

/** Registra um arquivo já gravado no storage, extraindo metadados reais com ffprobe (quando mídia). */
export async function registerAsset(opts: { projectId: string | null; kind: string; filename: string; relPath: string; mime?: string; probe?: boolean; meta?: Record<string, unknown> }): Promise<AssetRow> {
  const full = abs(opts.relPath);
  const st = await fsp.stat(full);
  let info: Awaited<ReturnType<typeof ffprobe>> | null = null;
  if (opts.probe !== false) info = await ffprobe(full).catch(() => null);
  const ext = opts.filename.split(".").pop() || "";
  const [row] = await db
    .insert(assets)
    .values({
      projectId: opts.projectId,
      kind: opts.kind,
      filename: opts.filename,
      relPath: opts.relPath,
      mime: opts.mime || mimeFor(ext),
      sizeBytes: st.size,
      durationSec: info?.duration ?? null,
      width: info?.width ?? null,
      height: info?.height ?? null,
      fps: info?.fps ?? null,
      format: info?.format ?? ext,
      hasAudio: info?.hasAudio ?? null,
      meta: { ...(opts.meta || {}), videoCodec: info?.videoCodec ?? null, audioCodec: info?.audioCodec ?? null, bitrate: info?.bitrate ?? null },
    })
    .returning();
  return row;
}

export async function getAsset(id: string): Promise<AssetRow | null> {
  const [a] = await db.select().from(assets).where(eq(assets.id, id));
  return a ?? null;
}

export function assetDto(a: AssetRow) {
  return {
    id: a.id,
    projectId: a.projectId,
    kind: a.kind,
    filename: a.filename,
    mime: a.mime,
    sizeBytes: a.sizeBytes,
    durationSec: a.durationSec,
    width: a.width,
    height: a.height,
    fps: a.fps,
    format: a.format,
    hasAudio: a.hasAudio,
    meta: a.meta,
    createdAt: a.createdAt.toISOString(),
    url: `/api/assets/${a.id}`,
  };
}
