import { NextResponse } from "next/server";
import { cfg } from "./config";

export type Ctx<P extends Record<string, string> = { id: string }> = { params: Promise<P> };

export const fail = (status: number, error: string) => NextResponse.json({ error }, { status });
export const ok = <T,>(data: T, status = 200) => NextResponse.json(data as never, { status });

export async function body<T = Record<string, unknown>>(req: Request): Promise<T> {
  try {
    return (await req.json()) as T;
  } catch {
    return {} as T;
  }
}

export function isUuid(s: string): boolean {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);
}

/** Envolve handlers: converte exceções em respostas JSON seguras (sem vazar stack). */
export function handler<A extends unknown[]>(fn: (...a: A) => Promise<Response>) {
  return async (...a: A): Promise<Response> => {
    try {
      return await fn(...a);
    } catch (e) {
      const msg = e instanceof Error ? e.message : "Erro inesperado";
      console.error("[api]", msg);
      return fail(500, msg.slice(0, 300));
    }
  };
}

/** Autenticação para rotas excluídas do proxy (uploads grandes, que o proxy limitaria a 10 MB). */
export function requireAuth(req: Request): Response | null {
  if (!cfg.accessToken) return null;
  const cookie = req.headers.get("cookie")?.match(/(?:^|;\s*)lumora_session=([^;]+)/)?.[1];
  const bearer = req.headers.get("authorization")?.replace(/^Bearer\s+/i, "");
  return cookie === cfg.accessToken || bearer === cfg.accessToken ? null : fail(401, "Não autorizado");
}
