import { eq, inArray, desc, and } from "drizzle-orm";
import { db } from "@/db";
import { jobs } from "@/db/schema";
import { cfg } from "./config";
import { cleanupTmp } from "./storage";
import type { JobInfo } from "@/lib/types";

/**
 * Fila de tarefas em segundo plano (processo do servidor, concorrência limitada).
 * - O estado fica no PostgreSQL (progress/status/result) -> o frontend acompanha por SSE/polling.
 * - Cancelamento real via AbortController (mata o processo FFmpeg/Whisper).
 * - Recuperação: tarefas "running/queued" órfãs após reinício são marcadas como interrompidas.
 * Para escala horizontal, esta interface é substituída por Redis + workers (ver README).
 */
type State = { ctrls: Map<string, AbortController>; active: number; waiting: (() => void)[]; recovered: boolean };
const g = globalThis as unknown as { __lumoraJobs?: State };
const state: State = (g.__lumoraJobs ??= { ctrls: new Map(), active: 0, waiting: [], recovered: false });

export type JobCtx = {
  id: string;
  signal: AbortSignal;
  progress: (p: number, msg?: string) => Promise<void>;
};

export async function recoverJobs() {
  if (state.recovered) return;
  state.recovered = true;
  const live = [...state.ctrls.keys()];
  const stale = await db.select({ id: jobs.id }).from(jobs).where(inArray(jobs.status, ["queued", "running"]));
  for (const j of stale) {
    if (live.includes(j.id)) continue;
    await db.update(jobs).set({ status: "failed", error: "Tarefa interrompida por reinício do servidor. Inicie novamente.", updatedAt: new Date() }).where(eq(jobs.id, j.id));
  }
  await cleanupTmp().catch(() => {});
}

export async function enqueueJob<T>(type: string, projectId: string | null, input: Record<string, unknown>, fn: (ctx: JobCtx) => Promise<T>): Promise<string> {
  await recoverJobs();
  const [row] = await db.insert(jobs).values({ type, projectId, input, status: "queued", message: "Na fila" }).returning({ id: jobs.id });
  const id = row.id;
  const ctrl = new AbortController();
  state.ctrls.set(id, ctrl);
  void run(id, ctrl, fn);
  return id;
}

async function acquire() {
  if (state.active < cfg.jobConcurrency) {
    state.active++;
    return;
  }
  await new Promise<void>((r) => state.waiting.push(r));
  state.active++;
}
function release() {
  state.active--;
  state.waiting.shift()?.();
}

async function run<T>(id: string, ctrl: AbortController, fn: (ctx: JobCtx) => Promise<T>) {
  await acquire();
  let last = 0;
  let lastP = -1;
  const progress = async (p: number, msg?: string) => {
    const now = Date.now();
    const pi = Math.max(0, Math.min(100, Math.round(p * 100)));
    if (now - last < 700 && pi - lastP < 3 && pi < 100) return;
    last = now;
    lastP = pi;
    await db.update(jobs).set({ progress: pi, ...(msg ? { message: msg } : {}), updatedAt: new Date() }).where(eq(jobs.id, id)).catch(() => {});
  };
  try {
    if (ctrl.signal.aborted) throw new Error("Cancelado");
    await db.update(jobs).set({ status: "running", message: "Processando", updatedAt: new Date() }).where(eq(jobs.id, id));
    const result = await fn({ id, signal: ctrl.signal, progress });
    await db.update(jobs).set({ status: "done", progress: 100, result: (result ?? null) as never, message: "Concluído", updatedAt: new Date() }).where(eq(jobs.id, id));
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (ctrl.signal.aborted || msg === "Cancelado") {
      await db.update(jobs).set({ status: "canceled", message: "Cancelado pelo usuário", updatedAt: new Date() }).where(eq(jobs.id, id));
    } else {
      await db.update(jobs).set({ status: "failed", error: msg.slice(0, 1000), message: "Falhou", updatedAt: new Date() }).where(eq(jobs.id, id));
    }
  } finally {
    state.ctrls.delete(id);
    release();
  }
}

export async function cancelJob(id: string): Promise<boolean> {
  const c = state.ctrls.get(id);
  await db.update(jobs).set({ cancelRequested: true, updatedAt: new Date() }).where(eq(jobs.id, id));
  if (c) {
    c.abort();
    return true;
  }
  // job órfão
  await db.update(jobs).set({ status: "canceled", message: "Cancelado", updatedAt: new Date() }).where(and(eq(jobs.id, id), inArray(jobs.status, ["queued", "running"])));
  return false;
}

export function toJobInfo(j: typeof jobs.$inferSelect): JobInfo {
  return {
    id: j.id,
    type: j.type,
    status: j.status as JobInfo["status"],
    progress: j.progress,
    message: j.message,
    error: j.error,
    result: j.result,
    projectId: j.projectId,
    createdAt: j.createdAt.toISOString(),
    updatedAt: j.updatedAt.toISOString(),
  };
}

export async function listJobs(projectId?: string | null, limit = 30): Promise<JobInfo[]> {
  await recoverJobs();
  const q = db.select().from(jobs);
  const rows = await (projectId ? q.where(eq(jobs.projectId, projectId)) : q).orderBy(desc(jobs.createdAt)).limit(limit);
  return rows.map(toJobInfo);
}

export async function getJob(id: string): Promise<JobInfo | null> {
  const [j] = await db.select().from(jobs).where(eq(jobs.id, id));
  return j ? toJobInfo(j) : null;
}
