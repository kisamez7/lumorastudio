import dns from "node:dns";
import net from "node:net";
import http from "node:http";
import https from "node:https";
import type { IncomingMessage } from "node:http";
import { cfg } from "./config";

export class UrlError extends Error {}

export function isPrivateIp(ip: string): boolean {
  const v = net.isIP(ip);
  if (v === 4) {
    const [a, b] = ip.split(".").map(Number);
    return (
      a === 0 || a === 10 || a === 127 || a >= 224 ||
      (a === 100 && b >= 64 && b <= 127) ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 192 && b === 0) ||
      (a === 198 && (b === 18 || b === 19))
    );
  }
  if (v === 6) {
    const l = ip.toLowerCase();
    if (l === "::" || l === "::1") return true;
    const mapped = l.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isPrivateIp(mapped[1]);
    return l.startsWith("fc") || l.startsWith("fd") || l.startsWith("fe8") || l.startsWith("fe9") || l.startsWith("fea") || l.startsWith("feb") || l.startsWith("ff");
  }
  return true;
}

export function parseUrl(raw: string): URL {
  let u: URL;
  try {
    u = new URL(raw.trim());
  } catch {
    throw new UrlError("URL inválida.");
  }
  if (u.protocol !== "http:" && u.protocol !== "https:") throw new UrlError("Somente URLs http(s) são aceitas.");
  if (u.username || u.password) throw new UrlError("URLs com credenciais embutidas não são aceitas.");
  if (raw.length > 2048) throw new UrlError("URL muito longa.");
  const port = u.port ? Number(u.port) : u.protocol === "https:" ? 443 : 80;
  if (![80, 443, 8080, 8443].includes(port) && !cfg.allowPrivateUrls) throw new UrlError("Porta não permitida.");
  const host = u.hostname.toLowerCase();
  if (!cfg.allowPrivateUrls && (host === "localhost" || host.endsWith(".local") || host.endsWith(".internal"))) {
    throw new UrlError("Endereços internos são bloqueados.");
  }
  return u;
}

/** lookup customizado: resolve e valida TODOS os IPs no momento da conexão (anti DNS-rebinding). */
const safeLookup: net.LookupFunction = (hostname, options, cb) => {
  dns.lookup(hostname, { all: true, family: 0 }, (err, addrs) => {
    if (err) return cb(err, "", 4);
    if (!cfg.allowPrivateUrls && addrs.some((a) => isPrivateIp(a.address))) {
      return cb(new UrlError("O endereço de destino é privado/interno e foi bloqueado (proteção SSRF).") as NodeJS.ErrnoException, "", 4);
    }
    const a = addrs[0];
    if ((options as { all?: boolean }).all) return (cb as unknown as (e: null, r: dns.LookupAddress[]) => void)(null, addrs);
    cb(null, a.address, a.family);
  });
};

export type SafeResponse = { res: IncomingMessage; url: URL; redirects: string[] };

/** GET/HEAD seguro: valida cada redirecionamento, host/IP, porta, e aplica timeout. Nunca executa comandos. */
export async function safeRequest(
  rawUrl: string,
  opts: { method?: "GET" | "HEAD"; headers?: Record<string, string>; signal?: AbortSignal; maxRedirects?: number; timeoutMs?: number } = {},
): Promise<SafeResponse> {
  let url = parseUrl(rawUrl);
  const redirects: string[] = [];
  const max = opts.maxRedirects ?? 5;
  for (let i = 0; i <= max; i++) {
    if (net.isIP(url.hostname.replace(/^\[|\]$/g, "")) && !cfg.allowPrivateUrls && isPrivateIp(url.hostname.replace(/^\[|\]$/g, ""))) {
      throw new UrlError("O endereço de destino é privado/interno e foi bloqueado (proteção SSRF).");
    }
    const lib = url.protocol === "https:" ? https : http;
    const res = await new Promise<IncomingMessage>((resolve, reject) => {
      const req = lib.request(
        url,
        {
          method: opts.method || "GET",
          headers: { "user-agent": "LumoraStudio/1.0 (+importador-autorizado)", accept: "*/*", ...(opts.headers || {}) },
          lookup: safeLookup,
          agent: false,
          timeout: opts.timeoutMs ?? 15000,
          signal: opts.signal,
        },
        resolve,
      );
      req.on("timeout", () => req.destroy(new UrlError("Tempo esgotado ao acessar a URL.")));
      req.on("error", reject);
      req.end();
    }).catch((e: Error) => {
      if (e instanceof UrlError) throw e;
      if ((e as NodeJS.ErrnoException).code === "ABORT_ERR" || e.name === "AbortError") throw new Error("Cancelado");
      if ((e as NodeJS.ErrnoException).cause instanceof UrlError) throw (e as NodeJS.ErrnoException).cause;
      throw new UrlError("Não foi possível acessar a URL (indisponível ou bloqueada): " + e.message);
    });
    const status = res.statusCode || 0;
    if ([301, 302, 303, 307, 308].includes(status) && res.headers.location) {
      res.resume();
      url = parseUrl(new URL(res.headers.location, url).toString());
      redirects.push(url.toString());
      continue;
    }
    return { res, url, redirects };
  }
  throw new UrlError("Redirecionamentos demais.");
}

export type Platform = { id: string; name: string; direct: boolean };

const HOSTS: [RegExp, Platform][] = [
  [/(^|\.)youtube\.com$|(^|\.)youtu\.be$/, { id: "youtube", name: "YouTube", direct: false }],
  [/(^|\.)tiktok\.com$/, { id: "tiktok", name: "TikTok", direct: false }],
  [/(^|\.)instagram\.com$/, { id: "instagram", name: "Instagram", direct: false }],
  [/(^|\.)facebook\.com$|(^|\.)fb\.watch$/, { id: "facebook", name: "Facebook", direct: false }],
  [/(^|\.)twitch\.tv$/, { id: "twitch", name: "Twitch", direct: false }],
  [/(^|\.)vimeo\.com$/, { id: "vimeo", name: "Vimeo", direct: false }],
  [/(^|\.)twitter\.com$|(^|\.)x\.com$/, { id: "x", name: "X (Twitter)", direct: false }],
];

export function detectPlatform(u: URL): Platform {
  const host = u.hostname.toLowerCase();
  for (const [re, p] of HOSTS) if (re.test(host)) return p;
  return { id: "direct", name: "URL direta / outra fonte", direct: true };
}

export function safeFilename(name: string): string {
  return name.replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_").replace(/\s+/g, " ").trim().slice(0, 120) || "arquivo";
}

export const VIDEO_EXT = ["mp4", "mov", "mkv", "webm", "m4v"];
export const AUDIO_EXT = ["mp3", "wav", "m4a", "aac", "ogg"];
export const IMAGE_EXT = ["png", "jpg", "jpeg", "webp"];

export function extOf(name: string): string {
  const m = name.toLowerCase().match(/\.([a-z0-9]{2,5})$/);
  return m ? m[1] : "";
}
