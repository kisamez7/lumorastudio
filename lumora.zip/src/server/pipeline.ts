import path from "node:path";
import fsp from "node:fs/promises";
import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { analyses, assets, clips, projects, transcripts } from "@/db/schema";
import { CLIP_MAX, CLIP_MIN, safeCaptionY, captionPresets, defaultAudioFx, defaultHook, defaultLayout, fmtTime, type Rect, type Segment } from "@/lib/types";
import { cfg } from "./config";
import { abs, assertSpace, newRel, removeRel, saveStream, SizeLimitError } from "./storage";
import { ffprobe } from "./ffmpeg";
import { analyzeAudio, analyzeVisual } from "./ai/media-analysis";
import { transcribeFile } from "./ai/transcribe";
import { selectClips } from "./ai/selector";
import { makeHooks } from "./ai/hooks";
import { buildCaptions } from "./ai/subtitles";
import { assertClipRange, renderClip } from "./render";
import { compileVideos, convertMedia, processAudio, scriptToVideo } from "./media-tools";
import { getAsset, registerAsset } from "./assets";
import type { JobCtx } from "./jobs";
import { UrlError, detectPlatform, extOf, parseUrl, safeFilename, safeRequest, AUDIO_EXT, VIDEO_EXT } from "./security";
import { isMediaContentType } from "./connectors";

export async function getProject(id: string) {
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  return p ?? null;
}

export async function getSource(projectId: string) {
  const p = await getProject(projectId);
  if (!p?.sourceAssetId) return null;
  const a = await getAsset(p.sourceAssetId);
  if (!a) return null;
  return { project: p, asset: a, file: abs(a.relPath) };
}

export async function getSegments(projectId: string): Promise<Segment[]> {
  const [t] = await db.select().from(transcripts).where(eq(transcripts.projectId, projectId));
  return t?.segments ?? [];
}

export async function saveTranscript(projectId: string, segments: Segment[], engine: string, language: string) {
  await db
    .insert(transcripts)
    .values({ projectId, segments, engine, language })
    .onConflictDoUpdate({ target: transcripts.projectId, set: { segments, engine, language, updatedAt: new Date() } });
}

async function upsertAnalysis(projectId: string, patch: Partial<typeof analyses.$inferInsert>) {
  await db
    .insert(analyses)
    .values({ projectId, ...patch })
    .onConflictDoUpdate({ target: analyses.projectId, set: { ...patch, updatedAt: new Date() } });
}

/* ------------------------------ transcrição ------------------------------ */
export async function transcribeJob(ctx: JobCtx, projectId: string, language: string) {
  const src = await getSource(projectId);
  if (!src) throw new Error("Projeto sem vídeo de origem.");
  const segs = await transcribeFile(src.file, language, src.asset.durationSec ?? 0, ctx.signal, (p, m) => void ctx.progress(p, m));
  if (!segs.length) throw new Error("Nenhuma fala foi reconhecida no áudio.");
  await saveTranscript(projectId, segs, "whisper-local", language);
  return { segments: segs.length };
}

/* ------------------------------ análise + seleção ------------------------------ */
export type AnalyzeOpts = { transcribe: boolean; count: number | "auto"; kind?: string; language?: string; reuse?: boolean };

export async function analyzeJob(ctx: JobCtx, projectId: string, opts: AnalyzeOpts) {
  const src = await getSource(projectId);
  if (!src) throw new Error("Projeto sem vídeo de origem.");
  const duration = src.asset.durationSec ?? 0;
  if (duration < CLIP_MIN + 1) throw new Error("O vídeo tem menos de 61 s; cortes individuais exigem 60–90 s.");
  const warnings: string[] = [];
  const kind = opts.kind || src.project.kind;
  const [prev] = await db.select().from(analyses).where(eq(analyses.projectId, projectId));
  await upsertAnalysis(projectId, { status: "running" });

  let audio = opts.reuse ? prev?.audio ?? null : null;
  if (!audio) {
    await ctx.progress(0.01, "Analisando áudio (100% da duração)");
    audio = await analyzeAudio(src.file, duration, src.asset.hasAudio ?? true, ctx.signal, (p) => void ctx.progress(0.02 + p * 0.18, "Analisando áudio"));
    await upsertAnalysis(projectId, { audio });
  }
  let visual = opts.reuse ? prev?.visual ?? null : null;
  if (!visual) {
    await ctx.progress(0.2, "Analisando imagem: mudanças de cena e movimento");
    visual = await analyzeVisual(src.file, duration, ctx.signal, (p) => void ctx.progress(0.2 + p * 0.3, "Analisando imagem"));
    await upsertAnalysis(projectId, { visual });
  }

  let segments = await getSegments(projectId);
  if (!segments.length && opts.transcribe) {
    await ctx.progress(0.5, "Transcrevendo com Whisper local");
    try {
      segments = await transcribeFile(src.file, opts.language || cfg.whisperLang, duration, ctx.signal, (p, m) => void ctx.progress(0.5 + p * 0.33, m));
      await saveTranscript(projectId, segments, "whisper-local", opts.language || cfg.whisperLang);
    } catch (e) {
      if (ctx.signal.aborted) throw e;
      warnings.push((e instanceof Error ? e.message : "Transcrição falhou") + " — seleção feita apenas com áudio e imagem.");
    }
  } else if (!segments.length) warnings.push("Sem transcrição: seleção baseada em áudio e imagem. Hooks e legendas ficam limitados.");

  await ctx.progress(0.85, "Selecionando melhores momentos (comparação global)");
  const sel = selectClips({ duration, segments, energy: audio.energy, motion: visual.motion, cuts: visual.cuts, kind, count: opts.count });
  if (!sel.clips.length) {
    await upsertAnalysis(projectId, { status: "done", coverage: coverageOf(duration, audio.energy.length, visual, segments.length, sel.stats) });
    return { clips: 0, warnings: [...warnings, sel.note || "Nenhum momento elegível."] };
  }

  await db.delete(clips).where(and(eq(clips.projectId, projectId), eq(clips.status, "candidate"), eq(clips.type, "clip")));
  const settings = src.project.settings as { cam?: Rect | null; game?: Rect | null };
  let i = 0;
  for (const c of sel.clips) {
    i++;
    await ctx.progress(0.88 + (i / sel.clips.length) * 0.1, `Refinando e preparando corte ${i}/${sel.clips.length}`);
    assertClipRange(c.start, c.end, duration);
    let visualEvent = c.visualEvent;
    try {
      // amostragem adaptativa: reanálise a 8 fps SOMENTE na janela escolhida
      const fine = await analyzeVisual(src.file, duration, ctx.signal, undefined, { start: c.start, end: c.end, fps: 8 });
      let mi = 0;
      fine.motion.forEach((v, k) => { if (v > fine.motion[mi]) mi = k; });
      visualEvent = `${fine.cuts.length} mudança(s) de cena (refinamento adaptativo a 8 fps na janela); maior variação visual em ${fmtTime(c.start + mi)}. Medido por diferença temporal de quadros — sem modelo de visão semântico.`;
    } catch (e) {
      if (ctx.signal.aborted) throw e;
    }
    const hooks = await makeHooks({ text: c.spokenText, tags: c.tags, durationSec: c.end - c.start, kind, peakSec: c.peakT });
    const style = { ...captionPresets[kind === "podcast" || kind === "educational" ? "podcast" : "viral"] };
    const layout = defaultLayout();
    if (settings.cam) {
      layout.cam = settings.cam;
      layout.game = settings.game ?? null;
      layout.mode = kind === "game" ? "A" : "fit";
      const sy = safeCaptionY(layout.mode);
      if (sy) style.yPct = sy;
    }
    const hook = { ...defaultHook(), text: hooks.find((h) => h.recommended)?.text ?? hooks[0]?.text ?? "" };
    await db.insert(clips).values({
      projectId, type: "clip", title: `Corte ${i} — ${c.topic}`.slice(0, 120), startSec: c.start, endSec: c.end, score: c.score, scoreBreakdown: c.breakdown,
      justification: c.justification, description: c.description, topic: c.topic, context: c.context, visualEvent, spokenText: c.spokenText, editorialPotential: c.editorialPotential,
      hookOptions: hooks, hook: { ...hook, enabled: hooks.length > 0 }, captionStyle: style, captions: segments.length ? buildCaptions(segments, c.start, c.end, style) : [],
      layout, audioFx: defaultAudioFx(), elements: [], extra: { tags: c.tags, peakT: c.peakT },
    });
  }
  await upsertAnalysis(projectId, { status: "done", coverage: coverageOf(duration, audio.energy.length, visual, segments.length, sel.stats) });
  await db.update(projects).set({ status: "analyzed", updatedAt: new Date() }).where(eq(projects.id, projectId));
  return { clips: sel.clips.length, warnings: sel.note ? [...warnings, sel.note] : warnings };
}

function coverageOf(duration: number, audioSecs: number, visual: { motion: number[]; sampleFps: number; cuts: number[] }, segCount: number, stats: unknown) {
  return {
    videoSeconds: Math.round(duration),
    audioSecondsAnalyzed: audioSecs,
    visualSamples: Math.round(visual.motion.length * visual.sampleFps),
    visualSampleFps: visual.sampleFps,
    sceneCuts: visual.cuts.length,
    transcriptSegments: segCount,
    selection: stats,
    coveragePct: duration ? Math.min(100, Math.round((audioSecs / Math.ceil(duration)) * 100)) : 0,
  };
}

/* ------------------------------ render ------------------------------ */
export async function renderJob(ctx: JobCtx, clipId: string) {
  const [clip] = await db.select().from(clips).where(eq(clips.id, clipId));
  if (!clip) throw new Error("Corte não encontrado.");
  const src = await getSource(clip.projectId);
  if (!src) throw new Error("Vídeo de origem não encontrado.");
  assertClipRange(clip.startSec, clip.endSec, src.asset.durationSec ?? undefined);
  await assertSpace(300 * 1024 * 1024);
  await db.update(clips).set({ status: "rendering" }).where(eq(clips.id, clipId));
  try {
    const imageAssets: Record<string, string> = {};
    for (const el of clip.elements) if (el.type === "image" && el.assetId) {
      const a = await getAsset(el.assetId);
      if (a) imageAssets[el.assetId] = abs(a.relPath);
    }
    let musicAbs: string | null = null;
    if (clip.audioFx.musicAssetId) {
      const m = await getAsset(clip.audioFx.musicAssetId);
      if (m) musicAbs = abs(m.relPath);
    }
    const rel = newRel(`projects/${clip.projectId}`, "mp4");
    const r = await renderClip({
      srcAbs: src.file,
      src: { width: src.asset.width ?? 1920, height: src.asset.height ?? 1080, hasAudio: src.asset.hasAudio ?? true, duration: src.asset.durationSec ?? 0 },
      clip, outAbs: abs(rel), imageAssets, musicAbs, signal: ctx.signal, onProgress: (p) => void ctx.progress(p, "Renderizando"),
    });
    const asset = await registerAsset({ projectId: clip.projectId, kind: "clip", filename: `${safeFilename(clip.title || "corte")}.mp4`, relPath: rel, meta: { clipId } });
    if (clip.outputAssetId) {
      const old = await getAsset(clip.outputAssetId);
      if (old) { await removeRel(old.relPath); await db.delete(assets).where(eq(assets.id, old.id)); }
    }
    await db.update(clips).set({ status: "rendered", outputAssetId: asset.id, renderedDuration: r.duration, extra: { ...clip.extra, layoutWarning: r.warning ?? null, renderedLayout: r.layoutMode }, updatedAt: new Date() }).where(eq(clips.id, clipId));
    return { assetId: asset.id, duration: r.duration, warning: r.warning };
  } catch (e) {
    await db.update(clips).set({ status: ctx.signal.aborted ? "candidate" : "failed", extra: { ...clip.extra, error: e instanceof Error ? e.message : String(e) } }).where(eq(clips.id, clipId));
    throw e;
  }
}

/* ------------------------------ importação por URL ------------------------------ */
export async function importUrlJob(ctx: JobCtx, p: { projectId: string | null; url: string; purpose: "source" | "download" }) {
  const u = parseUrl(p.url);
  const platform = detectPlatform(u);
  if (!platform.direct) throw new UrlError(`${platform.name} não permite importação direta autorizada por link. Use o upload manual do arquivo (com os devidos direitos).`);
  await assertSpace(cfg.maxImportBytes);
  const { res, url } = await safeRequest(p.url, { signal: ctx.signal, timeoutMs: 20000 });
  const status = res.statusCode || 0;
  if (status >= 400) { res.resume(); throw new UrlError(`Fonte indisponível (HTTP ${status}).`); }
  const ct = String(res.headers["content-type"] || "").split(";")[0].trim();
  const name = safeFilename(decodeURIComponent(url.pathname.split("/").pop() || "video.mp4"));
  let ext = extOf(name);
  if (!ct || !isMediaContentType(ct)) {
    if (![...VIDEO_EXT, ...AUDIO_EXT].includes(ext)) { res.resume(); throw new UrlError(`A URL não aponta para um arquivo de mídia (recebido: ${ct || "desconhecido"}).`); }
  }
  if (![...VIDEO_EXT, ...AUDIO_EXT].includes(ext)) ext = ct.startsWith("audio/") ? "mp3" : ct.includes("webm") ? "webm" : "mp4";
  const total = Number(res.headers["content-length"] || 0);
  if (total && total > cfg.maxImportBytes) { res.destroy(); throw new UrlError(`Arquivo de ${(total / 1048576).toFixed(0)} MB excede o limite de ${(cfg.maxImportBytes / 1048576).toFixed(0)} MB.`); }
  const onAbort = () => res.destroy();
  ctx.signal.addEventListener("abort", onAbort, { once: true });
  const rel = newRel(p.projectId ? `projects/${p.projectId}` : "downloads", ext);
  try {
    await saveStream(rel, res, cfg.maxImportBytes, ctx.signal, (got) => { if (total) void ctx.progress((got / total) * 0.9, `Baixando ${(got / 1048576).toFixed(1)} MB`); });
    const info = await ffprobe(abs(rel)).catch(() => null);
    if (!info || (!info.hasVideo && !info.hasAudio)) throw new Error("O arquivo baixado não é uma mídia válida.");
    if (info.duration > cfg.maxDurationSec) throw new Error(`Duração de ${Math.round(info.duration / 60)} min excede o limite de ${Math.round(cfg.maxDurationSec / 60)} min.`);
    const asset = await registerAsset({ projectId: p.projectId, kind: p.purpose === "source" ? "source" : "download", filename: name.includes(".") ? name : `${name}.${ext}`, relPath: rel, meta: { origin: "url", sourceUrl: p.url, platform: platform.id } });
    if (p.purpose === "source" && p.projectId) {
      if (!info.hasVideo) throw new Error("A importação de projeto exige um arquivo com vídeo.");
      await db.update(projects).set({ sourceAssetId: asset.id, sourceType: "url", sourceUrl: p.url, status: "ready", updatedAt: new Date() }).where(eq(projects.id, p.projectId));
    }
    return { assetId: asset.id };
  } catch (e) {
    await removeRel(rel);
    if (e instanceof SizeLimitError) throw new UrlError(e.message);
    throw e;
  } finally {
    ctx.signal.removeEventListener("abort", onAbort);
  }
}

/* ------------------------------ ferramentas de mídia ------------------------------ */
export async function convertJob(ctx: JobCtx, assetId: string, o: { format: "mp4" | "webm" | "mp3" | "wav"; height?: number }) {
  const a = await getAsset(assetId);
  if (!a) throw new Error("Arquivo não encontrado.");
  await assertSpace(((a.sizeBytes || 0) * 1.5) + 50 * 1024 * 1024);
  const rel = newRel(a.projectId ? `projects/${a.projectId}` : "downloads", o.format);
  try {
    await convertMedia(abs(a.relPath), abs(rel), { ...o, signal: ctx.signal, onProgress: (p) => void ctx.progress(p, "Convertendo") });
  } catch (e) { await removeRel(rel); throw e; }
  const base = a.filename.replace(/\.[a-z0-9]+$/i, "");
  const na = await registerAsset({ projectId: a.projectId, kind: o.format === "mp3" || o.format === "wav" ? "audio" : "download", filename: `${base}${o.height ? `-${o.height}p` : ""}.${o.format}`, relPath: rel, meta: { derivedFrom: a.id } });
  return { assetId: na.id };
}

export async function audioToolJob(ctx: JobCtx, assetId: string, o: { denoise: boolean; normalize: boolean; voice: boolean; removeSilence: boolean }) {
  const a = await getAsset(assetId);
  if (!a) throw new Error("Arquivo não encontrado.");
  const rel = newRel(a.projectId ? `projects/${a.projectId}` : "downloads", "mp3");
  try {
    await processAudio(abs(a.relPath), abs(rel), { ...o, signal: ctx.signal, onProgress: (p) => void ctx.progress(p, "Processando áudio") });
  } catch (e) { await removeRel(rel); throw e; }
  const na = await registerAsset({ projectId: a.projectId, kind: "audio", filename: `${a.filename.replace(/\.[a-z0-9]+$/i, "")}-audio-melhorado.mp3`, relPath: rel, meta: { derivedFrom: a.id, ...o } });
  return { assetId: na.id };
}

export async function compileJob(ctx: JobCtx, projectId: string, o: { clipIds: string[]; transition: "fade" | "zoomin" | "slideleft" | "none"; title: string }) {
  const rows = await db.select().from(clips).where(and(eq(clips.projectId, projectId), inArray(clips.id, o.clipIds)));
  if (rows.length < 2) throw new Error("Selecione ao menos 2 trechos.");
  const ordered = o.clipIds.map((id) => rows.find((r) => r.id === id)!).filter(Boolean);
  const files: string[] = [];
  for (let i = 0; i < ordered.length; i++) {
    let c = ordered[i];
    if (c.type === "compilation") throw new Error("Não é possível compilar uma compilação.");
    if (c.status !== "rendered" || !c.outputAssetId) {
      await ctx.progress((i / ordered.length) * 0.6, `Renderizando trecho ${i + 1}/${ordered.length}`);
      await renderJob({ ...ctx, progress: async () => {} }, c.id);
      [c] = await db.select().from(clips).where(eq(clips.id, c.id));
    }
    const a = c.outputAssetId ? await getAsset(c.outputAssetId) : null;
    if (!a) throw new Error("Arquivo de um trecho não encontrado.");
    files.push(abs(a.relPath));
  }
  const rel = newRel(`projects/${projectId}`, "mp4");
  let info;
  try {
    info = await compileVideos(files, abs(rel), { transition: o.transition, signal: ctx.signal, onProgress: (p) => void ctx.progress(0.6 + p * 0.4, "Compilando") });
  } catch (e) { await removeRel(rel); throw e; }
  const asset = await registerAsset({ projectId, kind: "compilation", filename: `${safeFilename(o.title || "compilacao")}.mp4`, relPath: rel, meta: { clipIds: o.clipIds, transition: o.transition } });
  const [row] = await db.insert(clips).values({
    projectId, type: "compilation", title: o.title || "Compilação", startSec: 0, endSec: info.duration, score: 0, hook: { ...defaultHook(), enabled: false }, captionStyle: captionPresets.viral, layout: defaultLayout(), audioFx: defaultAudioFx(),
    status: "rendered", outputAssetId: asset.id, renderedDuration: info.duration, description: `Compilação de ${ordered.length} trechos (duração livre, não é corte individual).`, extra: { clipIds: o.clipIds },
  }).returning({ id: clips.id });
  return { assetId: asset.id, clipId: row.id, duration: info.duration };
}

export async function scriptVideoJob(ctx: JobCtx, projectId: string | null, o: { script: string; aspect: "9:16" | "16:9" | "1:1"; secondsPerSlide: number; palette: number }) {
  const rel = newRel(projectId ? `projects/${projectId}` : "downloads", "mp4");
  try {
    await scriptToVideo(o.script, abs(rel), { ...o, signal: ctx.signal, onProgress: (p) => void ctx.progress(p, "Gerando vídeo") });
  } catch (e) { await removeRel(rel); throw e; }
  const a = await registerAsset({ projectId, kind: "export", filename: "video-de-roteiro.mp4", relPath: rel, meta: { generated: "script" } });
  return { assetId: a.id };
}

export async function deleteAssetFiles(rows: { relPath: string }[]) {
  for (const r of rows) await fsp.rm(abs(r.relPath), { force: true }).catch(() => {});
}

export { path };
export const CLIP_LIMITS = { CLIP_MIN, CLIP_MAX };
