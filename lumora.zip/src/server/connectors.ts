import { detectPlatform, extOf, parseUrl, safeRequest, VIDEO_EXT, AUDIO_EXT, UrlError, type Platform } from "./security";

/**
 * Conectores de origem. Política:
 *  - URLs diretas de mídia (mp4/webm/mov/mkv/mp3...) são importadas por download HTTP seguro (anti-SSRF).
 *  - Plataformas (YouTube, TikTok, Instagram, Facebook, Twitch, Vimeo, X): NÃO contornamos proteções,
 *    DRM, login ou termos de uso. Quando há oEmbed oficial, mostramos título/miniatura; o arquivo deve ser
 *    enviado manualmente (upload) ou obtido por API/exportação oficial com permissão do titular.
 */
export type ProbeInfo = {
  url: string;
  platform: Platform;
  supported: boolean;
  status: "ok" | "platform-restricted" | "not-media" | "unavailable";
  reason: string;
  contentType?: string;
  size?: number | null;
  filename?: string;
  title?: string;
  thumbnail?: string;
  author?: string;
  official?: string;
};

const OEMBED: Record<string, (u: string) => string> = {
  youtube: (u) => `https://www.youtube.com/oembed?format=json&url=${encodeURIComponent(u)}`,
  vimeo: (u) => `https://vimeo.com/api/oembed.json?url=${encodeURIComponent(u)}`,
  tiktok: (u) => `https://www.tiktok.com/oembed?url=${encodeURIComponent(u)}`,
  x: (u) => `https://publish.twitter.com/oembed?url=${encodeURIComponent(u)}`,
};

const OFFICIAL: Record<string, string> = {
  youtube: "YouTube Data API / download pelo YouTube Studio (para seus próprios vídeos).",
  tiktok: "Content Posting/Display API do TikTok ou exportação do seu próprio conteúdo no app.",
  instagram: "Instagram Graph API (contas profissionais autorizadas) ou exportação pelo app.",
  facebook: "Graph API (páginas autorizadas) ou download pelo Meta Business Suite.",
  twitch: "Download de VODs próprios pelo Twitch Creator Dashboard.",
  vimeo: "Vimeo API (arquivos com download habilitado pelo titular).",
  x: "X API (com permissão) ou arquivo de dados exportado da conta.",
};

export function isMediaContentType(ct: string): boolean {
  return /^(video|audio)\//i.test(ct) || /octet-stream/i.test(ct);
}

export async function probeUrl(raw: string): Promise<ProbeInfo> {
  const u = parseUrl(raw);
  const platform = detectPlatform(u);
  if (!platform.direct) {
    const info: ProbeInfo = {
      url: raw, platform, supported: false, status: "platform-restricted",
      reason: `${platform.name} não oferece um método de importação direto e autorizado para links públicos. Não contornamos DRM, login ou proteções. Baixe o arquivo por um meio oficial/autorizado (você precisa ter os direitos) e envie por Upload.`,
      official: OFFICIAL[platform.id],
    };
    const o = OEMBED[platform.id];
    if (o) {
      try {
        const r = await fetch(o(raw), { signal: AbortSignal.timeout(6000) });
        if (r.ok) {
          const j = (await r.json()) as { title?: string; thumbnail_url?: string; author_name?: string };
          info.title = j.title;
          info.thumbnail = j.thumbnail_url;
          info.author = j.author_name;
        }
      } catch {}
    }
    return info;
  }
  try {
    let r = await safeRequest(raw, { method: "HEAD", timeoutMs: 10000 }).catch(() => null);
    if (!r || (r.res.statusCode || 0) >= 400) {
      r?.res.resume();
      r = await safeRequest(raw, { method: "GET", headers: { range: "bytes=0-0" }, timeoutMs: 10000 });
    }
    const status = r.res.statusCode || 0;
    const ct = String(r.res.headers["content-type"] || "").split(";")[0].trim();
    const cl = r.res.headers["content-range"] ? Number(String(r.res.headers["content-range"]).split("/")[1]) : Number(r.res.headers["content-length"] || 0);
    r.res.destroy();
    const filename = decodeURIComponent(r.url.pathname.split("/").pop() || "arquivo");
    const ext = extOf(filename);
    if (status >= 400) return { url: raw, platform, supported: false, status: "unavailable", reason: `A fonte respondeu HTTP ${status} (indisponível ou acesso restrito).` };
    const looksMedia = isMediaContentType(ct) && (ct !== "application/octet-stream" || [...VIDEO_EXT, ...AUDIO_EXT].includes(ext));
    if (!looksMedia && ![...VIDEO_EXT, ...AUDIO_EXT].includes(ext)) {
      return { url: raw, platform, supported: false, status: "not-media", reason: `A URL retorna "${ct || "conteúdo desconhecido"}", não um arquivo de mídia direto (mp4, webm, mov, mkv, mp3...).`, contentType: ct };
    }
    return { url: r.url.toString(), platform, supported: true, status: "ok", reason: "Arquivo de mídia direto disponível para importação.", contentType: ct, size: cl || null, filename };
  } catch (e) {
    const msg = e instanceof UrlError ? e.message : "Link indisponível ou inacessível.";
    return { url: raw, platform, supported: false, status: "unavailable", reason: msg };
  }
}
