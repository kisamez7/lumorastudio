import { ToolRouter } from "@/components/tools";

export default async function ToolPage({ params }: { params: Promise<{ tool: string }> }) {
  const { tool } = await params;
  return <ToolRouter tool={tool} />;
}
