import Link from "next/link";
import { ArrowRight, Scissors, Brain, Clapperboard, Download, Send, Sparkles } from "lucide-react";

const MODULES = [
  { icon: Scissors, title: "Criar", color: "from-violet-500/25", desc: "Cortes de 60–90 s escolhidos pela IA em qualquer ponto do vídeo, com hooks, legendas e enquadramento vertical.", links: [["Criador de cortes", "/t/clips"], ["Game Clipping", "/t/game"], ["Compilador", "/t/compile"]] },
  { icon: Brain, title: "Entender", color: "from-blue-500/25", desc: "Transcrição Whisper local, resumos, busca de momentos, chat com o vídeo, mapas mentais e anotações.", links: [["Resumo", "/t/summary"], ["Busca de momentos", "/t/moments"], ["Chat com vídeo", "/t/chat"]] },
  { icon: Clapperboard, title: "Editar", color: "from-emerald-500/25", desc: "Editor com timeline, hooks e legendas editáveis, reenquadramento, áudio, miniaturas e B-roll.", links: [["Editor", "/t/editor"], ["Legendas", "/t/captions"], ["Miniaturas", "/t/thumbnails"]] },
  { icon: Download, title: "Baixar", color: "from-sky-500/25", desc: "Baixe mídias diretas autorizadas, converta formatos e extraia áudio em MP3 — sem marca d’água, sem ampliar resoluções.", links: [["Downloader", "/t/downloader"], ["Conversor", "/t/converter"], ["Áudio MP3", "/t/audio-extract"]] },
  { icon: Send, title: "Publicar", color: "from-fuchsia-500/25", desc: "Títulos, descrições por rede, hashtags e calendário. Exportação para publicação manual.", links: [["Títulos", "/t/titles"], ["Calendário", "/t/calendar"], ["Preparação", "/t/publish"]] },
];

export default function Home() {
  return (
    <div>
      <section className="rise relative overflow-hidden rounded-3xl border border-white/[0.08] px-6 py-14 sm:px-12 sm:py-20">
        <div className="pointer-events-none absolute -left-24 -top-24 size-96 rounded-full bg-violet-600/25 blur-[100px]" />
        <div className="pointer-events-none absolute -bottom-32 right-0 size-96 rounded-full bg-emerald-500/15 blur-[110px]" />
        <div className="pointer-events-none absolute right-1/4 top-0 size-72 rounded-full bg-blue-500/20 blur-[100px]" />
        <div className="relative max-w-3xl">
          <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-xs text-zinc-300"><Sparkles className="size-3.5 text-violet-300" />Código aberto · processamento local · sem marca d’água</span>
          <h1 className="text-4xl font-semibold leading-[1.08] tracking-tight sm:text-6xl">Transforme qualquer vídeo em <span className="grad-text">conteúdo extraordinário</span> com inteligência artificial.</h1>
          <p className="mt-6 max-w-2xl text-base leading-relaxed text-zinc-400 sm:text-lg">Encontre os melhores momentos, crie cortes profissionais, edite vídeos, gere legendas e prepare seu conteúdo para as redes sociais em um único lugar.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/new" className="grad-bg glow inline-flex items-center gap-2 rounded-xl px-6 py-3.5 font-medium text-white transition hover:brightness-110 active:scale-[0.98]">Começar novo projeto <ArrowRight className="size-4" /></Link>
            <Link href="/dashboard" className="inline-flex items-center rounded-xl border border-white/10 bg-white/[0.04] px-6 py-3.5 text-zinc-200 transition hover:bg-white/10">Abrir dashboard</Link>
          </div>
        </div>
      </section>

      <section className="mt-10 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {MODULES.map((m, i) => (
          <div key={m.title} style={{ animationDelay: `${i * 60}ms` }} className="glass rise group relative overflow-hidden rounded-2xl p-6 transition hover:border-white/20">
            <div className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${m.color} to-transparent opacity-0 transition group-hover:opacity-100`} />
            <div className="relative">
              <m.icon className="mb-4 size-7 text-violet-300" />
              <h2 className="text-lg font-semibold">{m.title}</h2>
              <p className="mt-1.5 min-h-[72px] text-sm leading-relaxed text-zinc-400">{m.desc}</p>
              <div className="mt-4 flex flex-wrap gap-2">{m.links.map(([l, h]) => <Link key={h} href={h} className="rounded-lg bg-white/[0.06] px-3 py-1.5 text-xs text-zinc-200 transition hover:bg-white/15">{l}</Link>)}</div>
            </div>
          </div>
        ))}
        <div className="glass rise rounded-2xl p-6">
          <h2 className="text-lg font-semibold">Como funciona a seleção</h2>
          <ul className="mt-3 space-y-2 text-sm text-zinc-400">
            <li>• Áudio e imagem analisados em 100% da duração.</li>
            <li>• Janelas candidatas comparadas globalmente — nunca fatiadas em sequência.</li>
            <li>• Cortes individuais sempre entre 60 e 90 s (validado no backend e após o render).</li>
            <li>• Notas são estimativas editoriais, não garantia de viralização.</li>
          </ul>
        </div>
      </section>
    </div>
  );
}
