"use client";
import { Files } from "lucide-react";
import { PageHeader } from "@/components/ui";
import { AssetList } from "@/components/AssetList";

export default function FilesPage() {
  return (
    <div>
      <PageHeader title="Arquivos" subtitle="Originais, cortes, compilações, áudios e downloads armazenados. Baixe direto para computador ou celular." icon={<Files className="size-5" />} />
      <AssetList />
    </div>
  );
}
