"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Copy, History as HistoryIcon, Trash2 } from "lucide-react";
import { api, del, post } from "@/lib/client";
import type { JobInfo } from "@/lib/types";
import { Badge, Btn, Card, Empty, PageHeader } from "@/components/ui";
import { useProject } from "@/components/ProjectContext";

export default function History() {
  const { projects, reload, setCurrent, currentId } = useProject();
  const [jobs, setJobs] = useState<JobInfo[]>([]);
  const [busy, setBusy] = useState<string | null>(null);
  useEffect(() => { api<JobInfo[]>("/api/jobs").then(setJobs).catch(() => {}); }, [projects]);
  return (
    <div>
      <PageHeader title="Histórico" subtitle="Reabra, duplique ou exclua projetos. Exclusão remove também os arquivos do armazenamento." icon={<HistoryIcon className="size-5" />} />
      {!projects.length ? <Empty title="Sem histórico ainda" /> : (
        <Card className="overflow-x-auto p-0">
          <table className="w-full min-w-[640px] text-sm">
            <thead className="text-left text-xs uppercase tracking-wider text-zinc-500"><tr><th className="p-4">Projeto</th><th>Tipo</th><th>Cortes</th><th>Atualizado</th><th /></tr></thead>
            <tbody>
              {projects.map((p) => (
                <tr key={p.id} className="border-t border-white/[0.06]">
                  <td className="p-4 font-medium">{p.name}{currentId === p.id && <Badge tone="violet"> ativo</Badge>}</td>
                  <td className="text-zinc-400">{p.kind}</td><td className="text-zinc-400">{p.clipCount}</td><td className="text-zinc-500">{new Date(p.updatedAt).toLocaleString("pt-BR")}</td>
                  <td className="space-x-2 whitespace-nowrap p-4 text-right">
                    <Link href="/t/clips" onClick={() => setCurrent(p.id)}><Btn size="sm">Reabrir</Btn></Link>
                    <Btn size="sm" loading={busy === p.id} onClick={async () => { setBusy(p.id); await post(`/api/projects/${p.id}/duplicate`); await reload(); setBusy(null); }}><Copy className="size-3.5" />Duplicar</Btn>
                    <Btn size="sm" variant="danger" onClick={async () => { if (!confirm(`Excluir “${p.name}” e todos os arquivos?`)) return; await del(`/api/projects/${p.id}`); if (currentId === p.id) setCurrent(null); await reload(); }}><Trash2 className="size-3.5" /></Btn>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}
      <h2 className="mb-3 mt-8 font-medium">Tarefas recentes</h2>
      <Card>
        {!jobs.length ? <p className="text-sm text-zinc-500">Nenhuma tarefa.</p> : (
          <ul className="divide-y divide-white/[0.06] text-sm">{jobs.map((j) => (
            <li key={j.id} className="flex flex-wrap items-center justify-between gap-2 py-2.5"><span>{j.type} <span className="text-xs text-zinc-500">{new Date(j.createdAt).toLocaleString("pt-BR")}</span></span><span className="flex items-center gap-2">{j.error && <span className="max-w-xs truncate text-xs text-rose-300" title={j.error}>{j.error}</span>}<Badge tone={j.status === "done" ? "green" : j.status === "failed" ? "rose" : "zinc"}>{j.status}</Badge></span></li>
          ))}</ul>
        )}
      </Card>
    </div>
  );
}
