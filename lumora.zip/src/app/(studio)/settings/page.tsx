"use client";
import { useEffect, useState } from "react";
import { CheckCircle2, MinusCircle, Settings, XCircle } from "lucide-react";
import { api, fmtBytes } from "@/lib/client";
import { Card, PageHeader, Progress } from "@/components/ui";

type Sys = {
  mode: string; ffmpeg: string | null; whisper: { engine: string; model: string; language: string };
  ollama: { configured: boolean; reachable: boolean; models: string[]; model: string }; cvService: { configured: boolean; reachable: boolean };
  storage: { driver: string; used: number; free: number | null; quota: number }; limits: { maxUploadMB: number; maxImportMB: number; maxVideoMinutes: number; concurrency: number }; auth: boolean;
};

const Row = ({ ok, label, detail }: { ok: boolean | null; label: string; detail: string }) => (
  <li className="flex items-start gap-3 py-3">
    {ok === null ? <MinusCircle className="mt-0.5 size-5 shrink-0 text-zinc-500" /> : ok ? <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-emerald-400" /> : <XCircle className="mt-0.5 size-5 shrink-0 text-amber-400" />}
    <div><p className="text-sm font-medium">{label}</p><p className="text-xs text-zinc-500">{detail}</p></div>
  </li>
);

export default function SettingsPage() {
  const [s, setS] = useState<Sys | null>(null);
  useEffect(() => { api<Sys>("/api/system").then(setS).catch(() => {}); }, []);
  if (!s) return <div className="shimmer h-60 rounded-2xl" />;
  const pct = Math.min(100, (s.storage.used / s.storage.quota) * 100);
  return (
    <div>
      <PageHeader title="Configurações e capacidades" subtitle="Estado real de cada componente neste servidor. Recursos indisponíveis são informados — nada é simulado." icon={<Settings className="size-5" />} />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <h2 className="mb-1 font-medium">Motores de processamento</h2>
          <ul className="divide-y divide-white/[0.06]">
            <Row ok={!!s.ffmpeg} label="FFmpeg / FFprobe" detail={s.ffmpeg ?? "não encontrado — instale ou defina FFMPEG_PATH"} />
            <Row ok label="Transcrição — Whisper local" detail={`${s.whisper.engine} · modelo ${s.whisper.model} · idioma ${s.whisper.language}. Baixa o modelo na primeira execução.`} />
            <Row ok label="Análise de áudio e imagem" detail="RMS por segundo + diferença temporal de quadros sobre 100% do vídeo (FFmpeg)." />
            <Row ok={s.ollama.reachable} label="LLM local (Ollama) — opcional" detail={s.ollama.configured ? (s.ollama.reachable ? `ativo · modelos: ${s.ollama.models.join(", ") || "nenhum"}` : "OLLAMA_URL definido, mas inacessível") : "não configurado → resumos/chat/hooks usam heurísticas extrativas; Tradução indisponível"} />
            <Row ok={s.cvService.reachable} label="Serviço de Computer Vision (OpenCV) — opcional" detail={s.cvService.configured ? (s.cvService.reachable ? "ativo" : "CV_SERVICE_URL definido, mas inacessível") : "não configurado → defina a webcam manualmente no Reenquadramento"} />
          </ul>
        </Card>
        <div className="space-y-6">
          <Card>
            <h2 className="mb-3 font-medium">Armazenamento ({s.storage.driver})</h2>
            <Progress value={pct} />
            <p className="mt-2 text-xs text-zinc-500">{fmtBytes(s.storage.used)} usados de {fmtBytes(s.storage.quota)} (cota) · disco livre: {s.storage.free !== null ? fmtBytes(s.storage.free) : "n/d"}</p>
          </Card>
          <Card>
            <h2 className="mb-3 font-medium">Limites e modo</h2>
            <dl className="grid grid-cols-2 gap-3 text-sm">
              {[["Modo", s.mode === "hosted" ? "Hospedado" : "Local"], ["Upload máx.", `${s.limits.maxUploadMB} MB`], ["Importação máx.", `${s.limits.maxImportMB} MB`], ["Duração máx.", `${s.limits.maxVideoMinutes} min`], ["Tarefas simultâneas", String(s.limits.concurrency)], ["Acesso protegido", s.auth ? "Sim (código)" : "Não (anônimo local)"]].map(([k, v]) => <div key={k}><dt className="text-[11px] uppercase tracking-wider text-zinc-500">{k}</dt><dd>{v}</dd></div>)}
            </dl>
            <p className="mt-4 text-xs leading-relaxed text-zinc-500">Software gratuito não significa hospedagem gratuita: processamento de vídeo consome CPU, disco e banda. Local = seu hardware. Hospedado = custos de VPS/volume/banco. Veja o README.</p>
          </Card>
        </div>
      </div>
    </div>
  );
}
