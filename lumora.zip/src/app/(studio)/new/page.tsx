"use client";
import Link from "next/link";
import { useState } from "react";
import { Plus, Scissors } from "lucide-react";
import { post } from "@/lib/client";
import { Btn, Card, Field, inputCls, Notice, PageHeader } from "@/components/ui";
import { useProject } from "@/components/ProjectContext";
import { ImportPanel, SourceCard } from "@/components/ImportPanel";

const KINDS = [["general", "Geral"], ["game", "Gameplay / Live"], ["podcast", "Podcast / Entrevista"], ["educational", "Educativo / Aula"]];

export default function NewProject() {
  const { project, currentId, setCurrent, reload } = useProject();
  const [name, setName] = useState("");
  const [kind, setKind] = useState("general");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const create = async () => {
    setBusy(true); setErr("");
    try { const p = await post<{ id: string }>("/api/projects", { name, kind }); setCurrent(p.id); setName(""); await reload(); } catch (e) { setErr(e instanceof Error ? e.message : "Erro"); }
    setBusy(false);
  };
  return (
    <div>
      <PageHeader title="Novo projeto" subtitle="1) Dê um nome e escolha o tipo de conteúdo · 2) Envie o vídeo ou importe por link · 3) Analise com a IA." icon={<Plus className="size-5" />} />
      <div className="space-y-5">
        <Card>
          <div className="grid gap-4 sm:grid-cols-[1fr_260px_auto] sm:items-end">
            <Field label="Nome do projeto"><input className={inputCls} placeholder="Ex.: Gameplay Valorant — 23/11" value={name} onChange={(e) => setName(e.target.value)} /></Field>
            <Field label="Tipo de conteúdo" hint="Ajusta pesos da seleção e layouts.">
              <select className={inputCls} value={kind} onChange={(e) => setKind(e.target.value)}>{KINDS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
            </Field>
            <Btn variant="primary" onClick={create} loading={busy}>Criar projeto</Btn>
          </div>
          {err && <div className="mt-3"><Notice tone="rose">{err}</Notice></div>}
        </Card>
        {currentId && project && (
          <>
            <p className="text-sm text-zinc-400">Projeto ativo: <b className="text-zinc-100">{project.name}</b></p>
            {project.source ? <SourceCard project={project} onChange={reload} /> : <ImportPanel project={project} onChange={reload} />}
            {project.source && (
              <div className="flex flex-wrap gap-3">
                <Link href={project.kind === "game" ? "/t/game" : "/t/clips"}><Btn variant="primary"><Scissors className="size-4" />Analisar vídeo e criar cortes</Btn></Link>
                <Link href="/t/transcript"><Btn>Transcrever</Btn></Link>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
