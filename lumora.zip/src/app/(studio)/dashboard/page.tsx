"use client";
import Link from "next/link";
import { useEffect, useState } from "react";
import { Activity, Film, HardDrive, LayoutDashboard, Scissors, Plus } from "lucide-react";
import { api, fmtBytes } from "@/lib/client";
import type { JobInfo } from "@/lib/types";
import { Badge, Btn, Card, PageHeader } from "@/components/ui";
import { useProject } from "@/components/ProjectContext";

type Sys = { counts: Record<string, number>; storage: { used: number; free: number | null; quota: number }; ffmpeg: string | null };

export default function Dashboard() {
  const { projects, setCurrent } = useProject();
  const [sys, setSys] = useState<Sys | null>(null);
  const [jobs, setJobs] = useState<JobInfo[]>([]);
  useEffect(() => {
    const load = () => { api<Sys>("/api/system").then(setSys).catch(() => {}); api<JobInfo[]>("/api/jobs").then(setJobs).catch(() => {}); };
    load();
    const t = setInterval(load, 4000);
    return () => clearInterval(t);
  }, []);
  const stats = [
    { l: "Projetos", v: sys?.counts.projects ?? "—", i: Film },
    { l: "Cortes (60–90 s)", v: sys?.counts.clips ?? "—", i: Scissors },
    { l: "Cortes renderizados", v: sys?.counts.rendered ?? "—", i: Activity },
    { l: "Armazenamento", v: sys ? fmtBytes(sys.storage.used) : "—", i: HardDrive },
  ];
  return (
    <div>
      <PageHeader title="Dashboard" subtitle="Visão geral dos projetos, tarefas em andamento e recursos." icon={<LayoutDashboard className="size-5" />} actions={<Link href="/new"><Btn variant="primary"><Plus className="size-4" />Novo projeto</Btn></Link>} />
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {stats.map((s) => (
          <Card key={s.l}><s.i className="mb-3 size-5 text-violet-300" /><p className="text-2xl font-semibold">{s.v}</p><p className="text-xs text-zinc-500">{s.l}</p></Card>
        ))}
      </div>
      <div className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <Card>
          <h2 className="mb-4 font-medium">Projetos recentes</h2>
          {!projects.length ? <p className="text-sm text-zinc-500">Nenhum projeto ainda. <Link href="/new" className="text-violet-300 underline">Crie o primeiro</Link>.</p> : (
            <ul className="divide-y divide-white/[0.06]">
              {projects.slice(0, 6).map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0"><p className="truncate text-sm font-medium">{p.name}</p><p className="text-xs text-zinc-500">{p.source ? `${p.source.width}×${p.source.height}` : "sem vídeo"} · {p.clipCount} cortes · {new Date(p.updatedAt).toLocaleString("pt-BR")}</p></div>
                  <Link href="/t/clips" onClick={() => setCurrent(p.id)}><Btn size="sm">Abrir</Btn></Link>
                </li>
              ))}
            </ul>
          )}
        </Card>
        <Card>
          <h2 className="mb-4 font-medium">Fila de tarefas</h2>
          {!jobs.length ? <p className="text-sm text-zinc-500">Sem tarefas.</p> : (
            <ul className="space-y-2.5">
              {jobs.slice(0, 8).map((j) => (
                <li key={j.id} className="flex items-center justify-between gap-2 text-sm">
                  <span className="truncate text-zinc-300">{j.type}</span>
                  <span className="flex items-center gap-2">{j.status === "running" && <span className="text-xs text-zinc-500">{j.progress}%</span>}<Badge tone={j.status === "done" ? "green" : j.status === "failed" ? "rose" : j.status === "running" ? "violet" : "zinc"}>{j.status}</Badge></span>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-4 text-[11px] text-zinc-600">{sys?.ffmpeg ?? "FFmpeg não detectado"}</p>
        </Card>
      </div>
    </div>
  );
}
