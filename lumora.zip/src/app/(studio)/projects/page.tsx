"use client";
import Link from "next/link";
import { Clock, Plus } from "lucide-react";
import { Badge, Btn, Empty, PageHeader } from "@/components/ui";
import { useProject } from "@/components/ProjectContext";
import { fmtTime } from "@/lib/types";

export default function Projects() {
  const { projects, setCurrent, currentId } = useProject();
  return (
    <div>
      <PageHeader title="Projetos recentes" subtitle="Tudo é salvo no banco de dados e no armazenamento persistente — nada se perde ao atualizar a página." icon={<Clock className="size-5" />} actions={<Link href="/new"><Btn variant="primary"><Plus className="size-4" />Novo</Btn></Link>} />
      {!projects.length ? <Empty title="Nenhum projeto">Crie um projeto para começar.</Empty> : (
        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {projects.map((p) => (
            <div key={p.id} className={`glass rise overflow-hidden rounded-2xl transition hover:border-white/20 ${currentId === p.id ? "ring-1 ring-violet-400/50" : ""}`}>
              <div className="relative aspect-video bg-black">
                {p.source ? <video src={`${p.source.url}#t=1`} preload="metadata" muted className="size-full object-cover" /> : <div className="grid size-full place-items-center text-xs text-zinc-600">sem vídeo</div>}
                {p.source?.durationSec && <span className="absolute bottom-2 right-2 rounded bg-black/70 px-1.5 py-0.5 text-[11px]">{fmtTime(p.source.durationSec)}</span>}
              </div>
              <div className="p-4">
                <p className="truncate font-medium">{p.name}</p>
                <div className="mt-2 flex flex-wrap gap-1.5"><Badge tone="violet">{p.kind}</Badge><Badge>{p.clipCount} cortes</Badge>{p.renderedCount > 0 && <Badge tone="green">{p.renderedCount} prontos</Badge>}</div>
                <p className="mt-2 text-xs text-zinc-500">{new Date(p.updatedAt).toLocaleString("pt-BR")}</p>
                <div className="mt-3 flex gap-2"><Link href="/t/clips" onClick={() => setCurrent(p.id)} className="flex-1"><Btn size="sm" variant="primary" className="w-full">Abrir</Btn></Link></div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
