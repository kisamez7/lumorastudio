"use client";
import { useState } from "react";
import { post } from "@/lib/client";
import { Btn, inputCls, Notice } from "@/components/ui";
import { Logo } from "@/components/Shell";

export default function Login() {
  const [token, setToken] = useState("");
  const [err, setErr] = useState("");
  return (
    <div className="grid min-h-screen place-items-center px-4">
      <form className="glass w-full max-w-sm space-y-4 rounded-2xl p-7" onSubmit={async (e) => { e.preventDefault(); try { await post("/api/auth/login", { token }); location.href = "/"; } catch (x) { setErr(x instanceof Error ? x.message : "Erro"); } }}>
        <Logo size="lg" />
        <p className="text-sm text-zinc-400">Esta instância é protegida. Informe o código de acesso.</p>
        <input type="password" className={inputCls} placeholder="Código de acesso" value={token} onChange={(e) => setToken(e.target.value)} autoFocus />
        {err && <Notice tone="rose">{err}</Notice>}
        <Btn variant="primary" className="w-full" type="submit">Entrar</Btn>
      </form>
    </div>
  );
}
