import { db } from "@/db";
import { projects } from "@/db/schema";
import { body, handler, ok, fail } from "@/server/http";
import { projectList } from "@/server/queries";

export const dynamic = "force-dynamic";

export const GET = handler(async () => ok(await projectList()));

export const POST = handler(async (req: Request) => {
  const b = await body<{ name?: string; kind?: string }>(req);
  const name = String(b.name || "").trim().slice(0, 120) || `Projeto ${new Date().toLocaleDateString("pt-BR")}`;
  const kind = ["general", "game", "podcast", "educational"].includes(String(b.kind)) ? String(b.kind) : "general";
  const [p] = await db.insert(projects).values({ name, kind }).returning();
  if (!p) return fail(500, "Falha ao criar projeto");
  return ok(p, 201);
});
