import { eq } from "drizzle-orm";
import { db } from "@/db";
import { analyses, projects } from "@/db/schema";
import { body, fail, handler, ok, type Ctx } from "@/server/http";
import { getSegments } from "@/server/pipeline";
import { buildMindmap, buildNotes, summarize } from "@/server/ai/understand";
import { getAsset } from "@/server/assets";

export const dynamic = "force-dynamic";

export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const [a] = await db.select().from(analyses).where(eq(analyses.projectId, id));
  return ok({ summary: a?.summary ?? null, mindmap: a?.mindmap ?? null, notes: a?.notes ?? null, coverage: a?.coverage ?? null, audio: a?.audio ? { energy: a.audio.energy, peaks: a.audio.peaks, silenceRatio: a.audio.silenceRatio } : null, visual: a?.visual ? { motion: a.visual.motion, cuts: a.visual.cuts } : null });
});

async function upsert(id: string, patch: Partial<typeof analyses.$inferInsert>) {
  await db.insert(analyses).values({ projectId: id, ...patch }).onConflictDoUpdate({ target: analyses.projectId, set: { ...patch, updatedAt: new Date() } });
}

export const POST = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ kind?: string }>(req);
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail(404, "Projeto não encontrado");
  const segs = await getSegments(id);
  if (!segs.length) return fail(422, "Este recurso precisa de transcrição. Gere com o Whisper local ou importe um SRT/VTT em Transcrição.");
  const src = p.sourceAssetId ? await getAsset(p.sourceAssetId) : null;
  const duration = src?.durationSec ?? segs[segs.length - 1].end;
  if (b.kind === "summary") { const summary = await summarize(segs, duration); await upsert(id, { summary }); return ok({ summary }); }
  if (b.kind === "mindmap") { const mindmap = buildMindmap(p.name, segs); await upsert(id, { mindmap }); return ok({ mindmap }); }
  if (b.kind === "notes") { const notes = buildNotes(p.name, segs, duration); await upsert(id, { notes }); return ok({ notes }); }
  return fail(400, "kind inválido");
});

export const PUT = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ notes?: string }>(req);
  if (typeof b.notes !== "string") return fail(400, "notes ausente");
  await upsert(id, { notes: b.notes.slice(0, 200000) });
  return ok({ ok: true });
});
