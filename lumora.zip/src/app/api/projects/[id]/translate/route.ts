import { body, fail, handler, ok, type Ctx } from "@/server/http";
import { getSegments } from "@/server/pipeline";
import { translateSegments } from "@/server/ai/understand";
import { toSrt } from "@/server/ai/transcribe";
import { llmAvailable } from "@/server/ai/llm";

export const maxDuration = 600;

export const POST = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ lang?: string }>(req);
  const lang = String(b.lang || "inglês").slice(0, 30);
  if (!llmAvailable()) return fail(501, "Tradução requer um modelo de linguagem local. Configure OLLAMA_URL (ex.: http://localhost:11434) e OLLAMA_MODEL. Nenhuma tradução foi simulada.");
  const segs = await getSegments(id);
  if (!segs.length) return fail(422, "Sem transcrição para traduzir.");
  const out = await translateSegments(segs, lang);
  if (!out) return fail(502, "O modelo local não respondeu corretamente. Verifique se o Ollama está ativo e o modelo baixado.");
  return ok({ lang, segments: out, srt: toSrt(out) });
});
