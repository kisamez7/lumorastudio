import { eq } from "drizzle-orm";
import { db } from "@/db";
import { projects } from "@/db/schema";
import { body, fail, handler, ok, type Ctx } from "@/server/http";
import { enqueueJob } from "@/server/jobs";
import { importUrlJob } from "@/server/pipeline";
import { parseUrl, UrlError } from "@/server/security";

export const POST = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ url?: string }>(req);
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail(404, "Projeto não encontrado");
  try {
    parseUrl(String(b.url || ""));
  } catch (e) {
    return fail(400, e instanceof UrlError ? e.message : "URL inválida");
  }
  const url = String(b.url).trim();
  const jobId = await enqueueJob("import", id, { url }, (c) => importUrlJob(c, { projectId: id, url, purpose: "source" }));
  return ok({ jobId }, 202);
});
