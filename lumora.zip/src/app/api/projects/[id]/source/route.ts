import { eq } from "drizzle-orm";
import { db } from "@/db";
import { analyses, assets, clips, projects, transcripts } from "@/db/schema";
import { cfg } from "@/server/config";
import { fail, handler, isUuid, ok, requireAuth, type Ctx } from "@/server/http";
import { ffprobe } from "@/server/ffmpeg";
import { abs, assertSpace, newRel, removeRel, saveStream, SizeLimitError } from "@/server/storage";
import { assetDto, getAsset, registerAsset } from "@/server/assets";
import { VIDEO_EXT, extOf, safeFilename } from "@/server/security";

export const dynamic = "force-dynamic";
export const maxDuration = 3600;

/** Upload por corpo bruto (streaming para disco; sem carregar o arquivo em memória). */
export const PUT = handler(async (req: Request, ctx: Ctx) => {
  const denied = requireAuth(req);
  if (denied) return denied;
  const { id } = await ctx.params;
  if (!isUuid(id)) return fail(404, "Projeto não encontrado");
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail(404, "Projeto não encontrado");
  const filename = safeFilename(new URL(req.url).searchParams.get("filename") || "video.mp4");
  const ext = extOf(filename);
  if (!VIDEO_EXT.includes(ext)) return fail(415, `Formato .${ext || "?"} não suportado. Use MP4, MOV, MKV ou WEBM.`);
  if (!req.body) return fail(400, "Corpo vazio");
  const len = Number(req.headers.get("content-length") || 0);
  if (len > cfg.maxUploadBytes) return fail(413, `Arquivo excede o limite de ${Math.round(cfg.maxUploadBytes / 1048576)} MB.`);
  await assertSpace(len);
  const rel = newRel(`projects/${id}`, ext);
  try {
    await saveStream(rel, req.body, cfg.maxUploadBytes);
  } catch (e) {
    if (e instanceof SizeLimitError) return fail(413, e.message);
    return fail(499, "Upload interrompido.");
  }
  let info;
  try {
    info = await ffprobe(abs(rel));
  } catch {
    await removeRel(rel);
    return fail(422, "Arquivo inválido ou corrompido: não foi possível ler o vídeo.");
  }
  if (!info.hasVideo) { await removeRel(rel); return fail(422, "O arquivo não contém trilha de vídeo."); }
  if (info.duration > cfg.maxDurationSec) { await removeRel(rel); return fail(422, `Duração de ${Math.round(info.duration / 60)} min excede o limite de ${Math.round(cfg.maxDurationSec / 60)} min.`); }
  const asset = await registerAsset({ projectId: id, kind: "source", filename, relPath: rel, meta: { origin: "upload" } });
  if (p.sourceAssetId) await clearSource(id, p.sourceAssetId);
  await db.update(projects).set({ sourceAssetId: asset.id, sourceType: "upload", sourceUrl: null, status: "ready", updatedAt: new Date() }).where(eq(projects.id, id));
  return ok(assetDto(asset), 201);
});

async function clearSource(projectId: string, oldAssetId: string) {
  const old = await getAsset(oldAssetId);
  if (old) { await removeRel(old.relPath); await db.delete(assets).where(eq(assets.id, old.id)); }
  await db.delete(transcripts).where(eq(transcripts.projectId, projectId));
  await db.delete(analyses).where(eq(analyses.projectId, projectId));
  await db.delete(clips).where(eq(clips.projectId, projectId));
}

export const DELETE = handler(async (req: Request, ctx: Ctx) => {
  const denied = requireAuth(req);
  if (denied) return denied;
  const { id } = await ctx.params;
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail(404, "Projeto não encontrado");
  if (p.sourceAssetId) await clearSource(id, p.sourceAssetId);
  await db.update(projects).set({ sourceAssetId: null, sourceType: null, sourceUrl: null, status: "draft", updatedAt: new Date() }).where(eq(projects.id, id));
  return ok({ ok: true });
});
