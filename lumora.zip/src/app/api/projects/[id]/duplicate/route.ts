import fsp from "node:fs/promises";
import path from "node:path";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { analyses, clips, projects, transcripts } from "@/db/schema";
import { fail, handler, ok, type Ctx } from "@/server/http";
import { getAsset, registerAsset } from "@/server/assets";
import { abs, assertSpace, ensureDir, newRel } from "@/server/storage";

export const POST = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail(404, "Projeto não encontrado");
  const [np] = await db.insert(projects).values({ name: `${p.name} (cópia)`, kind: p.kind, settings: p.settings, sourceType: p.sourceType, sourceUrl: p.sourceUrl, status: p.status }).returning();
  const src = p.sourceAssetId ? await getAsset(p.sourceAssetId) : null;
  if (src) {
    await assertSpace(src.sizeBytes);
    const rel = newRel(`projects/${np.id}`, path.extname(src.relPath).slice(1) || "mp4");
    await ensureDir(path.posix.dirname(rel));
    await fsp.copyFile(abs(src.relPath), abs(rel));
    const na = await registerAsset({ projectId: np.id, kind: "source", filename: src.filename, relPath: rel });
    await db.update(projects).set({ sourceAssetId: na.id }).where(eq(projects.id, np.id));
  }
  const [t] = await db.select().from(transcripts).where(eq(transcripts.projectId, id));
  if (t) await db.insert(transcripts).values({ ...t, projectId: np.id });
  const [a] = await db.select().from(analyses).where(eq(analyses.projectId, id));
  if (a) await db.insert(analyses).values({ ...a, projectId: np.id });
  const cs = await db.select().from(clips).where(eq(clips.projectId, id));
  for (const c of cs) {
    // cópias de cortes voltam a "candidate" (render é refeito sob demanda)
    const { id: _i, outputAssetId: _o, renderedDuration: _r, createdAt: _c, updatedAt: _u, ...rest } = c;
    void _i; void _o; void _r; void _c; void _u;
    await db.insert(clips).values({ ...rest, projectId: np.id, status: c.type === "compilation" ? "failed" : "candidate" });
  }
  return ok(np, 201);
});
