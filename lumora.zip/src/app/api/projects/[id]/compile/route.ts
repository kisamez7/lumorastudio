import { body, fail, handler, ok, type Ctx } from "@/server/http";
import { enqueueJob } from "@/server/jobs";
import { compileJob } from "@/server/pipeline";

export const POST = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ clipIds?: string[]; transition?: string; title?: string }>(req);
  if (!Array.isArray(b.clipIds) || b.clipIds.length < 2) return fail(400, "Selecione ao menos 2 trechos.");
  const transition = (["fade", "zoomin", "slideleft", "none"].includes(String(b.transition)) ? b.transition : "fade") as "fade" | "zoomin" | "slideleft" | "none";
  const jobId = await enqueueJob("compile", id, { clipIds: b.clipIds }, (c) => compileJob(c, id, { clipIds: b.clipIds!, transition, title: String(b.title || "Compilação").slice(0, 100) }));
  return ok({ jobId }, 202);
});
