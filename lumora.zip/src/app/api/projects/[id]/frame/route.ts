import fsp from "node:fs/promises";
import path from "node:path";
import { fail, handler, type Ctx } from "@/server/http";
import { getSource } from "@/server/pipeline";
import { extractFrame } from "@/server/media-tools";
import { rmrf, tmpDir } from "@/server/storage";

export const dynamic = "force-dynamic";

export const GET = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const u = new URL(req.url);
  const src = await getSource(id);
  if (!src) return fail(404, "Sem vídeo.");
  const t = Math.max(0, Math.min((src.asset.durationSec ?? 1) - 0.1, Number(u.searchParams.get("t") || 0)));
  const w = Math.max(160, Math.min(1920, Number(u.searchParams.get("w") || 480)));
  const dir = await tmpDir();
  try {
    const out = path.join(dir, "f.jpg");
    await extractFrame(src.file, t, out, w);
    const buf = await fsp.readFile(out);
    return new Response(new Uint8Array(buf), { headers: { "content-type": "image/jpeg", "cache-control": "private, max-age=3600" } });
  } finally {
    await rmrf(dir);
  }
});
