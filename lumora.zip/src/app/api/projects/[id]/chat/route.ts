import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { analyses, chatMessages, clips, projects } from "@/db/schema";
import { body, fail, handler, ok, type Ctx } from "@/server/http";
import { getSegments } from "@/server/pipeline";
import { answerQuestion } from "@/server/ai/understand";
import { topKeywords } from "@/server/ai/text";
import { getAsset } from "@/server/assets";

export const dynamic = "force-dynamic";

export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const rows = await db.select().from(chatMessages).where(eq(chatMessages.projectId, id)).orderBy(asc(chatMessages.createdAt));
  return ok(rows);
});

export const POST = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ question?: string }>(req);
  const q = String(b.question || "").trim().slice(0, 600);
  if (!q) return fail(400, "Pergunta vazia.");
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail(404, "Projeto não encontrado");
  const segs = await getSegments(id);
  if (!segs.length) return fail(422, "O chat precisa da transcrição do vídeo. Gere-a em Transcrição.");
  const src = p.sourceAssetId ? await getAsset(p.sourceAssetId) : null;
  const cs = await db.select({ start: clips.startSec, score: clips.score, topic: clips.topic }).from(clips).where(eq(clips.projectId, id));
  const [a] = await db.select({ s: analyses.summary }).from(analyses).where(eq(analyses.projectId, id));
  const topics = a?.s?.topics.map((t) => t.name) ?? topKeywords(segs.map((s) => s.text).join(" "), 6);
  await db.insert(chatMessages).values({ projectId: id, role: "user", content: q });
  const r = await answerQuestion(q, segs, { topics, clips: cs, duration: src?.durationSec ?? segs[segs.length - 1].end });
  const [m] = await db.insert(chatMessages).values({ projectId: id, role: "assistant", content: r.answer, refs: r.refs }).returning();
  return ok({ ...m, engine: r.engine });
});

export const DELETE = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  await db.delete(chatMessages).where(eq(chatMessages.projectId, id));
  return ok({ ok: true });
});
