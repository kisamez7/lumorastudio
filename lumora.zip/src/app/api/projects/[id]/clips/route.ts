import { eq } from "drizzle-orm";
import { db } from "@/db";
import { clips, projects, assets } from "@/db/schema";
import { PLAN_MAX, PLAN_MIN, captionPresets, defaultAudioFx, defaultHook, defaultLayout, type Rect } from "@/lib/types";
import { body, fail, handler, ok, type Ctx } from "@/server/http";
import { clipsWithOutput } from "@/server/queries";
import { getSegments } from "@/server/pipeline";
import { assertClipRange, DurationError } from "@/server/render";
import { buildCaptions } from "@/server/ai/subtitles";
import { makeHooks } from "@/server/ai/hooks";
import { signalsOf } from "@/server/ai/text";
import { isTerminal } from "@/server/ai/text";

export const dynamic = "force-dynamic";

export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  return ok(await clipsWithOutput(id));
});

/** Cria um corte manual a partir de um momento (ex.: Find Moments). Sempre ajusta para 60–90 s em limites naturais. */
export const POST = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ start?: number; end?: number; around?: number }>(req);
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p?.sourceAssetId) return fail(400, "Projeto sem vídeo.");
  const [src] = await db.select().from(assets).where(eq(assets.id, p.sourceAssetId));
  const duration = src?.durationSec ?? 0;
  const segs = await getSegments(id);
  let start: number, end: number;
  if (typeof b.around === "number") {
    const t = Math.max(0, Math.min(duration, b.around));
    const starts = segs.filter((s, i) => i === 0 || isTerminal(segs[i - 1].text) || s.start - segs[i - 1].end > 0.7).map((s) => s.start);
    const ends = segs.filter((s, i) => !segs[i + 1] || isTerminal(s.text) || segs[i + 1].start - s.end > 0.7).map((s) => s.end);
    const wantStart = Math.max(0, t - 15);
    start = starts.length ? starts.reduce((a, c) => (Math.abs(c - wantStart) < Math.abs(a - wantStart) ? c : a)) : wantStart;
    if (start + PLAN_MAX > duration) start = Math.max(0, duration - PLAN_MAX);
    const cand = ends.filter((e) => e - start >= PLAN_MIN && e - start <= PLAN_MAX);
    end = cand.length ? cand.reduce((a, c) => (Math.abs(c - start - 75) < Math.abs(a - start - 75) ? c : a)) : Math.min(duration, start + 75);
  } else {
    start = Number(b.start);
    end = Number(b.end);
  }
  try {
    assertClipRange(start, end, duration);
  } catch (e) {
    return fail(400, e instanceof DurationError ? e.message : "Intervalo inválido");
  }
  const text = segs.filter((s) => s.end > start && s.start < end).map((s) => s.text).join(" ");
  const style = { ...captionPresets.viral };
  const sig = signalsOf(text);
  const tags = [sig.laugh ? "humor/risadas" : "", sig.game ? "gameplay" : ""].filter(Boolean);
  const hooks = await makeHooks({ text, tags, durationSec: end - start, kind: p.kind });
  const settings = p.settings as { cam?: Rect | null; game?: Rect | null };
  const layout = defaultLayout();
  if (settings.cam) { layout.cam = settings.cam; layout.game = settings.game ?? null; layout.mode = p.kind === "game" ? "A" : "fit"; }
  const [row] = await db.insert(clips).values({
    projectId: id, title: `Corte manual ${Math.round(start)}s`, startSec: start, endSec: end, score: 0, spokenText: text.slice(0, 1500),
    description: "Corte criado manualmente (sem pontuação automática).", justification: "Criado pelo usuário a partir de um momento selecionado.",
    hookOptions: hooks, hook: { ...defaultHook(), text: hooks[0]?.text ?? "", enabled: hooks.length > 0 }, captionStyle: style,
    captions: segs.length ? buildCaptions(segs, start, end, style) : [], layout, audioFx: defaultAudioFx(), extra: { manual: true, tags },
  }).returning();
  return ok(row, 201);
});
