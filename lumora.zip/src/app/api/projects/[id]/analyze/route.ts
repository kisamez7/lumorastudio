import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { jobs, projects } from "@/db/schema";
import { body, fail, handler, ok, type Ctx } from "@/server/http";
import { enqueueJob } from "@/server/jobs";
import { analyzeJob } from "@/server/pipeline";

export const POST = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ transcribe?: boolean; count?: number | "auto"; kind?: string; language?: string; reuse?: boolean }>(req);
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail(404, "Projeto não encontrado");
  if (!p.sourceAssetId) return fail(400, "Envie ou importe um vídeo antes de analisar.");
  const [running] = await db.select({ id: jobs.id }).from(jobs).where(and(eq(jobs.projectId, id), eq(jobs.type, "analyze"), inArray(jobs.status, ["queued", "running"])));
  if (running) return ok({ jobId: running.id, reused: true }, 202);
  const count = b.count === "auto" || b.count === undefined ? "auto" : Math.max(1, Math.min(20, Number(b.count) || 5));
  if (b.kind && ["general", "game", "podcast", "educational"].includes(b.kind) && b.kind !== p.kind) await db.update(projects).set({ kind: b.kind }).where(eq(projects.id, id));
  const jobId = await enqueueJob("analyze", id, { ...b }, (c) => analyzeJob(c, id, { transcribe: b.transcribe !== false, count, kind: b.kind, language: b.language, reuse: b.reuse }));
  return ok({ jobId }, 202);
});
