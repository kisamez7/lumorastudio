import { eq } from "drizzle-orm";
import { db } from "@/db";
import { analyses } from "@/db/schema";
import { body, fail, handler, ok, type Ctx } from "@/server/http";
import { getSegments } from "@/server/pipeline";
import { findMoments } from "@/server/ai/understand";

export const POST = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ query?: string }>(req);
  const q = String(b.query || "").trim();
  if (q.length < 2) return fail(400, "Digite o que procurar.");
  const segs = await getSegments(id);
  const [a] = await db.select().from(analyses).where(eq(analyses.projectId, id));
  if (!segs.length && !a?.audio) return fail(422, "Analise o vídeo ou gere a transcrição antes de buscar momentos.");
  return ok({ hits: findMoments(q, segs, a?.audio?.energy ?? [], a?.visual?.motion ?? []), usedTranscript: segs.length > 0, usedAudio: !!a?.audio, usedVisual: !!a?.visual });
});
