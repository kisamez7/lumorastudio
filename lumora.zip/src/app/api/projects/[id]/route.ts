import { eq } from "drizzle-orm";
import { db } from "@/db";
import { analyses, assets, chatMessages, clips, jobs, projects, publishItems, transcripts } from "@/db/schema";
import { body, fail, handler, isUuid, ok, type Ctx } from "@/server/http";
import { getAsset, assetDto } from "@/server/assets";
import { deleteAssetFiles } from "@/server/pipeline";

export const dynamic = "force-dynamic";

export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  if (!isUuid(id)) return fail(404, "Projeto não encontrado");
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail(404, "Projeto não encontrado");
  const src = p.sourceAssetId ? await getAsset(p.sourceAssetId) : null;
  const [t] = await db.select({ n: transcripts.projectId, engine: transcripts.engine, language: transcripts.language }).from(transcripts).where(eq(transcripts.projectId, id));
  const [a] = await db.select({ status: analyses.status, coverage: analyses.coverage, hasSummary: analyses.summary, hasMind: analyses.mindmap }).from(analyses).where(eq(analyses.projectId, id));
  return ok({
    ...p,
    source: src ? assetDto(src) : null,
    transcript: t ? { engine: t.engine, language: t.language } : null,
    analysis: a ? { status: a.status, coverage: a.coverage, hasSummary: !!a.hasSummary, hasMindmap: !!a.hasMind } : null,
  });
});

export const PATCH = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ name?: string; kind?: string; settings?: Record<string, unknown> }>(req);
  const [cur] = await db.select().from(projects).where(eq(projects.id, id));
  if (!cur) return fail(404, "Projeto não encontrado");
  const [p] = await db
    .update(projects)
    .set({
      ...(b.name ? { name: String(b.name).slice(0, 120) } : {}),
      ...(b.kind && ["general", "game", "podcast", "educational"].includes(b.kind) ? { kind: b.kind } : {}),
      ...(b.settings ? { settings: { ...cur.settings, ...b.settings } } : {}),
      updatedAt: new Date(),
    })
    .where(eq(projects.id, id))
    .returning();
  return ok(p);
});

export const DELETE = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const files = await db.select({ relPath: assets.relPath }).from(assets).where(eq(assets.projectId, id));
  await deleteAssetFiles(files);
  await db.delete(assets).where(eq(assets.projectId, id));
  await db.delete(clips).where(eq(clips.projectId, id));
  await db.delete(transcripts).where(eq(transcripts.projectId, id));
  await db.delete(analyses).where(eq(analyses.projectId, id));
  await db.delete(chatMessages).where(eq(chatMessages.projectId, id));
  await db.delete(publishItems).where(eq(publishItems.projectId, id));
  await db.delete(jobs).where(eq(jobs.projectId, id));
  await db.delete(projects).where(eq(projects.id, id));
  return ok({ ok: true });
});
