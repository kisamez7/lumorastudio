import fsp from "node:fs/promises";
import path from "node:path";
import { cfg } from "@/server/config";
import { fail, handler, ok, type Ctx } from "@/server/http";
import { getSource } from "@/server/pipeline";
import { extractFrame } from "@/server/media-tools";
import { rmrf, tmpDir } from "@/server/storage";

export const maxDuration = 120;

/** Detecção automática de webcam: delega ao serviço de Computer Vision (OpenCV/MediaPipe, ver /backend). */
export const POST = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  if (!cfg.cvServiceUrl) return fail(501, "Detecção automática requer o serviço de Computer Vision (pasta /backend, defina CV_SERVICE_URL). Use a seleção manual da região da webcam. Nada foi simulado.");
  const src = await getSource(id);
  if (!src) return fail(404, "Sem vídeo.");
  const dur = src.asset.durationSec ?? 10;
  const dir = await tmpDir();
  try {
    const form = new FormData();
    for (const [i, f] of [0.05, 0.25, 0.5, 0.75, 0.95].entries()) {
      const out = path.join(dir, `f${i}.jpg`);
      await extractFrame(src.file, dur * f, out, 960);
      form.append("frames", new Blob([new Uint8Array(await fsp.readFile(out))], { type: "image/jpeg" }), `f${i}.jpg`);
    }
    const r = await fetch(`${cfg.cvServiceUrl}/detect-webcam`, { method: "POST", body: form, signal: AbortSignal.timeout(60000) });
    if (!r.ok) return fail(502, "Serviço de visão respondeu com erro.");
    return ok(await r.json());
  } catch {
    return fail(502, "Serviço de visão indisponível.");
  } finally {
    await rmrf(dir);
  }
});
