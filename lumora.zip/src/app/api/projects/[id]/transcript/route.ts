import { eq } from "drizzle-orm";
import { db } from "@/db";
import { projects, transcripts } from "@/db/schema";
import { body, fail, handler, ok, type Ctx } from "@/server/http";
import { enqueueJob } from "@/server/jobs";
import { getSegments, saveTranscript, transcribeJob } from "@/server/pipeline";
import { parseSubtitles, sanitizeSegments, toSrt, toTxt } from "@/server/ai/transcribe";
import type { Segment } from "@/lib/types";

export const dynamic = "force-dynamic";

export const GET = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const [t] = await db.select().from(transcripts).where(eq(transcripts.projectId, id));
  const fmt = new URL(req.url).searchParams.get("format");
  const segs = t?.segments ?? [];
  if (fmt === "srt" || fmt === "txt") {
    if (!segs.length) return fail(404, "Sem transcrição.");
    const text = fmt === "srt" ? toSrt(segs) : toTxt(segs);
    return new Response(text, { headers: { "content-type": "text/plain; charset=utf-8", "content-disposition": `attachment; filename="transcricao.${fmt}"` } });
  }
  return ok({ segments: segs, engine: t?.engine ?? null, language: t?.language ?? null });
});

export const PUT = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ segments?: Segment[]; srt?: string; language?: string }>(req);
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p) return fail(404, "Projeto não encontrado");
  let segs: Segment[];
  let engine = "manual";
  if (typeof b.srt === "string") {
    segs = parseSubtitles(b.srt);
    if (!segs.length) return fail(422, "Não encontrei marcações de tempo válidas (SRT/VTT). Texto sem tempos não pode ser sincronizado.");
    engine = "srt-import";
  } else if (Array.isArray(b.segments)) {
    segs = b.segments.filter((s) => typeof s.text === "string" && Number.isFinite(s.start) && Number.isFinite(s.end)).map((s) => ({ start: s.start, end: s.end, text: s.text, speaker: s.speaker, words: s.words }));
    const prev = await getSegments(id);
    // texto editado invalida timestamps por palavra daquele segmento
    segs = segs.map((s, i) => (prev[i] && prev[i].text !== s.text ? { ...s, words: undefined } : s));
    engine = "manual";
  } else return fail(400, "Envie 'segments' ou 'srt'.");
  const dur = 0;
  await saveTranscript(id, sanitizeSegments(segs, dur), engine, b.language || "pt");
  return ok({ segments: segs.length, engine });
});

export const POST = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ language?: string }>(req);
  const [p] = await db.select().from(projects).where(eq(projects.id, id));
  if (!p?.sourceAssetId) return fail(400, "Projeto sem vídeo.");
  const jobId = await enqueueJob("transcribe", id, { ...b }, (c) => transcribeJob(c, id, b.language || "pt"));
  return ok({ jobId }, 202);
});
