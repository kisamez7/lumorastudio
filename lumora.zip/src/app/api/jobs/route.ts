import { handler, isUuid, ok } from "@/server/http";
import { listJobs } from "@/server/jobs";

export const dynamic = "force-dynamic";

export const GET = handler(async (req: Request) => {
  const pid = new URL(req.url).searchParams.get("projectId");
  return ok(await listJobs(pid && isUuid(pid) ? pid : null, 40));
});
