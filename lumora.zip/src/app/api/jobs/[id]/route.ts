import { fail, handler, isUuid, ok, type Ctx } from "@/server/http";
import { getJob } from "@/server/jobs";

export const dynamic = "force-dynamic";

export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  if (!isUuid(id)) return fail(404, "Tarefa não encontrada");
  const j = await getJob(id);
  return j ? ok(j) : fail(404, "Tarefa não encontrada");
});
