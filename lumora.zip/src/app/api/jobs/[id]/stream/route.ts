import { fail, isUuid, type Ctx } from "@/server/http";
import { getJob } from "@/server/jobs";

export const dynamic = "force-dynamic";
export const maxDuration = 3600;

/** Server-Sent Events: progresso real da tarefa (lido do PostgreSQL). */
export async function GET(req: Request, ctx: Ctx) {
  const { id } = await ctx.params;
  if (!isUuid(id)) return fail(404, "Tarefa não encontrada");
  const enc = new TextEncoder();
  const stream = new ReadableStream({
    async start(controller) {
      let lastKey = "";
      const send = (data: unknown) => controller.enqueue(enc.encode(`data: ${JSON.stringify(data)}\n\n`));
      try {
        while (!req.signal.aborted) {
          const j = await getJob(id);
          if (!j) { send({ error: "not-found" }); break; }
          const key = `${j.status}|${j.progress}|${j.message}`;
          if (key !== lastKey) { send(j); lastKey = key; }
          if (["done", "failed", "canceled"].includes(j.status)) break;
          await new Promise((r) => setTimeout(r, 900));
        }
      } catch {}
      try { controller.close(); } catch {}
    },
  });
  return new Response(stream, { headers: { "content-type": "text/event-stream", "cache-control": "no-cache, no-transform", connection: "keep-alive" } });
}
