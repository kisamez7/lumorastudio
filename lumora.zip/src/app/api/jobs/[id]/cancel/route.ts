import { handler, ok, type Ctx } from "@/server/http";
import { cancelJob } from "@/server/jobs";

export const POST = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  await cancelJob(id);
  return ok({ ok: true });
});
