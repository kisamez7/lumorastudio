import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { assets } from "@/db/schema";
import { fail, handler, isUuid, ok, requireAuth } from "@/server/http";
import { assetDto, registerAsset } from "@/server/assets";
import { AUDIO_EXT, IMAGE_EXT, extOf, safeFilename } from "@/server/security";
import { abs, assertSpace, newRel, removeRel, saveStream, SizeLimitError } from "@/server/storage";

export const dynamic = "force-dynamic";

export const GET = handler(async (req: Request) => {
  const denied = requireAuth(req);
  if (denied) return denied;
  const u = new URL(req.url);
  const kinds = (u.searchParams.get("kind") || "").split(",").filter(Boolean);
  const pid = u.searchParams.get("projectId");
  const conds = [];
  if (kinds.length) conds.push(inArray(assets.kind, kinds));
  if (pid && isUuid(pid)) conds.push(eq(assets.projectId, pid));
  const rows = await db.select().from(assets).where(conds.length ? and(...conds) : undefined).orderBy(desc(assets.createdAt)).limit(300);
  return ok(rows.map(assetDto));
});

/** Upload de imagens (B-roll/overlays) e músicas — corpo bruto com ?kind=image|music&filename=&projectId= */
export const PUT = handler(async (req: Request) => {
  const denied = requireAuth(req);
  if (denied) return denied;
  const u = new URL(req.url);
  const kind = u.searchParams.get("kind") === "music" ? "music" : "image";
  const filename = safeFilename(u.searchParams.get("filename") || "arquivo");
  const ext = extOf(filename);
  if (!(kind === "image" ? IMAGE_EXT : AUDIO_EXT).includes(ext)) return fail(415, `Formato .${ext} não suportado para ${kind === "image" ? "imagem (png, jpg, webp)" : "música (mp3, wav, m4a)"}.`);
  const pid = u.searchParams.get("projectId");
  if (!req.body) return fail(400, "Corpo vazio");
  await assertSpace(Number(req.headers.get("content-length") || 0));
  const rel = newRel(pid && isUuid(pid) ? `projects/${pid}` : "library", ext);
  try {
    await saveStream(rel, req.body, 200 * 1024 * 1024);
  } catch (e) {
    return fail(e instanceof SizeLimitError ? 413 : 499, e instanceof Error ? e.message : "Falha no upload");
  }
  try {
    const a = await registerAsset({ projectId: pid && isUuid(pid) ? pid : null, kind, filename, relPath: rel });
    if (kind === "music" && !a.hasAudio) throw new Error("Arquivo sem áudio válido");
    if (kind === "image" && !a.width) throw new Error("Imagem inválida");
    return ok(assetDto(a), 201);
  } catch (e) {
    await removeRel(rel);
    void abs;
    return fail(422, e instanceof Error ? e.message : "Arquivo inválido");
  }
});
