import { body, fail, handler, ok, type Ctx } from "@/server/http";
import { enqueueJob } from "@/server/jobs";
import { audioToolJob, convertJob } from "@/server/pipeline";
import { getAsset } from "@/server/assets";

/** Conversão (mp4/webm/mp3/wav, altura ≤ original) ou processamento de áudio (mode: "audio"). */
export const POST = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<{ mode?: string; format?: string; height?: number; denoise?: boolean; normalize?: boolean; voice?: boolean; removeSilence?: boolean }>(req);
  const a = await getAsset(id);
  if (!a) return fail(404, "Arquivo não encontrado");
  if (b.mode === "audio") {
    const o = { denoise: !!b.denoise, normalize: !!b.normalize, voice: !!b.voice, removeSilence: !!b.removeSilence };
    return ok({ jobId: await enqueueJob("audio", a.projectId, { assetId: id, ...o }, (c) => audioToolJob(c, id, o)) }, 202);
  }
  const format = (["mp4", "webm", "mp3", "wav"].includes(String(b.format)) ? b.format : "mp4") as "mp4" | "webm" | "mp3" | "wav";
  const height = b.height ? Number(b.height) : undefined;
  if (height && a.height && height > a.height) return fail(400, `${height}p indisponível: o arquivo original tem ${a.height}p. Não ampliamos artificialmente.`);
  return ok({ jobId: await enqueueJob("convert", a.projectId, { assetId: id, format, height }, (c) => convertJob(c, id, { format, height })) }, 202);
});
