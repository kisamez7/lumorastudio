import fs from "node:fs";
import fsp from "node:fs/promises";
import { Readable } from "node:stream";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { assets, projects } from "@/db/schema";
import { fail, handler, isUuid, ok, type Ctx } from "@/server/http";
import { getAsset } from "@/server/assets";
import { abs, removeRel } from "@/server/storage";

export const dynamic = "force-dynamic";

/** Entrega arquivos com suporte a Range (seek no player) e ?download=1. Acesso só por ID aleatório + autenticação do app. */
export const GET = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  if (!isUuid(id)) return fail(404, "Arquivo não encontrado");
  const a = await getAsset(id);
  if (!a) return fail(404, "Arquivo não encontrado");
  const file = abs(a.relPath);
  const st = await fsp.stat(file).catch(() => null);
  if (!st) return fail(404, "Arquivo ausente no armazenamento");
  const size = st.size;
  const headers: Record<string, string> = {
    "content-type": a.mime || "application/octet-stream",
    "accept-ranges": "bytes",
    "x-content-type-options": "nosniff",
    "cache-control": "private, max-age=3600",
  };
  if (new URL(req.url).searchParams.get("download")) headers["content-disposition"] = `attachment; filename*=UTF-8''${encodeURIComponent(a.filename)}`;
  const range = req.headers.get("range")?.match(/bytes=(\d*)-(\d*)/);
  if (range) {
    let start = range[1] ? Number(range[1]) : 0;
    let end = range[2] ? Number(range[2]) : size - 1;
    if (!range[1] && range[2]) { start = Math.max(0, size - Number(range[2])); end = size - 1; }
    if (start > end || start >= size) return new Response(null, { status: 416, headers: { "content-range": `bytes */${size}` } });
    end = Math.min(end, size - 1);
    return new Response(Readable.toWeb(fs.createReadStream(file, { start, end })) as ReadableStream, { status: 206, headers: { ...headers, "content-range": `bytes ${start}-${end}/${size}`, "content-length": String(end - start + 1) } });
  }
  return new Response(Readable.toWeb(fs.createReadStream(file)) as ReadableStream, { headers: { ...headers, "content-length": String(size) } });
});

export const DELETE = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const a = await getAsset(id);
  if (!a) return fail(404, "Arquivo não encontrado");
  const [p] = await db.select({ id: projects.id }).from(projects).where(eq(projects.sourceAssetId, id));
  if (p) return fail(400, "Este é o vídeo de origem de um projeto. Remova-o pelo projeto.");
  await removeRel(a.relPath);
  await db.delete(assets).where(eq(assets.id, id));
  return ok({ ok: true });
});
