import { body, fail, handler, ok } from "@/server/http";
import { enqueueJob } from "@/server/jobs";
import { importUrlJob } from "@/server/pipeline";
import { parseUrl, UrlError } from "@/server/security";

/** Baixa uma mídia direta autorizada para "Arquivos baixados" (sem projeto). */
export const POST = handler(async (req: Request) => {
  const b = await body<{ url?: string; rights?: boolean }>(req);
  if (!b.rights) return fail(400, "Confirme que você tem os direitos/autorização para baixar este conteúdo.");
  try { parseUrl(String(b.url || "")); } catch (e) { return fail(400, e instanceof UrlError ? e.message : "URL inválida"); }
  const url = String(b.url).trim();
  return ok({ jobId: await enqueueJob("download", null, { url }, (c) => importUrlJob(c, { projectId: null, url, purpose: "download" })) }, 202);
});
