import { execFile } from "node:child_process";
import { sql } from "drizzle-orm";
import { db } from "@/db";
import { cfg } from "@/server/config";
import { FFMPEG } from "@/server/ffmpeg";
import { handler, ok } from "@/server/http";
import { ollamaStatus } from "@/server/ai/llm";
import { storageUsage } from "@/server/storage";

export const dynamic = "force-dynamic";

const ver = () => new Promise<string | null>((r) => execFile(FFMPEG, ["-version"], { timeout: 5000 }, (e, o) => r(e ? null : o.split("\n")[0])));

export const GET = handler(async () => {
  const [ff, ol, st, counts] = await Promise.all([
    ver(),
    ollamaStatus(),
    storageUsage(),
    db.execute(sql`select (select count(*)::int from projects) as projects, (select count(*)::int from clips where type='clip') as clips, (select count(*)::int from clips where status='rendered') as rendered, (select count(*)::int from jobs where status in ('queued','running')) as active_jobs, (select count(*)::int from assets) as assets`),
  ]);
  let cv = false;
  if (cfg.cvServiceUrl) cv = await fetch(`${cfg.cvServiceUrl}/health`, { signal: AbortSignal.timeout(2500) }).then((r) => r.ok).catch(() => false);
  return ok({
    mode: cfg.mode,
    ffmpeg: ff,
    whisper: { engine: "Whisper local (transformers.js/ONNX, CPU)", model: cfg.whisperModel, language: cfg.whisperLang },
    ollama: { configured: !!cfg.ollamaUrl, ...ol, model: cfg.ollamaModel },
    cvService: { configured: !!cfg.cvServiceUrl, reachable: cv },
    storage: { driver: "disco/volume local", ...st },
    limits: { maxUploadMB: cfg.maxUploadBytes / 1048576, maxImportMB: cfg.maxImportBytes / 1048576, maxVideoMinutes: cfg.maxDurationSec / 60, concurrency: cfg.jobConcurrency },
    auth: !!cfg.accessToken,
    counts: (counts.rows as Record<string, number>[])[0],
  });
});
