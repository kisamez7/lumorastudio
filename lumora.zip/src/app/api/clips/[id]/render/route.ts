import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { clips, jobs } from "@/db/schema";
import { fail, handler, ok, type Ctx } from "@/server/http";
import { enqueueJob } from "@/server/jobs";
import { renderJob } from "@/server/pipeline";

export const POST = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const [c] = await db.select().from(clips).where(eq(clips.id, id));
  if (!c) return fail(404, "Corte não encontrado");
  if (c.type !== "clip") return fail(400, "Compilações já são renderizadas ao serem criadas.");
  const [running] = await db.select({ id: jobs.id, input: jobs.input }).from(jobs).where(and(eq(jobs.projectId, c.projectId), eq(jobs.type, "render"), inArray(jobs.status, ["queued", "running"])));
  if (running && (running.input as { clipId?: string }).clipId === id) return ok({ jobId: running.id, reused: true }, 202);
  const jobId = await enqueueJob("render", c.projectId, { clipId: id }, (j) => renderJob(j, id));
  return ok({ jobId }, 202);
});
