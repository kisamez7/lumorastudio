import { eq } from "drizzle-orm";
import { db } from "@/db";
import { clips } from "@/db/schema";
import { fail, handler, type Ctx } from "@/server/http";
import { toSrt } from "@/server/ai/transcribe";

export const dynamic = "force-dynamic";

export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const [c] = await db.select().from(clips).where(eq(clips.id, id));
  if (!c || !c.captions.length) return fail(404, "Sem legendas.");
  const text = toSrt(c.captions.map((l) => ({ start: l.start, end: l.end, text: l.words.map((w) => w.text).join(" ") })));
  return new Response(text, { headers: { "content-type": "text/plain; charset=utf-8", "content-disposition": `attachment; filename="legendas-corte.srt"` } });
});
