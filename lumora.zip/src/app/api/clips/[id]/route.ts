import { eq } from "drizzle-orm";
import { db } from "@/db";
import { assets, clips, projects } from "@/db/schema";
import { body, fail, handler, isUuid, ok, type Ctx } from "@/server/http";
import { getSegments } from "@/server/pipeline";
import { assertClipRange, DurationError } from "@/server/render";
import { buildCaptions } from "@/server/ai/subtitles";
import { assetDto, getAsset } from "@/server/assets";
import { removeRel } from "@/server/storage";
import type { AudioFx, Caption, CaptionStyle, EditorElement, HookConfig, LayoutConfig } from "@/lib/types";

export const dynamic = "force-dynamic";

export const GET = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  if (!isUuid(id)) return fail(404, "Corte não encontrado");
  const [c] = await db.select().from(clips).where(eq(clips.id, id));
  if (!c) return fail(404, "Corte não encontrado");
  const out = c.outputAssetId ? await getAsset(c.outputAssetId) : null;
  const [p] = await db.select().from(projects).where(eq(projects.id, c.projectId));
  const src = p?.sourceAssetId ? await getAsset(p.sourceAssetId) : null;
  return ok({ ...c, output: out ? assetDto(out) : null, source: src ? assetDto(src) : null });
});

type Patch = Partial<{ title: string; startSec: number; endSec: number; hook: HookConfig; captionStyle: CaptionStyle; captions: Caption[]; layout: LayoutConfig; audioFx: AudioFx; elements: EditorElement[]; rebuildCaptions: boolean }>;

/** Autosave do editor. Alterações de início/fim passam pela validação 60–90 s no backend. */
export const PATCH = handler(async (req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const b = await body<Patch>(req);
  const [c] = await db.select().from(clips).where(eq(clips.id, id));
  if (!c) return fail(404, "Corte não encontrado");
  const set: Partial<typeof clips.$inferInsert> = { updatedAt: new Date() };
  const start = b.startSec ?? c.startSec;
  const end = b.endSec ?? c.endSec;
  const rangeChanged = b.startSec !== undefined || b.endSec !== undefined;
  if (rangeChanged && c.type === "clip") {
    const [p] = await db.select().from(projects).where(eq(projects.id, c.projectId));
    const src = p?.sourceAssetId ? await getAsset(p.sourceAssetId) : null;
    try {
      assertClipRange(start, end, src?.durationSec ?? undefined);
    } catch (e) {
      return fail(400, e instanceof DurationError ? e.message : "Intervalo inválido");
    }
    set.startSec = start;
    set.endSec = end;
  }
  if (typeof b.title === "string") set.title = b.title.slice(0, 140);
  if (b.hook) {
    const h = b.hook;
    set.hook = { ...h, duration: Math.max(1, Math.min(8, h.duration)), start: Math.max(0, Math.min(h.start, (end - start) - 1)), size: Math.max(40, Math.min(200, h.size)), yPct: Math.max(3, Math.min(90, h.yPct)), text: String(h.text).slice(0, 120) };
  }
  if (b.captionStyle) set.captionStyle = b.captionStyle;
  if (b.layout) set.layout = b.layout;
  if (b.audioFx) set.audioFx = b.audioFx;
  if (b.elements) set.elements = b.elements.slice(0, 40);
  if (b.captions) set.captions = b.captions;
  else if (b.rebuildCaptions || rangeChanged || (b.captionStyle && b.captionStyle.wordsPerLine !== c.captionStyle.wordsPerLine)) {
    const segs = await getSegments(c.projectId);
    if (segs.length) set.captions = buildCaptions(segs, start, end, b.captionStyle ?? c.captionStyle);
  }
  if (c.status === "rendered" && !b.title) set.status = "candidate"; // edição invalida o render anterior
  const [row] = await db.update(clips).set(set).where(eq(clips.id, id)).returning();
  return ok(row);
});

export const DELETE = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const [c] = await db.select().from(clips).where(eq(clips.id, id));
  if (c?.outputAssetId) {
    const a = await getAsset(c.outputAssetId);
    if (a) { await removeRel(a.relPath); await db.delete(assets).where(eq(assets.id, a.id)); }
  }
  await db.delete(clips).where(eq(clips.id, id));
  return ok({ ok: true });
});
