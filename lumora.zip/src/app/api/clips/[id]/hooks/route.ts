import { eq } from "drizzle-orm";
import { db } from "@/db";
import { clips } from "@/db/schema";
import { fail, handler, ok, type Ctx } from "@/server/http";
import { makeHooks } from "@/server/ai/hooks";

export const POST = handler(async (_req: Request, ctx: Ctx) => {
  const { id } = await ctx.params;
  const [c] = await db.select().from(clips).where(eq(clips.id, id));
  if (!c) return fail(404, "Corte não encontrado");
  if (!c.spokenText) return fail(422, "Sem transcrição neste trecho: hooks automáticos precisam do conteúdo falado. Escreva o hook manualmente.");
  const tags = ((c.extra as { tags?: string[] }).tags) || [];
  const hooks = await makeHooks({ text: c.spokenText, tags, durationSec: c.endSec - c.startSec, kind: "general" });
  // rotaciona para trazer opções diferentes quando o usuário pede novas sugestões
  const [row] = await db.update(clips).set({ hookOptions: hooks, updatedAt: new Date() }).where(eq(clips.id, id)).returning();
  return ok(row.hookOptions);
});
