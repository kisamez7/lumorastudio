import { body, fail, handler, isUuid, ok } from "@/server/http";
import { enqueueJob } from "@/server/jobs";
import { scriptVideoJob } from "@/server/pipeline";

export const POST = handler(async (req: Request) => {
  const b = await body<{ script?: string; aspect?: string; secondsPerSlide?: number; palette?: number; projectId?: string }>(req);
  const script = String(b.script || "").slice(0, 8000);
  if (script.trim().length < 5) return fail(400, "Escreva um roteiro.");
  const aspect = (["9:16", "16:9", "1:1"].includes(String(b.aspect)) ? b.aspect : "9:16") as "9:16" | "16:9" | "1:1";
  const pid = b.projectId && isUuid(b.projectId) ? b.projectId : null;
  const o = { script, aspect, secondsPerSlide: Math.max(3, Math.min(12, Number(b.secondsPerSlide) || 5)), palette: Number(b.palette) || 0 };
  return ok({ jobId: await enqueueJob("ai-video", pid, { aspect }, (c) => scriptVideoJob(c, pid, o)) }, 202);
});
