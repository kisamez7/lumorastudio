import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { publishItems } from "@/db/schema";
import { body, fail, handler, isUuid, ok } from "@/server/http";

export const dynamic = "force-dynamic";

export const GET = handler(async (req: Request) => {
  const pid = new URL(req.url).searchParams.get("projectId");
  const q = db.select().from(publishItems);
  return ok(await (pid && isUuid(pid) ? q.where(eq(publishItems.projectId, pid)) : q).orderBy(desc(publishItems.createdAt)).limit(300));
});

type In = { id?: string; projectId?: string; clipId?: string; platform?: string; title?: string; description?: string; hashtags?: string[]; scheduledAt?: string | null; status?: string };

export const POST = handler(async (req: Request) => {
  const b = await body<In>(req);
  if (!["tiktok", "reels", "shorts", "facebook"].includes(String(b.platform))) return fail(400, "Plataforma inválida");
  const [row] = await db.insert(publishItems).values({
    projectId: b.projectId && isUuid(b.projectId) ? b.projectId : null, clipId: b.clipId && isUuid(b.clipId) ? b.clipId : null, platform: String(b.platform),
    title: String(b.title || "").slice(0, 200), description: String(b.description || "").slice(0, 3000), hashtags: (b.hashtags || []).slice(0, 30).map(String),
    scheduledAt: b.scheduledAt ? new Date(b.scheduledAt) : null, status: b.scheduledAt ? "scheduled" : "draft",
  }).returning();
  return ok(row, 201);
});

export const PATCH = handler(async (req: Request) => {
  const b = await body<In>(req);
  if (!b.id || !isUuid(b.id)) return fail(400, "id inválido");
  const [row] = await db.update(publishItems).set({
    ...(b.title !== undefined ? { title: String(b.title).slice(0, 200) } : {}), ...(b.description !== undefined ? { description: String(b.description).slice(0, 3000) } : {}),
    ...(b.hashtags ? { hashtags: b.hashtags.slice(0, 30).map(String) } : {}), ...(b.scheduledAt !== undefined ? { scheduledAt: b.scheduledAt ? new Date(b.scheduledAt) : null } : {}),
    ...(b.status && ["draft", "scheduled", "published"].includes(b.status) ? { status: b.status } : {}),
  }).where(eq(publishItems.id, b.id)).returning();
  return row ? ok(row) : fail(404, "Item não encontrado");
});

export const DELETE = handler(async (req: Request) => {
  const id = new URL(req.url).searchParams.get("id") || "";
  if (!isUuid(id)) return fail(400, "id inválido");
  await db.delete(publishItems).where(eq(publishItems.id, id));
  return ok({ ok: true });
});
