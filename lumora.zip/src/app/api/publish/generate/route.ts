import { eq } from "drizzle-orm";
import { db } from "@/db";
import { clips, projects } from "@/db/schema";
import { body, fail, handler, ok } from "@/server/http";
import { genPublish } from "@/server/ai/understand";

export const POST = handler(async (req: Request) => {
  const b = await body<{ clipId?: string }>(req);
  const [c] = await db.select().from(clips).where(eq(clips.id, String(b.clipId)));
  if (!c) return fail(404, "Corte não encontrado");
  const [p] = await db.select().from(projects).where(eq(projects.id, c.projectId));
  const text = c.spokenText || c.description;
  return ok(genPublish({ text, topic: c.topic, tags: ((c.extra as { tags?: string[] }).tags) || [], durationSec: c.endSec - c.startSec, hook: c.hook.text, kind: p?.kind || "general" }));
});
