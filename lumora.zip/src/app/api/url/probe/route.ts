import { body, fail, handler, ok } from "@/server/http";
import { probeUrl } from "@/server/connectors";
import { UrlError } from "@/server/security";

export const POST = handler(async (req: Request) => {
  const b = await body<{ url?: string }>(req);
  try {
    return ok(await probeUrl(String(b.url || "")));
  } catch (e) {
    if (e instanceof UrlError) return fail(400, e.message);
    throw e;
  }
});
