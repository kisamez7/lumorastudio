import { NextResponse } from "next/server";
import { body } from "@/server/http";
import { cfg } from "@/server/config";

export async function POST(req: Request) {
  const b = await body<{ token?: string }>(req);
  if (!cfg.accessToken || b.token !== cfg.accessToken) return NextResponse.json({ error: "Código inválido" }, { status: 401 });
  const res = NextResponse.json({ ok: true });
  res.cookies.set("lumora_session", cfg.accessToken, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production" && cfg.mode === "hosted", path: "/", maxAge: 60 * 60 * 24 * 30 });
  return res;
}
