import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Lumora Studio — IA para vídeos",
  description: "Encontre os melhores momentos, crie cortes, hooks e legendas, edite e prepare vídeos para redes sociais com IA local e gratuita.",
};
export const viewport: Viewport = { themeColor: "#07070c" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen antialiased">{children}</body>
    </html>
  );
}
