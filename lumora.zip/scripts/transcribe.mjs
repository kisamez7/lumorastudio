// Transcrição local (Whisper via transformers.js / ONNX Runtime, CPU).
// Uso: node scripts/transcribe.mjs <arquivo> <idioma|auto> <modelo>
// Emite linhas JSON em stdout: {type:"progress",p,msg} e {type:"result",segments,words,language}
import { spawn } from "node:child_process";

const [, , file, langArg = "pt", model = "Xenova/whisper-base"] = process.argv;
const ffmpeg = process.env.FFMPEG_PATH || "ffmpeg";
const SR = 16000;
const BLOCK_SEC = 300; // processa em blocos de 5 min para controlar memória
const LANGS = { pt: "portuguese", en: "english", es: "spanish", fr: "french", de: "german", it: "italian", ja: "japanese" };
const emit = (o) => process.stdout.write(JSON.stringify(o) + "\n");

async function duration() {
  return new Promise((res) => {
    const p = spawn(ffmpeg, ["-hide_banner", "-i", file]);
    let err = "";
    p.stderr.on("data", (d) => (err += d));
    p.on("close", () => {
      const m = err.match(/Duration: (\d+):(\d+):(\d+\.\d+)/);
      res(m ? +m[1] * 3600 + +m[2] * 60 + +m[3] : 0);
    });
  });
}

async function main() {
  const total = await duration();
  emit({ type: "progress", p: 0.01, msg: "Carregando modelo Whisper (" + model + ")" });
  const { pipeline } = await import("@huggingface/transformers");
  const asr = await pipeline("automatic-speech-recognition", model, { dtype: process.env.WHISPER_DTYPE || "fp32" });
  emit({ type: "progress", p: 0.05, msg: "Modelo carregado" });

  const proc = spawn(ffmpeg, ["-v", "error", "-i", file, "-vn", "-ac", "1", "-ar", String(SR), "-f", "f32le", "pipe:1"]);
  const blockBytes = BLOCK_SEC * SR * 4;
  let buf = Buffer.alloc(0);
  let offset = 0;
  const words = [];
  const queue = [];
  let ended = false;
  let wake = null;
  proc.stdout.on("data", (d) => {
    buf = Buffer.concat([buf, d]);
    while (buf.length >= blockBytes) {
      queue.push(buf.subarray(0, blockBytes));
      buf = buf.subarray(blockBytes);
    }
    // backpressure simples
    if (queue.length > 1) proc.stdout.pause();
    wake?.();
  });
  proc.stdout.on("end", () => { if (buf.length > SR * 4 * 0.5) queue.push(buf); ended = true; wake?.(); });
  proc.stderr.on("data", () => {});

  const opts = { return_timestamps: "word", chunk_length_s: 30, stride_length_s: 5, task: "transcribe" };
  if (langArg !== "auto") opts.language = LANGS[langArg] || langArg;

  while (true) {
    if (!queue.length) {
      if (ended) break;
      await new Promise((r) => (wake = r));
      continue;
    }
    const raw = queue.shift();
    proc.stdout.resume();
    const f32 = new Float32Array(raw.buffer.slice(raw.byteOffset, raw.byteOffset + raw.byteLength - (raw.byteLength % 4)));
    const out = await asr(f32, opts);
    for (const c of out.chunks || []) {
      const [s, e] = c.timestamp;
      const t = (c.text || "").trim();
      if (!t) continue;
      words.push({ start: +(offset + (s ?? 0)).toFixed(2), end: +(offset + (e ?? s ?? 0)).toFixed(2), text: t });
    }
    offset += f32.length / SR;
    emit({ type: "progress", p: 0.05 + 0.93 * Math.min(1, total ? offset / total : 0.5), msg: `Transcrito ${Math.round(offset)}s de ${Math.round(total)}s` });
  }

  // agrupa palavras em segmentos (pontuação final ou pausa > 0.8s)
  const segments = [];
  let cur = null;
  for (const w of words) {
    if (cur && (w.start - cur.end > 0.8 || cur.words.length >= 28)) { segments.push(cur); cur = null; }
    if (!cur) cur = { start: w.start, end: w.end, words: [] };
    cur.words.push(w);
    cur.end = w.end;
    if (/[.!?…]$/.test(w.text)) { segments.push(cur); cur = null; }
  }
  if (cur) segments.push(cur);
  const outSeg = segments.map((s) => ({ start: s.start, end: s.end, text: s.words.map((w) => w.text).join(" ").replace(/\s+([,.!?…])/g, "$1"), words: s.words }));
  emit({ type: "result", segments: outSeg, language: langArg });
}

main().catch((e) => { emit({ type: "error", message: String(e?.message || e) }); process.exit(1); });
