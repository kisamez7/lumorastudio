#!/usr/bin/env bash
# Gera um vídeo sintético 1920x1080 de 200 s (com "webcam" fora do centro) para testes. Requer ffmpeg.
set -e
F=${FFMPEG_PATH:-ffmpeg}
mkdir -p tmp_test
$F -v error -y -f lavfi -i "testsrc2=size=1920x1080:rate=30:duration=200" -f lavfi -i "smptebars=size=480x270:rate=30:duration=200" -f lavfi -i "sine=frequency=300:duration=200,tremolo=f=0.2:d=0.9" \
  -filter_complex "[0:v][1:v]overlay=1380:40[v]" -map "[v]" -map 2:a -c:v libx264 -preset ultrafast -crf 28 -c:a aac tmp_test/game.mp4
